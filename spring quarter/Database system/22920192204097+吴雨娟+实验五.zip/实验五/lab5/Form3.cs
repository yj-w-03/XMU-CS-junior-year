﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace lab5
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string sid = textBox1.Text.Trim();
            string sname = textBox2.Text.Trim();
            string email = textBox3.Text.Trim();
            string grade = textBox4.Text.Trim();
            string sql = "update STUDENTS set sname='" + sname + "',email='" + email + "',grade='" + grade + "' where sid='" + sid + "'";
            if (Form1.ExecuteSql(sql) > 0)
            {
                MessageBox.Show("编辑成功");
            }
            this.Close();
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            string sid = textBox1.Text.Trim();
            string sname = textBox2.Text.Trim();
            string email = textBox3.Text.Trim();
            string grade = textBox4.Text.Trim();
            string sql = "update STUDENTS set sname='" + sname + "',email='" + email + "',grade='" + grade + "' where sid='" + sid + "'";
            if (Form1.ExecuteSql(sql) > 0)
            {
                MessageBox.Show("编辑成功");
            }
            this.Close();
        }
    }
}
