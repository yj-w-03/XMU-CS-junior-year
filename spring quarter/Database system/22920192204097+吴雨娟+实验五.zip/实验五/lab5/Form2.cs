﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace lab5
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string sid = textBox1.Text.Trim();
            string sname = textBox2.Text.Trim();
            string email = textBox3.Text.Trim();
            string grade = textBox4.Text.Trim();
            string sql = "insert into STUDENTS values('" + sid + "','" + sname + "','" + email + "','" + grade + "')";
            if(Form1.ExecuteSql(sql)>0)
            {
                MessageBox.Show("添加成功");
            }
            this.Close();
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            string sid = textBox1.Text.Trim();
            string sname = textBox2.Text.Trim();
            string email = textBox3.Text.Trim();
            string grade = textBox4.Text.Trim();
            string sql = "insert into STUDENTS values('" + sid + "','" + sname + "','" + email + "','" + grade + "')";
            if (Form1.ExecuteSql(sql) > 0)
            {
                MessageBox.Show("添加成功");
            }
            this.Close();
        }
    }
}
