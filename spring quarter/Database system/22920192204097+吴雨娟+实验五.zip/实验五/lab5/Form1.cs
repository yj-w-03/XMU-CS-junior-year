﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;

namespace lab5
{
    public partial class Form1 : Form
    {
        static string connectionString = System.Configuration.ConfigurationManager.AppSettings["connectionString"];
        public Form1()
        {
            InitializeComponent();
        }

        public static DataSet Query(String sql)
        {
            SqlConnection con = new SqlConnection(connectionString);
            SqlDataAdapter sda = new SqlDataAdapter(sql, con);
            DataSet ds = new DataSet();
            try
            {
                con.Open();
                sda.Fill(ds, "students");
                return ds;
            }
            catch(SqlException e)
            {
                throw new Exception(e.Message);
            }
            finally
            {
                sda.Dispose();
                con.Close();
            }
        }

        public static int ExecuteSql(String sql)
        {
            SqlConnection con = new SqlConnection(connectionString);
            SqlCommand cmd = new SqlCommand(sql, con);
            try
            {
                con.Open();
                int rows = cmd.ExecuteNonQuery();
                return rows;
            }
            catch(SqlException e)
            {
                throw new Exception(e.Message);
            }
            finally
            {
                cmd.Dispose();
                con.Close();
            }
        }

        private void button1_Click(object sender,EventArgs e)
        {
            string sid = textBox1.Text.Trim();
            string sname = textBox2.Text.Trim();
            dataGridView1.DataSource = Query("select * from students where sid like '%" + sid + "'% and sname like '%" + sname + "'%").Tables["students"];
        }

        private void button3_Click(object sender, EventArgs e)
        {
            int a = dataGridView1.CurrentRow.Index;
            string sid = dataGridView1.Rows[a].Cells[0].Value.ToString().Trim();
            string sql = "delete from STUDENTS where sid='" + sid + "'";
            if(ExecuteSql(sql)>0)
            {
                MessageBox.Show("删除成功");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form2 childrenForm = new Form2();
            childrenForm.Owner = this;
            childrenForm.Show();
        }

        private void groupBox2_Enter(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            string sid = textBox1.Text.Trim();
            string sname = textBox2.Text.Trim();
            this.dataGridView1.DataSource = Query("select * from students where sid like '%" + sid + "%' and sname like '%" + sname + "%'").Tables["students"];
        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            Form2 childrenForm = new Form2();
            childrenForm.Owner = this;
            childrenForm.Show();
        }

        private void button3_Click_1(object sender, EventArgs e)
        {
            int a = dataGridView1.CurrentRow.Index;
            string sid = dataGridView1.Rows[a].Cells[0].Value.ToString().Trim();
            string sql = "delete from STUDENTS where sid='" + sid + "'";
            if (ExecuteSql(sql) > 0)
            {
                MessageBox.Show("删除成功");
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Form3 childrenForm = new Form3();
            childrenForm.Owner = this;
            childrenForm.Show();
        }
    }

    
}
