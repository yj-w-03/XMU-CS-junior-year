/*==============================================================*/
/* Database name:  SSManage                                     */
/* DBMS name:      Microsoft SQL Server Management Studio 18    */
/* Created on:     2022/6/19 16:13:50                           */
/*==============================================================*/

use master
if exists (select 1
          from sysobjects
          where  id = object_id('sp_kill_by_dbname')
          and type in ('P','PC'))
   drop procedure sp_kill_by_dbname
go

create proc sp_kill_by_dbname
	@dbname varchar(20)
as
begin
	declare @sql nvarchar(500),@temp varchar(1000)
	declare @spid int
	set @sql= 'declare getspid cursor for  
			select spid from sysprocesses 
			where dbid=db_id('''+@dbname+''')'
	exec (@sql)
	open getspid
	fetch next from getspid into @spid
	while @@fetch_status<>-1
	begin
		set @temp='kill '+rtrim(@spid)
		exec(@temp)
		fetch next from getspid into @spid
	end
	close getspid
	deallocate getspid
end
go

use master
exec sp_kill_by_dbname 'SSManage'
go

drop database SSManage
go
/*==============================================================*/
/* Database: SSManage                                             */
/*==============================================================*/
create database SSManage
go

use SSManage
go

/*==============================================================*/
/* Table: UserTable										        */
/*==============================================================*/
create table UserTable (
   userID               varchar(20)          not null,
   password             varchar(16)          not null,
   authority            int                  not null,
   constraint PK_USERTABLE primary key (userID)
)
go

/*==============================================================*/
/* Table: Student                                               */
/*==============================================================*/
create table Student (
   studentID            varchar(20)          not null,
   userID               varchar(20)          not null,
   studentName          varchar(10)          not null,
   studentSex           bit                  not null,
   studentGrade         char(5)              not null,
   studentFaculty       char(5)              not null,
   constraint PK_STUDENT primary key (studentID)
)
go

/*==============================================================*/
/* Table: Administrator                                         */
/*==============================================================*/
create table Administrator (
   adminID              varchar(20)          not null,
   userID               varchar(20)          not null,
   adminName            varchar(10)          not null,
   constraint PK_ADMINISTRATOR primary key (adminID)
)
go

/*==============================================================*/
/* Table: Teacher                                               */
/*==============================================================*/
create table Teacher (
   teacherID            varchar(20)          not null,
   userID               varchar(20)          not null,
   teacherName          varchar(10)          not null,
   teacherSex           bit                  not null,
   title                int                  not null,
   constraint PK_TEACHER primary key (teacherID)
)
go

/*==============================================================*/
/* Table: Course                                                */
/*==============================================================*/
create table Course (
   courseNo             varchar(20)          not null,
   teacherID            varchar(20)          not null,
   courseName           varchar(16)          not null,
   credit               int                  not null,
   hour                 int                  not null,
   type                 bit                  not null,
   time                 int                  not null,
   constraint PK_COURSE primary key (courseNo)
)
go

/*==============================================================*/
/* Table: Grade                                                 */
/*==============================================================*/
create table Grade (
   courseNo             varchar(20)          not null,
   studentID            varchar(20)          not null,
   grade                int                  not null,
   state                int                  ,
)
go

alter table Student
   add constraint FK_STUDENT_REFERENCE_USERTABL foreign key (userID)
      references UserTable (userID)
         on delete cascade
go

alter table Administrator
   add constraint FK_ADMINIST_REFERENCE_USERTABL foreign key (userID)
      references UserTable (userID)
         on delete cascade
go

alter table Teacher
   add constraint FK_TEACHER_REFERENCE_USERTABL foreign key (userID)
      references UserTable (userID)
         on delete cascade
go

alter table Course
   add constraint FK_COURSE_REFERENCE_TEACHER foreign key (teacherID)
      references Teacher (teacherID)
         on delete no action
go

alter table Grade
   add constraint FK_GRADE_REFERENCE_COURSE foreign key (courseNo)
      references Course (courseNo)
         on delete cascade
go

alter table Grade
   add constraint FK_GRADE_REFERENCE_STUDENT foreign key (studentID)
      references Student (studentID)
         on delete cascade
go

create function fun_print_faculty (@faculty char(5))
returns varchar(30)
as
begin
	declare @res varchar(30)
	set @res = ''
	if((select SUBSTRING(@faculty,1,1)) = '1') 
			set @res = @res + 'ͨ��ϵ ';
	if((select SUBSTRING(@faculty,2,1)) = '1') 
			set @res = @res + '����ϵ ';	
	if((select SUBSTRING(@faculty,3,1)) = '1') 
			set @res = @res + '����ϵ ';
	if((select SUBSTRING(@faculty,4,1)) = '1') 
			set @res = @res + '�����ϵ ';
	return @res
end
go

create function fun_print_grade (@grade char(5))
returns varchar(30)
as
begin
	declare @res varchar(30)
	set @res = ''
	if((select SUBSTRING(@grade,1,1)) = '1') 
			set @res = @res + '2021 ';
	if((select SUBSTRING(@grade,2,1)) = '1') 
			set @res = @res + '2020 ';	
	if((select SUBSTRING(@grade,3,1)) = '1') 
			set @res = @res + '2019 ';
	if((select SUBSTRING(@grade,4,1)) = '1') 
			set @res = @res + '2018 ';
	return @res
end
go

create function fun_print_title (@title int)
returns varchar(20)
as
begin
	declare @res varchar(20)
	set @res = ''
	if(@title = 0) 
		set @res = '����';
	if(@title = 1) 
		set @res = '��ʦ';
	if(@title = 2) 
		set @res = '������';	
	if(@title = 3) 
		set @res = '����';
	return @res
end
go

create function fun_print_sex (@sex bit)
returns varchar(20)
as
begin
	declare @res varchar(20)
	set @res = ''
	if(@sex = 0) 
		set @res = '��';
	if(@sex = 1) 
		set @res = 'Ů';
	return @res
end
go

create function fun_print_state (@state bit)
returns varchar(20)
as
begin
	declare @res varchar(20)
	set @res = ''
	if(@state = 0) 
		set @res = '����';
	if(@state = 1) 
		set @res = '��Ҫ����';
	return @res
end
go

create function fun_print_time (@time int)
returns varchar(20)
as
begin
	declare @res varchar(20)
	set @res = ''
	if(@time = 0) 
		set @res = '��һ��';
	if(@time = 1) 
		set @res = '��һ��';
	if(@time = 2) 
		set @res = '�����';
	if(@time = 3) 
		set @res = '�����';
	if(@time = 4) 
		set @res = '������';
	if(@time = 5) 
		set @res = '������';
	if(@time = 6) 
		set @res = '������';
	if(@time = 7) 
		set @res = '������';
	return @res
end
go

create function fun_print_type (@type bit)
returns varchar(20)
as
begin
	declare @res varchar(20)
	set @res = ''
	if(@type = 0) 
		set @res = 'ѡ��';
	if(@type = 1) 
		set @res = '����';
	return @res
end
go

create view v_admin as
select UserTable.userID, adminID as '����', adminName as '����'
from UserTable, Administrator
where UserTable.userID = Administrator.userID
go

create view v_student as
select UserTable.userID, studentID as 'ѧ��', studentName as '����', dbo.fun_print_sex(studentSex) as '�Ա�',
	  dbo.fun_print_grade(studentGrade) as '�꼶', dbo.fun_print_faculty(studentFaculty) as 'ϵ��'
from UserTable, Student
where UserTable.userID = Student.userID
go

create view v_teacher as
select UserTable.userID, teacherID as '����', teacherName as '����', dbo.fun_print_sex(teacherSex) as '�Ա�',
	  dbo.fun_print_title(title) as 'ְ��'
from UserTable, Teacher
where UserTable.userID = Teacher.userID
go

create view v_grade as
select studentID as 'ѧ��', Course.courseNo as '�γ̺�',Course.courseName as '�γ���', grade as '����',dbo.fun_print_state(state) as '�γ�״̬',
Course.credit as 'ѧ��',Course.hour as '��ʱ',dbo.fun_print_time(time) as 'ѧ��'
from Course,Grade
where Course.courseNo = Grade.courseNo
go

create view v_course as
select Course.courseNo as '�γ̺�',courseName as '�γ�����', teacherName as '�ον�ʦ', credit as 'ѧ��',hour as '��ʱ',
dbo.fun_print_type(type) as '�γ�����',dbo.fun_print_time(time) as 'ѧ��'
from Course,Teacher
where Course.teacherID = Teacher.teacherID
go

create trigger t_insert_state on Grade for insert
as
begin
	if(select grade from inserted)<60
	begin
	declare @studentID varchar(20),@courseNo varchar(20)
	select @studentID=studentID,@courseNo=courseNo from inserted
	update Grade set state=1 where studentID=@studentID and courseNo=@courseNo
	end
	else if(select grade from inserted)>=60
	begin
	select @studentID=studentID,@courseNo=courseNo from inserted
	update Grade set state=0 where studentID=@studentID and courseNo=@courseNo
	end
end
go

/*select * from Administrator
select * from UserTable
select * from Student
select * from Teacher
insert into UserTable values('1234','1234',0)
insert into UserTable values('2345','2345',1)
insert into UserTable values('22920192204033','3456',2)
insert into Administrator values('1234','1234','����')
insert into Teacher values('2345','2345','����',0,1)
insert into Student values('22920192204033','22920192204033','����',1,1,1)*/