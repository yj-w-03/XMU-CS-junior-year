﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace test1
{
    public partial class Form6 : Form
    {
        public Form6()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string tid = textBox1.Text.Trim();
            string newkey = textBox2.Text.Trim();
            string sql = "update UserTable set password='" + newkey + "' where userID='" + tid + "'";
            if (Form1.ExecuteSql(sql) > 0)
            {
                MessageBox.Show("编辑成功");
            }
            this.Close();
        }
    }
}
