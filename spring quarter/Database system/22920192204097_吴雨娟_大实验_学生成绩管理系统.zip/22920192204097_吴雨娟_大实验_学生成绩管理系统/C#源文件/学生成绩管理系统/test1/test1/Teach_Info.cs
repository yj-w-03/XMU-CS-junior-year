﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace test1
{
    public partial class Teach_Info : Form
    {
        public Teach_Info()
        {
            InitializeComponent();
        }

        public Add_Teacher Add_Teacher
        {
            get => default;
            set
            {
            }
        }

        public update_teach_Info update_teach_Info
        {
            get => default;
            set
            {
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.dataGridView1.DataSource = Login.Query("select * from v_teacher ").Tables[0];
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Add_Teacher TeacherFrom_add = new Add_Teacher();
            TeacherFrom_add.Owner = this;
            TeacherFrom_add.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            int a = dataGridView1.CurrentRow.Index;
            string tid = dataGridView1.Rows[a].Cells[0].Value.ToString().Trim();
            string sql = "delete from teacher where teacherID='" + tid + "'";
            string sql2 = "delete from usertable where userID='" + tid + "'";
            if (Login.ExecuteSql(sql) > 0)
            {
                Login.ExecuteSql(sql2);
                MessageBox.Show("删除成功");
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            update_teach_Info teacherFrom_update = new update_teach_Info();
            teacherFrom_update.Owner = this;
            teacherFrom_update.Show();
        }
    }
}
