﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace test1
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
            comboBox1.Items.Add("大一上");
            comboBox1.Items.Add("大一下");
            comboBox1.Items.Add("大二上");
            comboBox1.Items.Add("大二下");
            comboBox1.Items.Add("大三上");
            comboBox1.Items.Add("大三下");
            comboBox1.Items.Add("大四上");
            comboBox1.Items.Add("大四下");
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string sid = textBox1.Text.Trim();
            string time = comboBox1.Text.Trim();

            string sql1 = "select * from v_grade where 学号 = " + sid + "and 学期 = '" + time + "' ";


            this.dataGridView1.DataSource = Form1.Query(sql1).Tables[0];
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged_1(object sender, EventArgs e)
        {

        }
    }
}
