﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace test1
{
    public partial class Add_Course : Form
    {
        public Add_Course()
        {
            InitializeComponent();
            comboBox1.Items.Add("选修课");
            comboBox1.Items.Add("必修课");
            comboBox2.Items.Add("大一上");
            comboBox2.Items.Add("大一下");
            comboBox2.Items.Add("大二上");
            comboBox2.Items.Add("大二下");
            comboBox2.Items.Add("大三上");
            comboBox2.Items.Add("大三下");
            comboBox2.Items.Add("大四上");
            comboBox2.Items.Add("大四下");
        }

        private void comboBox5_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }

        private void ground_Enter(object sender, EventArgs e)
        {

        }

        private void button6_Click(object sender, EventArgs e)
        {
            string cno = textBox1.Text.Trim();
            string tid = textBox2.Text.Trim();
            string name = textBox3.Text.Trim();
            string credit = textBox4.Text.Trim();
            string hour = textBox5.Text.Trim();
            string type = comboBox1.Text.Trim();
            string time = comboBox2.Text.Trim();
            bool ttype;
            if (type == "必修课")
                ttype = true;
            else
                ttype = false;
            int ttime=0;
            if (type == "大一上")
                ttime = 0;
            else if (type == "大一下")
                ttime = 1;
            else if (type == "大二上")
                ttime = 2;
            else if (type == "大二下")
                ttime = 3;
            else if (type == "大三上")
                ttime = 4;
            else if (type == "大三下")
                ttime = 5;
            else if (type == "大四上")
                ttime = 6;
            else
                ttime = 7;
            string sql = "insert into course values('" + cno + "','" + tid + "','" + name + "','" + credit + "','" + hour + "','" + ttype + "','" + ttime + "')";
            if (cno == "" || tid == "" || name == "" || credit == "" || hour == "" || type == "" || time == "")
            {
                MessageBox.Show("新增课程信息中不能包含空值！");
            }
            else
            {
                if (Login.ExecuteSql(sql) > 0)
                {
                    MessageBox.Show("添加成功");
                }
                this.Close();
            }
        }
    }
}
