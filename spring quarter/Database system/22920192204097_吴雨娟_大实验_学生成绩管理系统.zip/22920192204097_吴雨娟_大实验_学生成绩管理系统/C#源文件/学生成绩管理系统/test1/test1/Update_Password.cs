﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace test1
{
    public partial class Update_Password : Form
    {
        string Userid;
        public Update_Password(string userid)
        {
            InitializeComponent();
            Userid = userid;
        }

        private void Uodate_Password_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string sql = "update usertable set password = '" + textBox1.Text + "' from usertable where userid = '" + Userid + "';";
            if (Login.ExecuteSql(sql) > 0)
            {
                MessageBox.Show("修改成功！");
            }
            this.Close();
        }
    }
}
