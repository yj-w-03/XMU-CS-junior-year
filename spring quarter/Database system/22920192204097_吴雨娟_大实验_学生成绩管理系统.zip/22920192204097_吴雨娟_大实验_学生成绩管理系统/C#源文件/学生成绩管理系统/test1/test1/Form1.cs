﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;

namespace test1
{
    public partial class Form1 : Form
    {
        static string connectionString = System.Configuration.ConfigurationManager.AppSettings["connectionString"];
        string Userid;
        public Form1(string userid)
        {
            Userid = userid;
            InitializeComponent();
            string sql = "select * from v_student where userid = '" + Userid + "';";
            DataSet ds = Login.Query(sql);
            DataTable dt = ds.Tables[0];
            label6.Text = dt.Rows[0][0].ToString();    
            label7.Text = dt.Rows[0][2].ToString();
            label8.Text = dt.Rows[0][3].ToString();
            label9.Text = dt.Rows[0][4].ToString();
            label10.Text = dt.Rows[0][5].ToString();
        }

        public Form2 change_key
        {
            get => default;
            set
            {
            }
        }

        public Form3 query_grade
        {
            get => default;
            set
            {
            }
        }

        public Form4 query_CourseAndCredit
        {
            get => default;
            set
            {
            }
        }

        public static DataSet Query(String sql)
        {
            SqlConnection con = new SqlConnection(connectionString);
            SqlDataAdapter sda = new SqlDataAdapter(sql, con);
            DataSet ds = new DataSet();
            try
            {
                con.Open();
                sda.Fill(ds, "students");
                return ds;
            }
            catch (SqlException e)
            {
                throw new Exception(e.Message);
            }
            finally
            {
                sda.Dispose();
                con.Close();
            }
        }

        public static int ExecuteSql(String sql)
        {
            SqlConnection con = new SqlConnection(connectionString);
            SqlCommand cmd = new SqlCommand(sql, con);
            try
            {
                con.Open();
                int rows = cmd.ExecuteNonQuery();
                return rows;
            }
            catch (SqlException e)
            {
                throw new Exception(e.Message);
            }
            finally
            {
                cmd.Dispose();
                con.Close();
            }
        }



        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form2 childrenForm = new Form2();
            childrenForm.Owner = this;
            childrenForm.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form3 childrenForm = new Form3();
            childrenForm.Owner = this;
            childrenForm.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Form4 childrenForm = new Form4();
            childrenForm.Owner = this;
            childrenForm.Show();
        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
           
        }

        private void label7_Click(object sender, EventArgs e)
        {

        }
    }
}
