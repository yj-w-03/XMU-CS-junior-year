﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace test1
{
    public partial class Add_Student : Form
    {
        public Add_Student()
        {
            InitializeComponent();
            comboBox1.Items.Add("男");
            comboBox1.Items.Add("女");
            comboBox2.Items.Add("2021");
            comboBox2.Items.Add("2020");
            comboBox2.Items.Add("2019");
            comboBox2.Items.Add("2018");
            comboBox3.Items.Add("通信系");
            comboBox3.Items.Add("网安系");
            comboBox3.Items.Add("智能系");
            comboBox3.Items.Add("计算机系");
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string sid = textBox1.Text.Trim();
            string name = textBox2.Text.Trim();
            string sex = comboBox1.Text.Trim();
            string grade = comboBox2.Text.Trim();
            string faculty = comboBox3.Text.Trim();
            bool ssex;
            if (sex == "男")
                ssex = false;
            else
                ssex = true;
            if (grade == "2021")
                grade = "1000";
            else if (grade == "2020")
                grade = "0100";
            else if (grade == "2019")
                grade = "0010";
            else
                grade = "0001";
            if (faculty == "通信系")
                faculty = "1000";
            else if (faculty == "网安系")
                faculty = "0100";
            else if (faculty == "智能系")
                faculty = "0010";
            else
                faculty = "0001";
            int f=2;
            string sql1 = "insert into usertable values('" + sid + "','" + sid + "','" + f  + "')";
            if (name == "" || sex == "" || grade == "" || faculty == "" || sid == "")
            {
                MessageBox.Show("新增学生信息中不能包含空值！");
            }
            else
                Login.ExecuteSql(sql1);
            string sql2 = "insert into student values('" + sid + "','" + sid + "','" + name + "','" + ssex + "','" + grade + "','" + faculty + "')";

            if (Login.ExecuteSql(sql2) > 0)
            {
                 MessageBox.Show("添加成功");
            }
            this.Close();
            
        }
    }
}
