﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace test1
{
    public partial class update_teach_Info : Form
    {
        public update_teach_Info()
        {
            InitializeComponent();
            comboBox1.Items.Add("男");
            comboBox1.Items.Add("女");
            comboBox2.Items.Add("助教");
            comboBox2.Items.Add("讲师");
            comboBox2.Items.Add("副教授");
            comboBox2.Items.Add("教授");
        }

        private void button6_Click(object sender, EventArgs e)
        {
            string tid = textBox1.Text.Trim();
            string name = textBox2.Text.Trim();
            string sex = comboBox1.Text.Trim();
            string title = comboBox2.Text.Trim();
            bool ssex;
            if (sex == "男")
                ssex = false;
            else
                ssex = true;
            int ttitle;
            if (title == "助教")
                ttitle = 0;
            else if (title == "讲师")
                ttitle = 1;
            else if (title == "副教授")
                ttitle = 2;
            else
                ttitle = 3;
            string sql = "update teacher set teacherName='" + name + "',teacherSex='" + ssex + "',title='" + ttitle + "' where teacherID='" + tid + "'";
            if (Login.ExecuteSql(sql) > 0)
            {
                MessageBox.Show("修改成功");
            }
            this.Close();
        }
    }
}
