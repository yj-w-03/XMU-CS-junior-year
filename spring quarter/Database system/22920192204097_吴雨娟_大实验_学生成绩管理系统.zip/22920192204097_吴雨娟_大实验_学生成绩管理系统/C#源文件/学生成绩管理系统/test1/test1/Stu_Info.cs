﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace test1
{
    public partial class Stu_Info : Form
    {
        public Stu_Info()
        {
            InitializeComponent();
        }

        public Add_Student Add_Student
        {
            get => default;
            set
            {
            }
        }

        public update_stu_Info update_stu_Info
        {
            get => default;
            set
            {
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.dataGridView1.DataSource = Login.Query("select * from v_student ").Tables[0];
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Add_Student StudentFrom_add = new Add_Student();
            StudentFrom_add.Owner = this;
            StudentFrom_add.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            int a = dataGridView1.CurrentRow.Index;
            string sid = dataGridView1.Rows[a].Cells[0].Value.ToString().Trim();
            string sql = "delete from student where studentID='" + sid + "'";
            string sql2 = "delete from usertable where userID='" + sid + "'";
            if (Login.ExecuteSql(sql) > 0)
            {
                Login.ExecuteSql(sql2);
                MessageBox.Show("删除成功");
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            update_stu_Info studentFrom_update = new update_stu_Info();
            studentFrom_update.Owner = this;
            studentFrom_update.Show();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
