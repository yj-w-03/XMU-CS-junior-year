﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace test1
{
    public partial class update_stu_Info : Form
    {
        public update_stu_Info()
        {
            InitializeComponent();
            comboBox1.Items.Add("男");
            comboBox1.Items.Add("女");
            comboBox2.Items.Add("2021");
            comboBox2.Items.Add("2020");
            comboBox2.Items.Add("2019");
            comboBox2.Items.Add("2018");
            comboBox3.Items.Add("通信系");
            comboBox3.Items.Add("网安系");
            comboBox3.Items.Add("智能系");
            comboBox3.Items.Add("计算机系");
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void update_stu_Info_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string sid = textBox1.Text.Trim();
            string sname = textBox2.Text.Trim();
            string sex = comboBox1.Text.Trim();
            string grade = comboBox2.Text.Trim();
            string faculty = comboBox3.Text.Trim();
            bool ssex;
            if (sex == "男")
                ssex = false;
            else
                ssex = true;
            if (grade == "2021")
                grade = "1000";
            else if (grade == "2020")
                grade = "0100";
            else if (grade == "2019")
                grade = "0010";
            else
                grade = "0001";
            if (faculty == "通信系")
                faculty = "1000";
            else if (faculty == "网安系")
                faculty = "0100";
            else if (faculty == "智能系")
                faculty = "0010";
            else
                faculty = "0001";
            string sql = "update student set studentName='" + sname + "',studentSex='" + ssex + "',studentGrade='" + grade + "',studentFaculty='" + faculty + "' where studentID='" + sid + "'";
            if (Login.ExecuteSql(sql) > 0)
            {
                MessageBox.Show("修改成功");
            }
            this.Close();
        }
    }
}
