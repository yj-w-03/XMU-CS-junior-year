﻿using System;
using System.Configuration;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace test1
{
    public partial class Login : Form
    {
        static string connectionString = System.Configuration.ConfigurationManager.AppSettings["connectionString"];
        public static DataSet Query(String sql)
        {
            SqlConnection con = new SqlConnection(connectionString);
            SqlDataAdapter sda = new SqlDataAdapter(sql, con);
            DataSet ds = new DataSet();
            try
            {
                con.Open();
                sda.Fill(ds, "result");
                return ds;
            }
            catch (SqlException e)
            {
                throw new Exception(e.Message);
            }
            finally
            {
                sda.Dispose();
                con.Close();
            }
        }
        public static int ExecuteSql(String sql)
        {
            SqlConnection con = new SqlConnection(connectionString);
            SqlCommand cmd = new SqlCommand(sql, con);
            try
            {
                con.Open();
                int rows = cmd.ExecuteNonQuery();
                return rows;
            }
            catch (SqlException e)
            {
                throw new Exception(e.Message);
            }
            finally
            {
                cmd.Dispose();
                con.Close();
            }
        }

        public Login()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void child_form_closed(object sender, FormClosedEventArgs e)
        {
            this.Close();
        }

        private void submit(object sender, EventArgs e)
        {
            string username = textBox1.Text;
            string password = textBox2.Text;

            if (username == "" && password == "")
            {
                MessageBox.Show("学工号和密码不能为空！");
            }
            else if (username == "")
            {
                MessageBox.Show("学工号不能为空！");
            }
            else if (password == "")
            {
                MessageBox.Show("密码不能为空！");
            }
            else
            {
                string sql = "select authority, password from usertable where userid = '" + username + "';";
                DataSet ds = Query(sql);
                DataTable dt = ds.Tables[0];
                if (dt.Rows.Count == 0)
                {
                    MessageBox.Show("此用户不存在！");
                }
                else
                {
                    if (password != dt.Rows[0][1].ToString())
                    {
                        MessageBox.Show("密码错误！");
                    }
                    else
                    {
                        
                        if (dt.Rows[0][0].ToString() == "2") // 学生
                        {
                            Form1 childform = new Form1(username);
                            childform.Show();
                            childform.FormClosed += child_form_closed;
                            this.Hide();
                        }
                        else if (dt.Rows[0][0].ToString() == "1" )  //教师
                        {
                            Form5 childform = new Form5(username);
                            childform.Show();
                            childform.FormClosed += child_form_closed;
                            this.Hide();
                        }
                        else                   //管理员
                        {
                            Admin childform = new Admin(username);
                            childform.Show();
                            childform.FormClosed += child_form_closed;
                            this.Hide();
                        }
                    }
                }
            }
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        public Admin Admin
        {
            get => default;
            set
            {
            }
        }

        public Form1 Student
        {
            get => default;
            set
            {
            }
        }

        public Admin Admin1
        {
            get => default;
            set
            {
            }
        }

        public Form5 Teacher
        {
            get => default;
            set
            {
            }
        }

        public Form1 Form1
        {
            get => default;
            set
            {
            }
        }

        public Form5 Form5
        {
            get => default;
            set
            {
            }
        }
    }
}
