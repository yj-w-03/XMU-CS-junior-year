﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace test1
{
    public partial class Course_Info : Form
    {
        public Course_Info()
        {
            InitializeComponent();
        }

        public Add_Course Add_Course
        {
            get => default;
            set
            {
            }
        }

        public update_course_Info update_course_Info
        {
            get => default;
            set
            {
            }
        }

        public Add_Course Add_Course1
        {
            get => default;
            set
            {
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.dataGridView1.DataSource = Login.Query("select * from v_course ").Tables[0];
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Add_Course CourseFrom_add = new Add_Course();
            CourseFrom_add.Owner = this;
            CourseFrom_add.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            int a = dataGridView1.CurrentRow.Index;
            string cno = dataGridView1.Rows[a].Cells[0].Value.ToString().Trim();
            string sql = "delete from course where courseNo='" + cno + "'";

            if (Login.ExecuteSql(sql) > 0)
            {
                MessageBox.Show("删除成功");
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            update_course_Info courseFrom_update = new update_course_Info();
            courseFrom_update.Owner = this;
            courseFrom_update.Show();
        }
    }
}
