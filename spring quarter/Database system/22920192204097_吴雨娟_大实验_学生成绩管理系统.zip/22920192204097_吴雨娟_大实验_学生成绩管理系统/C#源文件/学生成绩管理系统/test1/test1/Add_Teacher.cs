﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace test1
{
    public partial class Add_Teacher : Form
    {
        public Add_Teacher()
        {
            InitializeComponent();
            comboBox1.Items.Add("男");
            comboBox1.Items.Add("女");
            comboBox2.Items.Add("助教");
            comboBox2.Items.Add("讲师");
            comboBox2.Items.Add("副教授");
            comboBox2.Items.Add("教授");

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void Add_Teacher_Load(object sender, EventArgs e)
        {

        }

        private void button6_Click(object sender, EventArgs e)
        {
            string tid = textBox1.Text;
            string name = textBox2.Text;
            string sex = comboBox1.Text;
            string title = comboBox2.Text;
            bool ssex;
            if (sex == "男")
                ssex = false;
            else
                ssex = true;
            int ttitle;
            if (title == "助教")
                ttitle = 0;
            else if (title == "讲师")
                ttitle = 1;
            else if (title == "副教授")
                ttitle = 2;
            else
                ttitle = 3;

            int f = 1;
            string sql1 = "insert into usertable values('" + tid + "','" + tid + "','" + f + "')";
            if (name == "" || sex == "" || title == "" || tid == "")
            {
                MessageBox.Show("新增教师信息中不能包含空值！");
            }
            else
                Login.ExecuteSql(sql1);

            string sql2 = "insert into teacher values('" + tid + "','" + tid + "','" + name + "','" + ssex + "','" + ttitle + "')";

            if (Login.ExecuteSql(sql2) > 0)
            {
                MessageBox.Show("添加成功");
            }
            this.Close();
        }
    }
}
