﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace test1
{
    public partial class Admin : Form
    {
        string Userid;
        string AdminId;
        public Admin(string userid)
        {
            Userid = userid;
            InitializeComponent();
            string sql = "select * from v_admin where userid = '" + Userid + "';";
            DataSet ds = Login.Query(sql);
            DataTable dt = ds.Tables[0];
            label2.Text = dt.Rows[0][1].ToString();    //工号
            label4.Text = dt.Rows[0][2].ToString();    //姓名
        }

        public Stu_Info Stu_Info
        {
            get => default;
            set
            {
            }
        }

        public Teach_Info Teach_Info
        {
            get => default;
            set
            {
            }
        }

        public Course_Info Course_Info
        {
            get => default;
            set
            {
            }
        }

        public Grade_Info Grade_Info
        {
            get => default;
            set
            {
            }
        }

        public Update_Password Update_Password
        {
            get => default;
            set
            {
            }
        }

        public Grade_Info Grade_Info1
        {
            get => default;
            set
            {
            }
        }

        private void Form2_Load(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)      //修改密码
        {
            Update_Password adminform = new Update_Password(Userid);
            adminform.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Stu_Info stu_infoForm = new Stu_Info();
            stu_infoForm.Owner = this;
            stu_infoForm.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Teach_Info teach_infoForm = new Teach_Info();
            teach_infoForm.Owner = this;
            teach_infoForm.Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Course_Info course_infoForm = new Course_Info();
            course_infoForm.Owner = this;
            course_infoForm.Show();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Grade_Info grade_infoForm = new Grade_Info();
            grade_infoForm.Owner = this;
            grade_infoForm.Show();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }
    }
}
