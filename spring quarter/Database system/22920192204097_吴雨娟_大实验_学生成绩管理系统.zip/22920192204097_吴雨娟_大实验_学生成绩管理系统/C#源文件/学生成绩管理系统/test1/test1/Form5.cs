﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace test1
{
    public partial class Form5 : Form
    {
        static string connectionString = System.Configuration.ConfigurationManager.AppSettings["connectionString"];
        string Userid;
        public Form5(string userid)
        {
            Userid = userid;
            InitializeComponent();
            string sql = "select * from v_teacher where userid = '" + Userid + "';";
            DataSet ds = Login.Query(sql);
            DataTable dt = ds.Tables[0];
            label5.Text = dt.Rows[0][0].ToString();
            label6.Text = dt.Rows[0][2].ToString();
            label7.Text = dt.Rows[0][3].ToString();
            label8.Text = dt.Rows[0][4].ToString();
        }

        public Form6 change_key
        {
            get => default;
            set
            {
            }
        }

        public Form8 query_student
        {
            get => default;
            set
            {
            }
        }

        public Form7 insert_grade
        {
            get => default;
            set
            {
            }
        }

        public Form9 query_grade
        {
            get => default;
            set
            {
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form6 childrenForm = new Form6();
            childrenForm.Owner = this;
            childrenForm.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Form8 childrenForm = new Form8();
            childrenForm.Owner = this;
            childrenForm.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form7 childrenForm = new Form7();
            childrenForm.Owner = this;
            childrenForm.Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Form9 childrenForm = new Form9();
            childrenForm.Owner = this;
            childrenForm.Show();
        }
    }
}
