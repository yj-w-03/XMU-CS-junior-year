from gpiozero import Button,LED,PWMLED
from time import sleep
import numpy as np

button=Button(12,False,bounce_time=0.1)
LED_R=PWMLED(17)
LED_G=PWMLED(27)
LED_B=PWMLED(22)
flag=0

def light_on(color):
    global flag
    if flag:
        print("breath in")
        for i in np.arange(0,1,0.1):
            color.value=i
            sleep(0.1)
            #每次要变换颜色深浅的时候都要进行判断
            if button.is_pressed:
                LED_R.value=0
                LED_G.value=0
                LED_B.value=0
                print("stop")
                flag=0
                break



def light_off(color):
    global flag
    if flag:
        print("breath out")
        for i in np.arange(0,1,0.1):
            color.value=1-i
            sleep(0.1)
            #每次要变换颜色深浅的时候都要进行判断
            if button.is_pressed:
                LED_R.value=0
                LED_G.value=0
                LED_B.value=0
                print("stop")
                flag=0
                break
        #清零，避免颜色重叠
        color.value=0


while True:
    flag=1
    if button.is_pressed:
        print("start")
        sleep(0.1)
        while flag:
            light_on(LED_R)
            light_off(LED_R)
            light_on(LED_G)
            light_off(LED_G)
            light_on(LED_B)
            light_off(LED_B)

    sleep(0.2)


