#coding:utf-8
from flask import Flask, render_template , request
import RPi.GPIO as GPIO
from gpiozero import MCP3008
import time
import json
#temperature = 0
adc=MCP3008(channel=0)

def convert_temp(value):
    return (value*3.3-0.5)*100

def get_temp():
    temp=convert_temp(adc.value)
    # 向控制台打印结果
    # temp=25
    print ("温度值为: %.3f" %temp)
    # 返回温度值
    return temp


app = Flask(__name__)
@app.route('/',methods=['GET','POST'])
def index():

    return render_template('DTHweb.html')

@app.route('/echarts')
def echarts():
    i = 0
    result=[]
    while True:
        time.sleep(1)
        result.append(get_temp())
        i+=1
        if(i==10):
            break

    print(result)
    content = json.dumps(result)
    #resp = Response_headers(content)
    return content


if __name__=='__main__':
    app.run(debug=True)