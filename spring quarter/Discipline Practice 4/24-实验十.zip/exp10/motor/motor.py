import logging
from flask import Flask, request, render_template                                 
from flask_restful import Resource, Api, reqparse, inputs                           
from gpiozero import PWMLED, Device                                                 
from gpiozero.pins.pigpio import PiGPIOFactory
from gpiozero import AngularServo


# Initialize Logging
logging.basicConfig(level=logging.WARNING)  # Global logging configuration
logger = logging.getLogger('main')  # Logger for this module
logger.setLevel(logging.INFO) # Debugging for this file.




# Flask & Flask-RESTful instance variables
app = Flask(__name__) # Core Flask app.                                             
api = Api(app) # Flask-RESTful extension wrapper                                   


# Global variables
servo = AngularServo(18, min_angle=0, max_angle=180)
GPIO_PIN = 18
state = {                                                                          
    'level': 45 # % brightless of LED.
}

"""
GPIO Related Functions
"""
def init_motor():
    """Create and initialise an PWMLED Object"""
    servo.angle = state['level']                                               


"""
Flask & Flask-Restful Related Functions
"""

# @app.route applies to the core Flask instance (app).
# Here we are serving a simple web page.
@app.route('/', methods=['GET'])                                                   
def index():
    """Make sure inde.html is in the templates folder
    relative to this Python file."""
    return render_template('index_api_client.html', pin=GPIO_PIN)             


# Flask-restful resource definitions.
# A 'resource' is modeled as a Python Class.
class motorControl(Resource):  

    def __init__(self):
        self.args_parser = reqparse.RequestParser()                                

        self.args_parser.add_argument(
            name='level',  # Name of arguement
            required=True,  # Mandatory arguement
            type=inputs.int_range(0, 180),  # Allowed range 0..100                
            help='Set Angle {error_msg}',
            default=None)


    def get(self):
        """ Handles HTTP GET requests to return current motor state."""
        return state  


    def post(self):
        """Handles HTTP POST requests to set Angle."""
        global state                                                                

        args = self.args_parser.parse_args()                                       

        # Set PWM duty cycle to adjust brightness level.
        state['level'] = args.level                                                
        servo.angle = state['level']                                          
        logger.info("Angle is " + str(state['level']))

        return state                                                                


# Initialise Module.
init_motor()
# Register Flask-RESTful resource and mount to server end point /led
api.add_resource(motorControl, '/motor')                                                


if __name__ == '__main__':
    app.run(debug=True)                                           
