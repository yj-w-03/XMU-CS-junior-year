import cv2
import numpy as np
from PIL import Image
import os

# 设置训练图片的路径来源
path = 'dataset'

# 使用了LBPH人脸识别器
recognizer = cv2.face.LBPHFaceRecognizer_create()
detector = cv2.CascadeClassifier("haarcascade_frontalface_default.xml")

# 定义函数用于对人脸照片数据进行处理
def getImagesAndLabels(path):

    imagePaths = [os.path.join(path,f) for f in os.listdir(path)]     
    faceSamples=[]
    ids = []

    for imagePath in imagePaths:

        PIL_img = Image.open(imagePath).convert('L') # 转化为灰度图
        img_numpy = np.array(PIL_img,'uint8')

        id = int(os.path.split(imagePath)[-1].split(".")[1])
        faces = detector.detectMultiScale(img_numpy)

        for (x,y,w,h) in faces:
            faceSamples.append(img_numpy[y:y+h,x:x+w])
            ids.append(id)

    return faceSamples,ids

print ("\n [INFO] Training faces. It will take a few seconds. Wait ...")

# 抽取dataset目录中的照片，返回两个数组faces和ids
faces,ids = getImagesAndLabels(path)

# 对人脸识别器进行训练
recognizer.train(faces, np.array(ids))

# 将训练好的模型存储在trainer文件夹中并命名为trainer.yml
recognizer.write('trainer/trainer.yml') 

# 输出在此次训练中用到了几个人的数据
print("\n [INFO] {0} faces trained. Exiting Program".format(len(np.unique(ids))))
