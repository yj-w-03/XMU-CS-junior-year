import cv2
import numpy as np
import os 

# File: lab_cputemp.py
#向OneNET平台已经创建的数据流发送数据点
import urllib.request
import requests
import json
import time
import datetime
from gpiozero import MCP3008
from time import sleep

import numpy as np


APIKEY = 'Jf2d3LxMgq87oy5BC=wYH8h9lBI='  #改成你的APIKEY,需要在设备里创建
adc=MCP3008(channel=0)

recognizer = cv2.face.LBPHFaceRecognizer_create()
recognizer.read('trainer/trainer.yml')
cascadePath = "haarcascade_frontalface_default.xml"
faceCascade = cv2.CascadeClassifier(cascadePath);

font = cv2.FONT_HERSHEY_SIMPLEX

# 初始化
id = 0

# 将人的ID与名字进行关联
names = ['cjz', 'pb', 'lsz', 'zjl', 'jjx'] 

# 抓取此时摄像头拍到的情景
cam = cv2.VideoCapture(0)
cam.set(3, 640) # 设置视频信息
cam.set(4, 480) 

# 设置人脸的最小规格
minW = 0.1*cam.get(3)
minH = 0.1*cam.get(4)


while True:

    ret, img =cam.read()
    cv2.imshow('camera',img) 
    cv2.imwrite('test.jpg',img)
    state = ""

    gray = cv2.cvtColor(img,cv2.COLOR_BGR2GRAY)

    faces = faceCascade.detectMultiScale( 
        gray,
        scaleFactor = 1.2,
        minNeighbors = 5,
        minSize = (int(minW), int(minH)),
       )

    for(x,y,w,h) in faces:

        cv2.rectangle(img, (x,y), (x+w,y+h), (0,255,255), 2)

        id, confidence = recognizer.predict(gray[y:y+h,x:x+w])

        # 检查该人脸是否与数据库内的人脸数据有足够高的匹配度
        # （100-confidence）为此时的匹配度百分比
        if (confidence < 30):
            id = names[id]
            state = "The current state is safe."
            confidence = "  {0}%".format(round(100 - confidence))
        else:
            id = "unknown"
            state = "Illegal intrusion!"
            confidence = "  {0}%".format(round(100 - confidence))
        
        cv2.putText(img, str(id), (x+5,y-5), font, 1, (0,255,255), 2)
        pName = str(id)
        # 将 confidence的值更新为(100-confidence)
        # 在终端中输出识别出的人脸的ID和对应的匹配度
        print("The person id is %s.\n"%pName)
        cv2.putText(img, str(confidence), (x+5,y+h-5), font, 1, (0,255,255), 1)  
        print("The confidence is %s.\n"%str(confidence))
        #cv2.imwrite("test.jpg", gray[y:y+h,x:x+w])
        #cv2.imwrite("test.jpg", img)
    
    #cv2.imshow('camera',img) 

    # 连接到OneNET
    CurTime = datetime.datetime.now()
    urll='http://api.heclouds.com/devices/949655139/datapoints'  #用于传输id和信息
    url='http://api.heclouds.com/bindata'  #用于实时传输图片
    #传输id
    values={'datastreams':[{"id":"pName","datapoints":[{"at":CurTime.isoformat(),"value":str(id)}]}]}
    #传输信息
    values2={'datastreams':[{"id":"monitor","datapoints":[{"at":CurTime.isoformat(),"value":state}]}]}
    print ("当前的ISO时间为： %s" %CurTime.isoformat())
    print ("当前人脸为: %s" %str(id))

    jdata = json.dumps(values)  # 对数据进行JSON格式化编码，生成的是字符串
    # 打印json内容
    print (jdata)
    data11 = bytes(jdata, 'utf-8')

    jdata2 = json.dumps(values2)  # 对数据进行JSON格式化编码，生成的是字符串
    # 打印json内容
    print (jdata2)
    data22 = bytes(jdata2, 'utf-8')
    

    headers = {
        #"Content-Type": "image/jpg", # 
        "api-key": APIKEY, # 你的APIKEY
    }
    #传输图片
    params = {"device_id": "949655139", "datastream_id": "img"}
    fp=open('test.jpg','rb')
    imgg = fp.read()

    request = urllib.request.Request(urll, data11)
    request.add_header('api-key', APIKEY)
    request.get_method = lambda:'POST'  # 设置HTTP的访问方式
    request = urllib.request.urlopen(request)


    request2 = urllib.request.Request(urll, data22)
    request2.add_header('api-key', APIKEY)
    request2.get_method = lambda:'POST'  # 设置HTTP的访问方式
    request2 = urllib.request.urlopen(request2)
    
    #rr=requests.post(url,params=params,data=str(id),headers=headers)
    #print(rr.status_code)
    #print(rr.content)
    
    r=requests.post(url,params=params,data=imgg,headers=headers)
    print(r.status_code)
    print(r.content)
    
    fp.close()
    
#    if cv2.waitKey(1) & 0xFF == ord("q"):
#            break

# 清理
print("\n [INFO] Exiting Program and cleanup stuff")
cam.release()
cv2.destroyAllWindows()
