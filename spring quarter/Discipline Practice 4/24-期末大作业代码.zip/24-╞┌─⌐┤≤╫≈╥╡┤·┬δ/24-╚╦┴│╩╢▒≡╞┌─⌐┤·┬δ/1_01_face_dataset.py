import cv2
import os

cam = cv2.VideoCapture(0)
cam.set(3, 640) # 设置视频信息
cam.set(4, 480) 

#加载分类器
face_detector = cv2.CascadeClassifier('haarcascade_frontalface_default.xml')

# 对于每一个人，输入一个数字作为它对应的ID
face_id = input('\n enter user id end press <return> ==>  ')

# 提醒用户看镜头，进行人脸信息收集
print("\n [INFO] Initializing face capture. Look the camera and wait ...")

count = 0 # 初始化

while(True):

    ret, img = cam.read()
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    # 调用分类器函数，设置参数
    faces = face_detector.detectMultiScale(gray, 1.3, 5)

    for (x,y,w,h) in faces:
        
        # 设置方框对人脸进行跟踪标记
        cv2.rectangle(img, (x,y), (x+w,y+h), (0,255,255), 2)     
        count += 1

        # 保存拍摄取样的图片于dataset文件夹中
        cv2.imwrite("dataset/User." + str(face_id) + '.' + str(count) + ".jpg", gray[y:y+h,x:x+w])

        cv2.imshow('image', img)

    k = cv2.waitKey(100) & 0xff # 使用‘ESC’可以强制退出
    if k == 27:
        break
    elif count >= 30: # 对于每一个人，拍摄取样30张照片
         break

# 清除
print("\n [INFO] Exiting Program and cleanup stuff")
cam.release()
cv2.destroyAllWindows()


