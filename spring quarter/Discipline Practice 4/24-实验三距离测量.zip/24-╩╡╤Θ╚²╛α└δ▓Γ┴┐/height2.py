from gpiozero import DistanceSensor, LED
from signal import pause
from time import sleep

sensor = DistanceSensor(23, 24, max_distance = 1, threshold_distance = 0.05)
led = LED(16)

while True:
    print('Distance to nearest object is', sensor.distance, 'm')
    sleep(1)
    sensor.when_in_range = led.on
    sensor.when_out_of_range = led.off

pause()