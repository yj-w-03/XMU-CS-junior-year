from gpiozero import LineSensor
from signal import pause
import time

start=0
end=0
num=0

def fun1():
    print("Line detected")
    global num
    global start
    global end
    if num==0:
        start=time.time()
        print("start time is %f\n"%(start))
    else:
        end=time.time()
        speed=num*1.0/(end-start)
        print("The average speed of the round is %f round/s \n"%(speed))
        
    num+=1

def fun2():
    return


sensor=LineSensor(4)
sensor.when_line=fun1
sensor.when_no_line=fun2
pause()



