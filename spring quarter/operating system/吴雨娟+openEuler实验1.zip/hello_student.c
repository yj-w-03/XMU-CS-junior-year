/* Hello from Kernel! */
#include <linux/module.h>
#include <linux/string.h>
MODULE_LICENSE("GPL");
static char* id = "1234";
module_param(id, charp, 0644);
MODULE_PARM_DESC(id, "char* param\n");
static char* name = "Apple";
module_param(name, charp, 0644);
MODULE_PARM_DESC(name, "char* param\n");
static int age = 22;
module_param(age, int, 0644);
MODULE_PARM_DESC(age, "int param\n");

void hello_student(char* id, char* name, int age)
{
	printk(KERN_ALERT "My name is %s, student id is %s. I am %d years old.\n", name, id,age);
}

void calculate(char* id)
{
	int len=strlen(id);
	long a=simple_strtol(id,NULL,10);
	long temp=a;
	long b=0;
	int i=0;
	int num[40];
	int j;
	while(temp){
		num[i++]=temp%10;
		temp/=10;
	}
	for(j=0;j<len;j++){
		b=b*10+num[j];
	}
	long answer=a+b;
	printk(KERN_ALERT "My answer is %ld.\n", answer);
}

int __init hello_init(void)
{
	printk(KERN_ALERT "Init module.\n");
	hello_student(id, name, age);
	calculate(id);
	return 0;
}

void __exit hello_exit(void)
{
	printk(KERN_ALERT "Exit module.\n");
}

module_init(hello_init);
module_exit(hello_exit);