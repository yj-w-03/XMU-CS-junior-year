#include "File.h"
#include "Disk.h"

#include <string.h>
#include <stdio.h>
#include <stdlib.h>


dirTable *rootDirTable; //根目录
dirTable *currentDirTable;  //当前位置
char path[200]; //保存当前绝对路径

//初始化根目录
void initRootDir() {
    //分配一个盘块空间给rootDirTable
    int startBlock = getBlock(1);
    char parent[] = "..";
    if (startBlock == -1)
        return;
    rootDirTable = (dirTable *) getBlockAddr(startBlock);
    rootDirTable->dirUnitAmount = 0;
    //仿照Linux，设置根目录的父目录仍为根目录
    addDirUnit(rootDirTable, parent, 0, startBlock);
    currentDirTable = rootDirTable;
    //初始化初始绝对路径
    path[0] = '/';
    path[1] = '\0';
}


//获得当前绝对路径
char *getPath() {
    return path;
}


//展示当前目录 ls
void showDir() {
    int unitAmount = currentDirTable->dirUnitAmount;
    printf("total:%d\n", unitAmount);
    printf("name\ttype\tsize\tFCB\tdataStartBlock\n");
    //遍历所有表项
    for (int i = 0; i < unitAmount; i++) {
        //获取目录项
        dirUnit unitTemp = currentDirTable->dirs[i];
        printf("%s\t%s\t", unitTemp.fileName, unitTemp.type == 0 ? "dir" : "file");
        //该表项是文件，继续输出大小和起始盘块号
        if (unitTemp.type == 1) {
            int FCBBlock = unitTemp.startBlock;
            FCB *fileFCB = (FCB *) getBlockAddr(FCBBlock);
            printf("%d\t%d\t%d\n", fileFCB->fileSize, FCBBlock, fileFCB->dataStartBlock);
        } else {
            int dirBlock = unitTemp.startBlock;
            dirTable *myTable = (dirTable *) getBlockAddr(dirBlock);
            printf("%d\t%d\t-\n", myTable->dirUnitAmount, unitTemp.startBlock);
        }
    }
}


//TODO 切换目录 cd
int changeDir(char dirName[])
{
    //目录项在目录位置
    int unitIndex = findUnitInTable(currentDirTable, dirName);

    //文件名不存在
    if (unitIndex == -1) {
        printf("directory not found\n");
        return -1;
    }

    //不是目录类型
    if(currentDirTable->dirs[unitIndex].type != 0){
        printf("Not a directory\n");
    }

    //修改当前目录(currentDirTable)
    int startBlock = currentDirTable->dirs[unitIndex].startBlock;
    currentDirTable = (dirTable *) getBlockAddr(startBlock);

    //修改全局绝对路径(path)
    char parent[] = "..";
    if(strcmp(dirName,parent) == 0){ // 回到父目录下
        int len = strlen(path);
        if(len == 1) return 0; // 根目录回到父目录，仍是根目录，不用修改path，直接返回即可
        path[len-1] = '\0'; // 先去掉绝对路径末尾的'/'
        for(int i=len-2; i>=0 ; i--){
            if(path[i] == '/' ){ // 遇到'/'时，表示绝对路径删除结束
                break;
            }
            else if(path[i] != '/'){ //未遇到'/'，继续删
                path[i] = '\0';
            }
        }
    }
    else{ // 去子目录下
        int len = strlen(path);
        strcpy(path+len, dirName);
        len = strlen(path);
        path[len++] = '/';
    }

    return 0;
}


//TODO 修改文件名或者目录名 rn
int changeName(char oldName[], char newName[])
{
    // 在目录表中找到该文件或目录所在的目录项
    int unitIndex = findUnitInTable(currentDirTable, oldName);
    if (unitIndex == -1) {
        printf("file not found\n");
        return -1;
    }
    // 修改名字
    strcpy(currentDirTable->dirs[unitIndex].fileName, newName);

    return 0;
}

//创建文件 touch
int creatFile(char fileName[], int fileSize) {
    //检测文件名字长度
    if (strlen(fileName) >= FILENAME_MAX_LENGTH) {
        printf("file name too long\n");
        return -1;
    }
    //获得FCB的空间
    int FCBBlock = getBlock(1);
    if (FCBBlock == -1)
        return -1;
    //获取文件数据空间
    int FileBlock = getBlock(fileSize);
    if (FileBlock == -1)
        return -1;
    //创建FCB
    if (creatFCB(FCBBlock, FileBlock, fileSize) == -1)
        return -1;
    //添加到目录项
    if (addDirUnit(currentDirTable, fileName, 1, FCBBlock) == -1)
        return -1;
    return 0;
}


//TODO 创建目录 mkdir
int creatDir(char dirName[])
{
    //检测文件名字长度
    if (strlen(dirName) >= FILENAME_MAX_LENGTH) {
        printf("directory name too long\n");
        return -1;
    }

    //为目录表分配空间
    int startBlock = getBlock(1);
    if (startBlock == -1)
        return -1;
    dirTable *newDirTable = (dirTable *) getBlockAddr(startBlock);
    newDirTable->dirUnitAmount = 0; // 初始化新目录表的目录项数为0

    //将目录作为目录项添加到当前目录
    addDirUnit(currentDirTable, dirName, 0, startBlock);

    //为新建的目录添加一个到父目录的目录项
    char parent[] = "..";
    addDirUnit(newDirTable, parent, 0, getAddrBlock((char *)currentDirTable));

    return 0;
}


//创建FCB
int creatFCB(int fcbdataStartBlock, int filedataStartBlock, int fileSize) {
    //找到fcb的存储位置
    FCB *currentFCB = (FCB *) getBlockAddr(fcbdataStartBlock);
    currentFCB->dataStartBlock = filedataStartBlock;//文件数据起始位置
    currentFCB->fileSize = fileSize;//文件大小
    currentFCB->link = 1;//文件链接数
    currentFCB->dataSize = 0;//文件已写入数据长度
    currentFCB->readPtr = 0;//文件读指针
    currentFCB->read_sem = sem_open("read_sem", O_CREAT, 0644, READER_MAX_NUM);
    if (currentFCB->read_sem == SEM_FAILED) {
        perror("sem_open error");
        exit(1);
    }
    currentFCB->write_sem = sem_open("write_sem", O_CREAT, 0644, 1);
    if (currentFCB->write_sem == SEM_FAILED) {
        perror("sem_open error");
        exit(1);
    }
    currentFCB->read_sem2 = sem_open("read_sem2", O_CREAT, 0644, 1);
    if (currentFCB->read_sem2 == SEM_FAILED) {
        perror("sem_open error");
        exit(1);
    }
    return 0;
}


//TODO 添加目录项
int addDirUnit(dirTable* myDirTable, char fileName[], int type, int FCBBlockNum)
{
    //检测目录表示是否已满
    if (myDirTable->dirUnitAmount >= DIR_TABLE_MAX_SIZE) {
        printf("dir table is full\n");
        return -1;
    } 
    
    //是否存在同名文件
    int unitIndex = findUnitInTable(myDirTable, fileName);
    if(unitIndex != -1){
        printf("duplicate naming\n");
        return -1;
    }
    
    //构建新目录项
    int nowposition = myDirTable->dirUnitAmount;
    myDirTable->dirs[nowposition].type = type;
    myDirTable->dirs[nowposition].startBlock = FCBBlockNum;
    strcpy(myDirTable->dirs[nowposition].fileName, fileName);
    myDirTable->dirUnitAmount++; // 目录表下的目录项数加1

    return 0;

}


//TODO 删除文件 rm
int deleteFile(char fileName[])
{
    //忽略系统的自动创建的父目录
    if (strcmp(fileName, "..") == 0) {
        printf("can't delete ..\n");
        return -1;
    }

    //查找文件的目录项位置
    int unitIndex = findUnitInTable(currentDirTable, fileName);
    if (unitIndex == -1) {
        printf("file not found\n");
        return -1;
    }
    dirUnit myUnit = currentDirTable->dirs[unitIndex];

    //若文件类型为目录，则返回错误
    if (myUnit.type == 0)//目录
    {
        printf("not a file\n");
        return -1;
    } 

    //释放文件内存
    deleteFileInTable(currentDirTable, unitIndex);

    //从目录表中剔除
    deleteDirUnit(currentDirTable, unitIndex);

    return 0;
}


//释放文件内存
int releaseFile(int FCBBlock) {
    FCB *myFCB = (FCB *) getBlockAddr(FCBBlock);
    myFCB->link--;  //链接数减一
    //无链接，删除文件
    if (myFCB->link == 0) {
        //释放文件的数据空间
        releaseBlock(myFCB->dataStartBlock, myFCB->fileSize);
    }
    //释放FCB的空间
    sem_close(myFCB->read_sem);
    sem_close(myFCB->write_sem);
    sem_close(myFCB->read_sem2);
    sem_unlink("read_sem");
    sem_unlink("write_sem");
    sem_unlink("read_sem2");
    //释放FCB空间
    releaseBlock(FCBBlock, 1);
    return 0;
}

//删除目录项
int deleteDirUnit(dirTable *myDirTable, int unitIndex) {
    //迁移覆盖
    int dirUnitAmount = myDirTable->dirUnitAmount;
    for (int i = unitIndex; i < dirUnitAmount - 1; i++) {
        myDirTable->dirs[i] = myDirTable->dirs[i + 1];
    }
    myDirTable->dirUnitAmount--;
    return 0;
}


//删除目录 rmdir
int deleteDir(char dirName[]) {
    //忽略系统的自动创建的父目录
    if (strcmp(dirName, "..") == 0) {
        printf("can't delete ..\n");
        return -1;
    }
    //查找文件
    int unitIndex = findUnitInTable(currentDirTable, dirName);
    if (unitIndex == -1) {
        printf("file not found\n");
        return -1;
    }
    dirUnit myUnit = currentDirTable->dirs[unitIndex];
    //判断类型
    if (myUnit.type == 0)//目录
    {
        deleteFileInTable(currentDirTable, unitIndex);
    } else {
        printf("not a dir\n");
        return -1;
    }
    //从目录表中剔除
    deleteDirUnit(currentDirTable, unitIndex);
    return 0;
}


//删除文件/目录项
int deleteFileInTable(dirTable *myDirTable, int unitIndex) {
    //查找文件
    dirUnit myUnit = myDirTable->dirs[unitIndex];
    //判断类型
    if (myUnit.type == 0)//目录
    {
        //找到目录位置
        int FCBBlock = myUnit.startBlock;
        dirTable *table = (dirTable *) getBlockAddr(FCBBlock);
        //递归删除目录下的所有文件
        printf("cycle delete dir %s\n", myUnit.fileName);
        int unitCount = table->dirUnitAmount;
        for (int i = 1; i < unitCount; i++)//忽略“..”
        {
            printf("delete %s\n", table->dirs[i].fileName);
            deleteFileInTable(table, i);
        }
        //释放目录表空间
        releaseBlock(FCBBlock, 1);
    } else {//文件
        //释放文件内存
        int FCBBlock = myUnit.startBlock;
        releaseFile(FCBBlock);
    }
    return 0;
}


//打开文件，获得控制块
FCB *open(char fileName[]) {
    int unitIndex = findUnitInTable(currentDirTable, fileName);
    if (unitIndex == -1) {
        printf("file not found\n");
        return NULL;
    }
    //控制块
    int FCBBlock = currentDirTable->dirs[unitIndex].startBlock;
    FCB *myFCB = (FCB *) getBlockAddr(FCBBlock);
    return myFCB;
}


//读文件
int read_file(char fileName[], int length) {
    //打开文件，获得控制块
    FCB *myFCB = open(fileName);
    myFCB->readPtr = 0; //文件指针重置
    //读数据
    char *data = (char *) getBlockAddr(myFCB->dataStartBlock);
    int val;
    myFCB->read_sem = sem_open("read_sem", 0);
    /* 获取记录读者数量的锁 */
    myFCB->read_sem2 = sem_open("read_sem2", 0);
    sem_wait(myFCB->read_sem2);
    if (sem_wait(myFCB->read_sem) == -1)
        perror("sem_wait error");
    sem_getvalue(myFCB->read_sem, &val);
    /* 根据拥有锁的进程数量来判断是否是第一个读者 */
    /* 如果是第一个读者就负责锁上写者锁 */
    if (val == READER_MAX_NUM - 1) {
        myFCB->write_sem = sem_open("write_sem", 0);
        if (sem_wait(myFCB->write_sem) == -1)
            perror("sem_wait error");
    }
    sem_post(myFCB->read_sem2);
    int dataSize = myFCB->dataSize;
    /* printf("myFCB->dataSize = %d\n", myFCB->dataSize); */
    //在不超出数据长度下，读取指定长度的数据
    for (int i = 0; i < length && myFCB->readPtr < dataSize; i++, myFCB->readPtr++) {
        printf("%c", *(data + myFCB->readPtr));
    }
    /* 下面两行只是为了模拟编辑器的关闭之前的情况， */
    /* 这样就能控制进程不会立即释放锁 */
    printf("\n> Read finished, press any key to continue....");
    getchar();
    /* 如果是最后一个读者就负责释放写者锁 */
    //这里进行了更改，旧：READER_MAX_NUM；新：READER_MAX_NUM-1 By. LeoHao
    sem_wait(myFCB->read_sem2);
    if (val == READER_MAX_NUM - 1) {
        sem_post(myFCB->write_sem);
    }
    sem_post(myFCB->read_sem);
    sem_post(myFCB->read_sem2);
    return 0;
}

//TODO 写文件，从末尾写入 write
int write_file(char fileName[], char content[])
{
    //获得控制块
    FCB *myFCB = open(fileName);
    
    /* 获得写者锁 */
    sem_wait(myFCB->write_sem);

    //在不超出文件的大小的范围内写入
    char *data = (char *) getBlockAddr(myFCB->dataStartBlock); // 获得文件数据盘块的起始物理地址
    int dataSize = myFCB->dataSize; // 记录当前已写的长度
    int fileSize = myFCB->fileSize * block_size; //文件大小，字节为单位

    // 写入长度是待写入内容的长度和文件剩余长度中的最小值，确保在不超出文件的大小的范围内写入
    int len;
    if(strlen(content) < fileSize - dataSize) len = strlen(content);
    else len = fileSize - dataSize;
    for(int i=0; i<len; i++){ // 从末尾写入
        *(data + dataSize + i) = content[i];
    }
    myFCB->dataSize += len; // 修改文件已写入的内容大小，确保下次写入时从文件已写入内容的末尾写入

    /* 模拟编辑器,控制写者不立即退出 */
    printf("> Write finished, press any key to continue....");
    getchar();
    /* 释放写者锁 */
    sem_post(myFCB->write_sem);

    return 0;
}


//从目录中查找目录项目
int findUnitInTable(dirTable *myDirTable, char unitName[]) {
    //获得目录表
    int dirUnitAmount = myDirTable->dirUnitAmount;
    int unitIndex = -1;
    for (int i = 0; i < dirUnitAmount; i++)//查找目录项位置
        if (strcmp(unitName, myDirTable->dirs[i].fileName) == 0)
            unitIndex = i;
    return unitIndex;
}