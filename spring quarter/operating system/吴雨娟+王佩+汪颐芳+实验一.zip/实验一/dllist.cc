#include <stdlib.h>
#include <stdio.h> 
#include "dllist.h"
#include "system.h"

extern int errortype;

DLLElement::DLLElement(void *itemPtr, int sortKey)
{
	item = itemPtr;
	key = sortKey;
	next = prev = NULL;
}

DLList::DLList() // initialize the dllist
{
    first = last = NULL;
}

DLList::~DLList() // de-allocate the dllist
{
    while (IsEmpty())  // IsEmpty() return true if dllist has elements
        Remove(NULL);  // delete all elements
}

void
DLList::Prepend(void *item) // add to head of dllist (set key = min_key-1)
{
	DLLElement *element = new DLLElement(item, 0);
	
    if ( !IsEmpty() ) {	// dllist is empty
        first = last = element;
        element->prev = element->next = NULL;
    } 
    else {		// else put it before first
    	int min_key = first->key;
		element->key = min_key - 1;
        element->next = first;
        element->prev = NULL;
        first->prev = element;
        first = element;
    }
}

void
DLList::Append(void *item) // add to tail of dllist (set key = max_key+1)
{
	DLLElement *element = new DLLElement(item, 0);
	
    if ( !IsEmpty() ) {	// dllist is empty
        first = last = element;
        element->prev = element->next = NULL;
    }
    else {		// else put it after last
        int max_key = last->key; 
        element->key = max_key + 1;
    	element->prev = last;
    	element->next = NULL;
        last->next = element;
        last = element;
    }
}

void *
DLList::Remove(int* keyPtr) // remove from head of dllist
{
    if (errortype == 201) {
	    printf("----------Remove: switch!----------\n");
		currentThread->Yield();
	}
    DLLElement *element = first;
    void *res = NULL;
    if ( !IsEmpty() ) {	// dllist is empty
        if (errortype == 202) {
	        printf("----------Remove: switch!----------\n");
		    currentThread->Yield();
	    }
        keyPtr = NULL;
        if (errortype == 203) {
	        printf("----------Remove: switch!----------\n");
		    currentThread->Yield();
	    }
    }
    else {		// else put it after last
        if (errortype == 204) {
	        printf("----------Remove: switch!----------\n");
		    currentThread->Yield();
	    }
        *keyPtr = element->key;
        res = element->item;
        if (errortype == 205) {
	        printf("----------Remove: switch!----------\n");
		    currentThread->Yield();
	    }
        first = first->next;
        if (errortype == 206) {
	        printf("----------Remove: switch!----------\n");
		    currentThread->Yield();
	    }
        if (first == NULL){
            last = NULL;
        }
        else{
            first->prev = NULL;
        }
    }
    delete element;
    if (errortype == 207) {
	        printf("----------Remove: switch!----------\n");
		    currentThread->Yield();
	    }
    return res;
}

bool
DLList::IsEmpty() // return true if dllist has elements
{
    return !(first == NULL && last == NULL);
}

void
DLList::PrintDllist() // print the key of all the items in dllist
{
	printf("DLLIST: \n");
	if( IsEmpty() ) { // dllist is not empty
		for(DLLElement *dlptr = first; dlptr != NULL; dlptr = dlptr->next) {
			printf("%d ",dlptr->key);
		}
		printf("\n");
	}
	else {
		printf("The dllist is empty!\n");
	}
}

void
DLList::SortedInsert(void *item, int sortKey) // put items on dllist in order (sorted by key)
{
    DLLElement *element = new DLLElement(item, sortKey);
    DLLElement *dlptr;
    if (errortype == 101) {
	        printf("----------SortedInsert: switch!----------\n");
		    currentThread->Yield();
	    }
    if( !IsEmpty() ){ // dllist is empty,put the item on
        if (errortype == 102) {
	        printf("----------SortedInsert: switch!----------\n");
		    currentThread->Yield();
	    }
        first = last = element;
        if (errortype == 103) {
	        printf("----------SortedInsert: switch!----------\n");
		    currentThread->Yield();
	    }
        element->prev = element->next = NULL;
    }
    else if( sortKey < first->key ){ // put on the first
        if (errortype == 104) {
	        printf("----------SortedInsert: switch!----------\n");
		    currentThread->Yield();
	    }
        element->next = first;
        if (errortype == 105) {
	        printf("----------SortedInsert: switch!----------\n");
		    currentThread->Yield();
	    }
        element->prev = NULL;
        if (errortype == 106) {
	        printf("----------SortedInsert: switch!----------\n");
		    currentThread->Yield();
	    }
        first->prev = element;
        if (errortype == 107) {
	        printf("----------SortedInsert: switch!----------\n");
		    currentThread->Yield();
	    }
        first = element;
    }
    else if( sortKey > last->key ){ // put on the last
        if (errortype == 108) {
	        printf("----------SortedInsert: switch!----------\n");
		    currentThread->Yield();
	    }
        element->next = NULL;
        if (errortype == 109) {
	        printf("----------SortedInsert: switch!----------\n");
		    currentThread->Yield();
	    }
        element->prev = last;
        if (errortype == 110) {
	        printf("----------SortedInsert: switch!----------\n");
		    currentThread->Yield();
	    }
        last->next = element;
        if (errortype == 111) {
	        printf("----------SortedInsert: switch!----------\n");
		    currentThread->Yield();
	    }
        last = element;
    }
    else{
        for(dlptr = first; dlptr != NULL && dlptr->key < sortKey; dlptr = dlptr->next)
        ;
        if (errortype == 112) {
	        printf("----------SortedInsert: switch!----------\n");
		    currentThread->Yield();
	    }
        element->prev = dlptr->prev;
        if (errortype == 113) {
	        printf("----------SortedInsert: switch!----------\n");
		    currentThread->Yield();
	    }
        dlptr->prev = element;
        if (errortype == 114) {
	        printf("----------SortedInsert: switch!----------\n");
		    currentThread->Yield();
	    }
        element->next = dlptr;
        if (errortype == 115) {
	        printf("----------SortedInsert: switch!----------\n");
		    currentThread->Yield();
	    }
        element->prev->next = element;

    }
}

void*
DLList::SortedRemove(int sortKey) // remove first item with key==sortKey
{
    DLLElement *dlptr = first;
    void *res;
    if ( !IsEmpty() ) 
		return NULL;
    for(; dlptr != NULL && dlptr->key != sortKey; dlptr = dlptr->next)
    ;
    if(dlptr == first){
        first = first->next;
        first->prev = NULL;
    }
    else if(dlptr == last){
        last = last->prev;
        last->next = NULL;
    }
    else if(dlptr == NULL){
        return NULL;
    }
    else{
        dlptr->prev->next = dlptr->next;
        dlptr->next->prev = dlptr->prev;
    }
    res = dlptr->item;
    delete dlptr;
    return res;
}