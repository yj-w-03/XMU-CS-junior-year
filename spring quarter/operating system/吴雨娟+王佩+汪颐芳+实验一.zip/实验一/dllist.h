
#ifndef DLLIST_H
#define DLLIST_H

// The following class defines a "dllist element" -- which is
// used to keep track of one item on a dllist. 

class DLLElement {
public:
    DLLElement( void *itemPtr, int sortKey );

    DLLElement *next; // next element on dllist
                      // NULL if this is the last

    DLLElement *prev; // previous element on dllist
                      // NULL if this is the first

    int key; // priority, for a sorted dllist

    void *item; // pointer to item on the dllist
};

// The following class defines a "dllist" -- priority-sorted doubly linked list of
// list elements, each of which contains an integer. The doubly linked list keeps 
// items sorted according to an integer key.

class DLList {
  public:
	DLList();  // initialize the dllist
	~DLList(); // de-allocate the dllist

	void Prepend(void *item); // add to head of dllist (set key = min_key-1)
	void Append(void *item);  // add to tail of dllist (set key = max_key+1)
	
	void *Remove(int *keyPtr); // remove from head of dllist
			   			       // set *keyPtr to key of the removed item
					           // return item (or NULL if dllist is empty)

	bool IsEmpty();	// return true if dllist has elements
	
	void PrintDllist(); // print the key of all the items in dllist
					
	// routines to put/get items on/off dllist in order (sorted by key)
	void SortedInsert(void *item, int sortKey);
	void *SortedRemove(int sortKey); // remove first item with key==sortKey
									 // return NULL if no such item exists

  private:
	DLLElement *first; // head of the dllist, NULL if empty
	DLLElement *last;  // last element of the dllist, NULL if empty
};

#endif // DLLIST_H

