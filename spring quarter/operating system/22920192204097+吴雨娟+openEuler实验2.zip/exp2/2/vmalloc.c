#include <linux/module.h>
#include <linux/vmalloc.h>

MODULE_LICENSE("GPL");

unsigned char *vmallocmem1;
unsigned char *vmallocmem2;
unsigned char *vmallocmem3;
unsigned char *vmallocmem4;

int more_size=512*1024*1024+10;


static int __init mem_module_init(void)
{
    printk("Start vmalloc!\n");
    // vmalloc 1
    vmallocmem1 = (unsigned char*)vmalloc(65536);
    if (vmallocmem1 != NULL)
        printk(KERN_ALERT "vmallocmem1 addr = %lx\n", (unsigned long)vmallocmem1);
    else
        printk("Failed to allocate vmallocmem1!\n");
    
    // vmalloc2
    vmallocmem2 = (unsigned char*)vmalloc(1048576);
    if (vmallocmem2 != NULL)
        printk(KERN_ALERT "vmallocmem2 addr = %lx\n", (unsigned long)vmallocmem2);
    else
        printk("Failed to allocate vmallocmem2!\n");

    // vmalloc 3
    vmallocmem3 = (unsigned char*)vmalloc(67108864);
    if (vmallocmem3 != NULL)
        printk(KERN_ALERT "vmallocmem3 addr = %lx\n", (unsigned long)vmallocmem3);
    else
        printk("Failed to allocate vmallocmem3!\n");
    // free 1,2 and 3
    vfree(vmallocmem1);
    vfree(vmallocmem2);
    vfree(vmallocmem3);
    // vmalloc 4
    vmallocmem4 = (unsigned char*)vmalloc(more_size);
    if (vmallocmem4 != NULL)
        printk(KERN_ALERT "vmallocmem4 addr = %lx\n", (unsigned long)vmallocmem4);
    else
        printk("Failed to allocate vmallocmem4!\n");
    return 0;
}

static void __exit mem_module_exit(void)
{
    //TODO: ADD YOUR CODE HERE
    vfree(vmallocmem4);
    printk("Exit vmalloc!\n");
}

module_init(mem_module_init);
module_exit(mem_module_exit);