/* High-level overview: This works by maintaining a singly-linked list of previously-used memory segments that have been freed. */


#define NALLOC 2048 // 2^11

#include <stdio.h>
#include <errno.h>
#include <limits.h>
#include <string.h>
#include <unistd.h>

/* This header is stored at the beginning of memory segments in the list. */
union header {
  struct {
    union header *next;
    unsigned len;
  } meta;
  long x; /* Presence forces alignment of headers in memory. */
};

static union header list;
static union header *first = NULL;
static union header *head;

void print()
{
    printf("Each size of mem in list:\n");
    union header *tt;
    tt = first;
    printf("%d ",tt->meta.len);
    tt = tt->meta.next;
    while(tt != first){
        printf("%d ",tt->meta.len);
        tt = tt->meta.next;
    }
    printf("\n");
}

// to judge bro
int is_buddy(union header *now, union header *bro,int len)
{
  int p,q; 
  p=(int)(now-head);
  q=(int)(bro-head);
  if(((p % (len*2))==0 && p+len==q) || ((p % (len*2))==len && p-len==q)) return 1;
  else return 0;
}

// if has brother, continue to merge
void merge()
{
  union header *p,*q;
  p = first;
  q = first->meta.next;
  while(q!=first){
    if(is_buddy(p,q,p->meta.len) && p->meta.len == q->meta.len && (p + p->meta.len == q)){
      p->meta.len *= 2;
      p->meta.next = q->meta.next;
      // from head again
      p = first;
      q = first->meta.next;
    }
    else{
      p = q;
      q = q->meta.next;
    }
  }
  
}

void free(void* ptr) {
  if (ptr == NULL) {
    return;
  }

  union header *iter, *block;
  iter = first;
  block = (union header*)ptr - 1;

  /* Traverse to the spot in the list to insert the freed fragment,
   * such that the list is ordered by memory address (for coalescing). */
  while (block <= iter || block >= iter->meta.next) {
    if ((block > iter || block < iter->meta.next) &&
        iter >= iter->meta.next) {
      break;
    }
    iter = iter->meta.next;
  }


  if (is_buddy(block,iter->meta.next,block->meta.len) && block->meta.len==iter->meta.next->meta.len ) {// latter is brother
    block->meta.len += iter->meta.next->meta.len;
    block->meta.next = iter->meta.next->meta.next;
    merge(); // re-check from head
  } else {
    block->meta.next = iter->meta.next;
  }
  if (is_buddy(iter,block,iter->meta.len) && block->meta.len == iter->meta.len) {// pre is brother
    iter->meta.len += block->meta.len;
    iter->meta.next = block->meta.next;
    merge(); // re-check from head
  } else {
    iter->meta.next = block;
  }
  //first = iter;

  
  print();
}

void *buddy_malloc(size_t size) {
  union header *p, *prev;
  prev = first;
  unsigned true_size =
    (size + sizeof(union header) - 1) / sizeof(union header) + 1;
  
  /* If the list of previously allocated fragments is empty,
   * initialize it. */
  if (first == NULL) {
    prev = &list;
    first = prev;
    list.meta.next = first;
    list.meta.len = 0;
  }
  p = prev->meta.next;



  while (1) {
    if (p->meta.len >= true_size) {
      if (p->meta.len == true_size) {
        /* If the fragment is exactly the right size, we do not have
         * to split it. */
        prev->meta.next = p->meta.next;
      } else {
        while(p->meta.len/2 >= true_size){
            union header *latter;
            p->meta.len /= 2;
            latter = p + p->meta.len; 
            latter->meta.len = p->meta.len; 
            latter->meta.next = p->meta.next;
            p->meta.next = latter;
        }
        prev->meta.next = p->meta.next;
      }
      //first = prev;
      printf("\nThe true_size is : %d\n",true_size);
      print();
      return (void *)(p+1);
    }
    /* If we reach the beginning of the list, no satisfactory fragment
     * was found, so we have to request a new one. */
    if (p == first) {
      char *page;
      union header *block;
      /* We have to request memory of at least a certain size. */
      unsigned temp=true_size;
      if (true_size < NALLOC) {
        temp=NALLOC;
      }
      page = sbrk((intptr_t) (temp * sizeof(union header)));
      if (page == (char *)-1) {
        /* There was no memory left to allocate. */
        errno = ENOMEM;
        return NULL;
      }
      /* Create a fragment from this new memory and add it to the list
       * so the above logic can handle breaking it if necessary. */
      block = (union header *)page;
      block->meta.len = temp;
      //printf("remalloc:\n");
      free((void *)(block + 1));
      head=block;
      printf("remalloc:\n");
      print();
      printf("\n");
      p = first;
    }
    prev = p;
    p = p->meta.next;
  }
  return NULL;
}

void* calloc(size_t num, size_t len) {
  void* ptr = buddy_malloc(num * len);

  /* Set the allocated array to 0's.*/
  if (ptr != NULL) {
    memset(ptr, 0, num * len);
  }

  return ptr;
}