#include <stdio.h>
#include "ff_malloc.c"

int main(int argc, char *argv[]) {
  int* arrays[60];
  int i, j, k;
  
  printf("Start test..\n"); //此行不能删除，须在ff_malloc之前调用printf函数


    printf("------allocate arrays[0-19]------\n");
    for (i = 0; i < 20; i++) {
      arrays[i] = (int *)ff_malloc(sizeof(int) * (5*i + 1));
      for (j = 0; j <= 5*i; j++) {
        arrays[i][j] = j;
      }
    }
    printf("------allocte arrays[0-19] is done!------\n\n");

    printf("------free arrays[8-14]------\n");
    for (i = 8; i < 15; i++) {
      free(arrays[i]);
    }
    printf("------free arrays[8-14] is done!------\n\n");



    printf("------allocate arrays[20-29]------\n");
    for (i = 20; i < 30; i++) {
      arrays[i] = (int *)ff_malloc(sizeof(int) * (5*i + 1));
      for (j = 0; j <= 5*i; j++) {
        arrays[i][j] = j;
      }
    }
    printf("------allocte arrays[20-29] is done!------\n\n");


    printf("------free arrays[0-7]------\n");
    for (i = 0; i < 8; i++) {
      free(arrays[i]);
    }
    printf("------free arrays[0-7] is done!------\n\n");

    printf("------free arrays[15-29]------\n");

    for (i = 15; i < 30; i++) {
      free(arrays[i]);
    }
    printf("------free arrays[15-29] is done!------\n\n");


  return 0;
}