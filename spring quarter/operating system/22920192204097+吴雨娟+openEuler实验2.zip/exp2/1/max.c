#include <linux/module.h>
#include <linux/slab.h>

MODULE_LICENSE("GPL");


unsigned char *kmallocmem3;
int max_size;
int page_size=65536;
int i;

static int __init mem_module_init(void)
{
    //TODO: ADD YOUR CODE HERE
    printk("Start kmalloc!\n");

    for(i=0;;i++){
        kmallocmem3 = (unsigned char*)kmalloc(page_size*i, GFP_KERNEL);
        if (kmallocmem3 == NULL){
            max_size=(i-1)*page_size;
            break;
        }
        kfree(kmallocmem3);
    }
    printk("The max size is %d",max_size);

    return 0;
}

static void __exit mem_module_exit(void)
{
    //TODO: ADD YOUR CODE HERE
    kfree(kmallocmem3);
    printk("Exit kmalloc!\n");
}

module_init(mem_module_init);
module_exit(mem_module_exit);