#include <linux/module.h>
#include <linux/slab.h>

MODULE_LICENSE("GPL");


/*TODO: allocate 4KB for kmallocmem1*/
unsigned char *kmallocmem1;
/*TODO: allocate 16KB for kmallocmem2*/
unsigned char *kmallocmem2; 
/*TODO: allocate max-allowed size of memory for kmallocmem3*/
unsigned char *kmallocmem3;
/*TODO: allocate memory lager than max-allowed size for kmallocmem4*/
unsigned char *kmallocmem4;

int max_size=512*1024*1024;
int more_size=512*1024*1024+10;

static int __init mem_module_init(void)
{
    //TODO: ADD YOUR CODE HERE
    printk("Start kmalloc!\n");
    // kmalloc 1
    kmallocmem1 = (unsigned char*)kmalloc(4096, GFP_KERNEL);
    if (kmallocmem1 != NULL)
        printk(KERN_ALERT "kmallocmem1 addr = %lx\n", (unsigned long)kmallocmem1);
    else
        printk("Failed to allocate kmallocmem1!\n");
    // kmalloc 2
    kmallocmem2 = (unsigned char *)kmalloc(16384, GFP_KERNEL);
    if (kmallocmem2 != NULL)
        printk(KERN_ALERT "kmallocmem2 addr = %lx\n", (unsigned long)kmallocmem2);
    else
        printk("Failed to allocate kmallocmem2!\n");
    // free 1 and 2
    kfree(kmallocmem1);
    kfree(kmallocmem2);
    // kmalloc 3
    kmallocmem3 = (unsigned char *)kmalloc(max_size, GFP_KERNEL);
    if (kmallocmem3 != NULL)
        printk(KERN_ALERT "kmallocmem3 addr = %lx\n", (unsigned long)kmallocmem3);
    else
        printk("Failed to allocate kmallocmem3!\n");
    // free 3
    kfree(kmallocmem3);
    // kmalloc 4
    kmallocmem4 = (unsigned char *)kmalloc(more_size, GFP_KERNEL);
    if (kmallocmem4 != NULL)
        printk(KERN_ALERT "kmallocmem4 addr = %lx\n", (unsigned long)kmallocmem4);
    else
        printk("Failed to allocate kmallocmem4!\n");
    return 0;
}

static void __exit mem_module_exit(void)
{
    //TODO: ADD YOUR CODE HERE
    kfree(kmallocmem4);
    printk("Exit kmalloc!\n");
}

module_init(mem_module_init);
module_exit(mem_module_exit);