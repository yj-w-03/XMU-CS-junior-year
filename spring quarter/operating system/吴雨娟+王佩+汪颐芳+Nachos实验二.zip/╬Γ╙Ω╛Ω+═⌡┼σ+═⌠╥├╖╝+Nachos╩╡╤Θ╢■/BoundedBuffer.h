#include "synch.h"
class BoundedBuffer {
   public:
     // create a bounded buffer with a limit of 'maxsize' bytes
     BoundedBuffer(int maxsize);
     ~BoundedBuffer();
     
     // read 'size' bytes from the bounded buffer, storing into 'data'.
     // ('size' may be greater than 'maxsize')
     void Read(char *data, int size);
     
     // write 'size' bytes from 'data' into the bounded buffer.
     // ('size' may be greater than 'maxsize')
     void Write(char *data, int size);
   private:
     int bufferSize;   //缓冲区大小
     char *buffer;     //指向缓冲区的指针

		 Semaphore *mutex; 
		 Semaphore *bufferEmpty;    //缓冲区是否为空
		 Semaphore *bufferFull;     //缓冲区是否已满
		
		 int rp;    //读指针
		 int wp;    //写指针

};

