#include "Table.h"
#include "thread.h"
#include "system.h"

//create a table whose max size is TableSize
//ensuring thread-safe

Table::Table(int size)//create a table
{
    TableSize = size;
    lock = new Lock("Tablelock");
    table = new void *[size];
    value = new int[size];
    for (int i = 0; i < size; i++) {
        value[i] = 0;
    }
}

Table::~Table()//free a table
{
    delete[] table;
    delete lock;
}

int Table::Alloc(void *elem,int which)//allocate a position for elem
{
    int i;
    lock->Acquire();
	printf("thread %d:\n", which);
    for (i = 0; i < TableSize; i++) {
        if (value[i] == 0) {
            table[i] = elem;
            value[i] = 1; // value[i] == 1 means position i is now taken
            printf("Allocate: table[%d] = %d.\n", i, (int)elem);
            lock->Release();
            return i;
        }
    }
	printf("Error: Allocate failed.\n");
    lock->Release();
    return -1;
}

void Table::Release(int index,int which)//release a position
{
    lock->Acquire();
	printf("thread %d:\n", which);
    if (index >= 0 && index < TableSize) {
        if (value[index] == 1) {
            value[index] = 0; // modify the 'flag' value
            table[index] = NULL;
            printf("Release: table[%d].\n", index);
        } else {
            printf("Error: table[%d] is NULL!\n", index);
        }
    }
    else {
        printf("Error: wrong index %d!\n", index);
    }
    lock->Release();
    return;
}

void *Table::Get(int index,int which)//get elem
{
    lock->Acquire();
	printf("thread %d:\n", which);
    if (index >= 0 && index < TableSize) {
        if (value[index] == 1) {
            printf("Get: table[%d] = %d\n", index, (int)table[index]);
            lock->Release();
            return (void *)table[index];
        } else {
            printf("Error: Get: table[%d]: empty!\n", index);
        }
    } else {
        printf("Error: wrong index %d!\n", index);
    }
    lock->Release();
    return NULL;
}
