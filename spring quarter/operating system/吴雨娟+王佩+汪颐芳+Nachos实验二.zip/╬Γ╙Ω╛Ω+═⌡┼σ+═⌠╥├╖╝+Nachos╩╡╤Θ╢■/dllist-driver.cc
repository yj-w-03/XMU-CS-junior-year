#include <stdio.h>
#include <stdlib.h>
#include <sys/time.h>
#include <unistd.h>
#include "synchdllist.h"
#include <ctime>

//N is the number of insert nodes , which is the thread number of the threads
extern void GenerateItems(SynchDLList *list,int N,int which)
{
	int key;
	srand(time(NULL));
	for (int i = 0; i < N; ++i)
	{
		key = rand()%(100+which*11);
		list->SortedInsert(NULL, key);
		printf("\nInsert item with key %d to thread%d\n", key,which);
		//list->PrintDllist();
	}
}


extern void RemoveItems(SynchDLList *list,int N,int which)
{
	int key;
    for(int i=0;i<N;i++) {
    	list->Remove(&key);
    	printf("\nRemove item with key %d from thread%d\n",key,which);
    	//list->PrintDllist();
	}
}

