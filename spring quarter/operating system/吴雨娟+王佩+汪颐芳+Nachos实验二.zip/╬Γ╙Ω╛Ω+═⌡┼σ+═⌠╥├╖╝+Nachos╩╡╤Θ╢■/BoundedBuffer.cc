#include "BoundedBuffer.h"
#include "system.h"
#include "synch.h"

BoundedBuffer::BoundedBuffer(int maxsize)
{
    bufferSize=maxsize;
    buffer=new char[bufferSize+1]();
    for(int i=0;i<bufferSize;i++)
    buffer[i]=' ';
    buffer[bufferSize]=0;

    mutex=new Semaphore("mutex",1);
	bufferEmpty=new Semaphore("bufferEmpty",bufferSize);
	bufferFull=new Semaphore("bufferFull",0);

    rp=0;
    wp=0;
}

BoundedBuffer::~BoundedBuffer()
{
	delete mutex;
	delete bufferEmpty;
	delete bufferFull;
	delete buffer;
}

void
BoundedBuffer::Read(char *data, int size)
{
    for(int i=0;i<size;i++)
    {
        bufferFull->P();      // Wait for the buffer to be not empty
        mutex->P();           // Ensure that no other thread 
		                      // will access the buffer during consume

        data[i]=buffer[rp];
        buffer[rp]=' ';
        rp=(rp+1)%bufferSize;

        printf("Read (Thread %p):%c\n", currentThread, data[i]);
		printf("buffer:%s\n\n",buffer);

        mutex->V();
        bufferEmpty->V();     
    }

}

void
BoundedBuffer::Write(char *data, int size)
{
    for(int i=0;i<size;i++)
    {
        bufferEmpty->P();   // Wait for the buffer to be not full
        mutex->P();         // Ensure that no other thread 
		                    // will access the buffer during consume

        buffer[wp]=data[i];
        wp=(wp+1)%bufferSize;

        printf("Write (Thread %p):%c\n", currentThread, data[i]);
		printf("buffer:%s\n\n",buffer);

        mutex->V();
        bufferFull->V();     
    }
}
