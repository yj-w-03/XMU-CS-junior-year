// synch.cc 
//	Routines for synchronizing threads.  Three kinds of
//	synchronization routines are defined here: semaphores, locks 
//   	and condition variables (the implementation of the last two
//	are left to the reader).
//
// Any implementation of a synchronization routine needs some
// primitive atomic operation.  We assume Nachos is running on
// a uniprocessor, and thus atomicity can be provided by
// turning off interrupts.  While interrupts are disabled, no
// context switch can occur, and thus the current thread is guaranteed
// to hold the CPU throughout, until interrupts are reenabled.
//
// Because some of these routines might be called with interrupts
// already disabled (Semaphore::V for one), instead of turning
// on interrupts at the end of the atomic operation, we always simply
// re-set the interrupt state back to its original value (whether
// that be disabled or enabled).
//
// Copyright (c) 1992-1993 The Regents of the University of California.
// All rights reserved.  See copyright.h for copyright notice and limitation 
// of liability and disclaimer of warranty provisions.

#include "copyright.h"
#include "synch.h"
#include "system.h"

//----------------------------------------------------------------------
// Semaphore::Semaphore
// 	Initialize a semaphore, so that it can be used for synchronization.
//
//	"debugName" is an arbitrary name, useful for debugging.
//	"initialValue" is the initial value of the semaphore.
//----------------------------------------------------------------------

Semaphore::Semaphore(char* debugName, int initialValue)
{
    name = debugName;
    value = initialValue;
    queue = new List;
}

//----------------------------------------------------------------------
// Semaphore::Semaphore
// 	De-allocate semaphore, when no longer needed.  Assume no one
//	is still waiting on the semaphore!
//----------------------------------------------------------------------

Semaphore::~Semaphore()
{
    delete queue;
}

//----------------------------------------------------------------------
// Semaphore::P
// 	Wait until semaphore value > 0, then decrement.  Checking the
//	value and decrementing must be done atomically, so we
//	need to disable interrupts before checking the value.
//
//	Note that Thread::Sleep assumes that interrupts are disabled
//	when it is called.
//----------------------------------------------------------------------

void
Semaphore::P()
{
    IntStatus oldLevel = interrupt->SetLevel(IntOff);	// disable interrupts
    
    while (value == 0) { 			// semaphore not available
	queue->Append((void *)currentThread);	// so go to sleep
	currentThread->Sleep();
    } 
    value--; 					// semaphore available, 
						// consume its value
    
    (void) interrupt->SetLevel(oldLevel);	// re-enable interrupts
}

//----------------------------------------------------------------------
// Semaphore::V
// 	Increment semaphore value, waking up a waiter if necessary.
//	As with P(), this operation must be atomic, so we need to disable
//	interrupts.  Scheduler::ReadyToRun() assumes that threads
//	are disabled when it is called.
//----------------------------------------------------------------------

void
Semaphore::V()
{
    Thread *thread;
    IntStatus oldLevel = interrupt->SetLevel(IntOff);

    thread = (Thread *)queue->Remove();
    if (thread != NULL)	   // make thread ready, consuming the V immediately
	scheduler->ReadyToRun(thread);
    value++;
    (void) interrupt->SetLevel(oldLevel);
}

//----------------------------------------------------------------------
// Lock::Lock
// 	Initialize a lock.
//  "debugName" is useful for debugging.
//  "sem" is a semaphore for mutual exclusivity, and its initial value is 1.
//  "holdThread" is the pointer of which thread held the lock now.
//  and "isHeldByCurrentThread" can use it.
//----------------------------------------------------------------------

Lock::Lock(char* debugName) 
{
    name = debugName;
	holdThread = NULL;
	sem = new Semaphore(debugName,1);
}

//----------------------------------------------------------------------
// Lock::~Lock
// 	De-allocate lock, when it is no longer needed.  
//----------------------------------------------------------------------

Lock::~Lock() 
{
    delete sem;
}

//----------------------------------------------------------------------
// Lock::Acquire
// 	when the thread not hold the lock now, call P to try to get the lock.
//----------------------------------------------------------------------

void Lock::Acquire() 
{
    ASSERT(!this->isHeldByCurrentThread());
    // ask for lock by calling P()
	sem->P();
	holdThread = currentThread;
}

//----------------------------------------------------------------------
// Lock::Release
// 	Release the lock, and the blocked thread can try to get lock now.
//----------------------------------------------------------------------

void Lock::Release() 
{
    ASSERT(isHeldByCurrentThread());
    // add 1 to value
	sem->V();
    // the lock is released
	holdThread = NULL;
}

//----------------------------------------------------------------------
// Lock::isHeldByCurrentThread
// 	Test whether the thread hold the lock now. Return True or False.
//----------------------------------------------------------------------

bool Lock::isHeldByCurrentThread()
{
    return holdThread == currentThread;
}

//----------------------------------------------------------------------
// Condition::Condition
// 	Initialize a condition, so that it can be used for synchronization.
//	"debugName" is an arbitrary name for debugging.
//	"sem" is a semaphore for condition, and its initial value is 0.
//  "value" is the number of threads which are blocked.
//----------------------------------------------------------------------

Condition::Condition(char* debugName) 
{ 
    name = debugName;
	sem = new Semaphore(debugName,0);
	value = 0;	
}

//----------------------------------------------------------------------
// Condition::~Condition
// 	De-allocate condition, when it is no longer needed.  
//----------------------------------------------------------------------

Condition::~Condition() 
{ 
    delete sem;
}

//----------------------------------------------------------------------
// Condition::Wait
//	"condtionLock" is a Lock, used with the condition together for mutual exclusivity.
//	record the lock, release lock, then sleep.
//	User must judge the condition is ture and then call the wait function!!!
//----------------------------------------------------------------------

void Condition::Wait(Lock* conditionLock) 
{ 
    // record the lock
    holdLock = conditionLock;
    // release lock
	conditionLock->Release();
	value++;
	sem->P();
    // get the lock again
	conditionLock->Acquire(); 
}

//----------------------------------------------------------------------
// Condition::Signal
//	"condtionLock" is a Lock, used with the condition together for mutual exclusivity.
//	Wake up a thread, if there is another thread in wating queue.
//----------------------------------------------------------------------

void Condition::Signal(Lock* conditionLock) 
{ 
    // ensure every call to Signal and Wait passes an associated mutex
    ASSERT(conditionLock == holdLock || holdLock == NULL); 
	// if there are thread blocked, wake one
	if(value > 0) {
		sem->V();
		value--;
	}
}

//----------------------------------------------------------------------
// Condition::Broadcast
//	"condtionLock" is a Lock, used with the condition together for mutual exclusivity.
//	Wake up all threads, if there is any thread in wating queue.
//----------------------------------------------------------------------

void Condition::Broadcast(Lock* conditionLock) 
{ 
    // ensure every call to Broadcast and Wait passes an associated mutex
    ASSERT(conditionLock == holdLock || holdLock == NULL); 
	// if there are thread blocked, wake all
	while(value > 0) {
		sem->V();
		value--;
	}
}
