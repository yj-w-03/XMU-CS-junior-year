// threadtest.cc
//	Simple test case for the threads assignment.
//
//	Create two threads, and have them context switch
//	back and forth between themselves by calling Thread::Yield,
//	to illustratethe inner workings of the thread system.
//
// Copyright (c) 1992-1993 The Regents of the University of California.
// All rights reserved.  See copyright.h for copyright notice and limitation
// of liability and disclaimer of warranty provisions.
#include <iostream>
#include "copyright.h"
#include "system.h"
#include "synch.h"      //ʵ�������ƺ������������ļ�
#include "synchdllist.h"
#include "BoundedBuffer.h"
#include "Table.h"
#include <ctime>
#include <stdlib.h>

//  set in main.cc
int testnum = 1;
int threadnum = 2;
int itemnum = 5;
int errortype = 0;

// External functions in dllist-driver.cc
extern void GenerateItems(SynchDLList *list,int N,int which);
extern void RemoveItems(SynchDLList *list,int N,int which);

SynchDLList *list;
Table *table;
BoundedBuffer *buffer;

char Rdata[1000]={0};
char WData[1000]="0";


//----------------------------------------------------------------------
// SimpleThread
// 	Loop 5 times, yielding the CPU to another ready thread
//	each iteration.
//
//	"which" is simply a number identifying the thread, for debugging
//	purposes.
//----------------------------------------------------------------------

void
DLListThread(int which)
{
    GenerateItems(list,itemnum,which);
    RemoveItems(list,itemnum,which);
}

void TableThread(int which)
{
    srand((int)time(NULL)+which);
    int num = rand()%100;

	void *elem = (void *)num;
	int p;

	p = table->Alloc(elem,which);

	if (p != -1) {
		num = (int)table->Get(p,which);
		table->Release(p,which);
	}
}

void BoundedBufferThread(int which)
{
	if ((which % 2) == 0) {
		srand((int)time(NULL)+which);
        int num = rand()%10;
		WData[0] = '0'+num;
		buffer->Write(WData, 1);
	} else {
		buffer->Read(Rdata, 1);
	}
}

//----------------------------------------------------------------------
// ThreadTest1
// 	Set up a ping-pong between two threads, by forking a thread
//	to call SimpleThread, and then calling SimpleThread ourselves.
//----------------------------------------------------------------------

void
ThreadTest1()
{
    DEBUG('t', "Entering ThreadTest1");
    list = new SynchDLList();
    for(int i=1;i<threadnum;i++)
    {
        Thread *t = new Thread("forked thread");   //Initialize a thread control block, so that we can then call Thread::Fork.
        t->Fork(DLListThread, i);       //"func" is the procedure to run concurrently. "arg" is a single argument to be passed to the procedure.
    }
    DLListThread(0);
}

void
ThreadTest2()
{
    DEBUG('t', "Entering ThreadTest2");
    table = new Table(itemnum);
    for(int i=1;i<threadnum;i++)
    {
        Thread *t = new Thread("forked thread");   //Initialize a thread control block, so that we can then call Thread::Fork.
        t->Fork(TableThread, i);       //"func" is the procedure to run concurrently. "arg" is a single argument to be passed to the procedure.
    }
    TableThread(0);
}

void
ThreadTest3()
{
    DEBUG('t', "Entering ThreadTest3");
    buffer = new BoundedBuffer(itemnum);
    for(int i=1;i<threadnum;i++)
    {
        Thread *t = new Thread("forked thread");   //Initialize a thread control block, so that we can then call Thread::Fork.
        t->Fork(BoundedBufferThread, i);       //"func" is the procedure to run concurrently. "arg" is a single argument to be passed to the procedure.
    }
    BoundedBufferThread(0);
}

//----------------------------------------------------------------------
// ThreadTest
// 	Invoke a test routine.
//----------------------------------------------------------------------

void
ThreadTest()
{
    switch (testnum) {
    case 1:
        ThreadTest1();  //�����˫������
        break;
    case 2:
        ThreadTest2();   //�̰߳�ȫ�ı��ṹ
        break;
    case 3:
        ThreadTest3();   //��С���޵Ļ�����
        break;
    default:
	printf("No test specified.\n");
	break;
    }
}

