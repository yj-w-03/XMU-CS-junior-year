
/*  A Bison parser, made from compile_sim.y
 by  GNU Bison version 1.25
  */

#define YYBISON 1  /* Identify Bison output.  */

#define alloca

#define	BASIC	258
#define	CONST	259
#define	ID	260
#define	IF	261
#define	ELSE	262
#define	WHILE	263
#define	DO	264
#define	BREAK	265
#define	RELOP_LT	266
#define	RELOP_LE	267
#define	RELOP_GT	268
#define	RELOP_GE	269
#define	RELOP_EQ	270
#define	RELOP_NEQ	271
#define	OR	272
#define	AND	273
#define	UMINUS	274

#line 1 "compile_sim.y"
 
#include <ctype.h>
#include <stdio.h>
#include <string.h>
#include <malloc.h>

int LineNo = 1; /*��ǰlookahead��ָ����ַ����ڵ��кţ�����ǰ���뵽���к�*/

int CompileFailed = 0;

void yyerror( char * ErrStr )
{
    CompileFailed = 1; /*����ʧ�ܱ�־*/
    printf("������Ϣ:%s, �к�:%d\n", ErrStr, LineNo);
}



/*�����ͳ����Ļ�������BASIC*/
#define CHAR     	1
#define INT      	2
#define FLOAT    	3
#define BOOL     	4

#define CHAR_WIDTH  	1
#define INT_WIDTH   	4
#define FLOAT_WIDTH 	8  
#define BOOL_WIDTH  	1

/*****************************���棺���ű��Ķ������غ���*******************************/

/*���������Ȳ�����ID_MAX_LEN ���ַ�*/
#define ID_MAX_LEN   64

/*���һ����ʶ��*/
struct SymbolElem {
    char name[ ID_MAX_LEN + 1 ]; /*������(���������)���Ȳ�����ID_MAX_LEN ���ַ�*/
    int type; /*�������������������int, �������ֻ���������ͣ���ʵ�ʵı������У�����Ҫ�������ṹ*/
    int  addr;      /*Ϊ�ñ�������Ŀռ���׵�ַ*/
    int  width;     /*�ñ����Ŀ��ȣ���ռ�ö��ٸ��ֽ�*/
    struct SymbolElem * next;  /*ָ����һ����ʶ��*/
};

/*��ʶ����*/
typedef struct SymbolList{
    struct SymbolElem * head;  /*ָ����ű���������ʵ�֣��ĵ�һ����㣬û��ͷ���,��ʼ��ΪNULL*/
    struct SymbolList * prev; /*��һ��ķ��ű�*/
    int beginaddr; /*�÷��ű��з������������ʱ�����ռ�Ŀ�ʼ��ַ*/
    int endaddr;    /*�÷��ű��з������������ʱ�����ռ�Ľ�����ַ*/
                   /*beginaddr~endaddr�Ŀռ��Ÿ÷��ű������б�������ʱ����*/
} * SymbolList;  /*���ű�*/

SymbolList TopSymbolList=NULL; /*ȫ�ֱ�������ŵ�ǰ�ķ��ű�������ǰ�������ķ��ű���,��ӦΪ���ϵ�top*/

/*����������һ���µķ��ű���SymbolList�������ϵ�Env����PrevList�������һ����ű�*/
SymbolList CreateSymbolList( SymbolList PrevList, int StartAddr )
{ 
	SymbolList list;
    list = (SymbolList) malloc( sizeof(struct SymbolList) );
    memset( list, 0, sizeof( struct SymbolList ) );
    list->prev = PrevList;
	list->endaddr = list->beginaddr = StartAddr;

    return list;
}

void DestroySymbolList( SymbolList List )
{
	struct SymbolElem * p, *q;
    
    if( List == NULL) return;
    p = List->head;
    while( p!=NULL ) {
    	q = p->next; free(p); p=q;
    }
    free(List);    
}

/*�ڷ��ű�List�в����Ƿ���ڱ�ʶ��IdName��������ڣ��򷵻ظý��ָ�룬���򷵻ؿ�*/
struct SymbolElem * LookUpSymbolList( SymbolList List, char * IdName )
{
	struct SymbolElem * p;
    	if( List==NULL ) return NULL;
    	for( p = List->head; p!=NULL; p = p->next ) 
        	if( strcmp( p->name, IdName ) == 0 ) break;
    	return p;
}

/*�ӷ��ű�List��ʼ�����ϵ�����һ����ű��в����Ƿ���ڱ�ʶ��IdName��������ڣ��򷵻ظý��ָ�룬���򷵻ؿ�*/
struct SymbolElem * LookUpAllSymbolList( SymbolList List, char * IdName )
{ 
	SymbolList env;
	struct SymbolElem * p;
    	env = List;
    	while( env!=NULL ) {
        		p = LookUpSymbolList( env, IdName );
        		if(  p != NULL ) return p; /*�ҵ��÷���*/
        		env = env->prev;
    	}
    return NULL;
}


/*����һ���µķ��Ž��,�����ӵ����ű��У����󷵻ظý��ָ��*/
struct SymbolElem * AddToSymbolList( SymbolList List, char * IdName,int IdType, int Width )
{
	struct SymbolElem * p;

    	p = (struct SymbolElem *) malloc( sizeof(struct SymbolElem) );

    	strcpy( p->name, IdName );
    	p->type = IdType;
	p->width = Width;
	p->addr = List->endaddr;
	List->endaddr += Width;

    	p->next = List->head;  /*���ñ�ʶ�����ӵ����ű���ͷ*/
    	List->head = p;

    	return p;    
}

void PrintSymbolList( SymbolList List )
{struct SymbolElem * p;
    printf("***********************�����б�*************************\n");
    if( List ==NULL ) return ;
    for( p=List->head; p!=NULL; p=p->next ) {
        printf("������:%s, ����:", p->name);
		switch( p->type ) {
            case CHAR : printf("char");  break;
            case INT  : printf("int");   break;
            case FLOAT: printf("float"); break;
            case BOOL : printf("bool");  break;
		}
        printf(", ��ַ:%d, ����:%d\n", p->addr, p->width );
	}
    printf("*************�ñ����б���ռ��%d���ֽڿռ�***************\n", List->endaddr - List->beginaddr);
}

/*����һ����ʱ����,������ʱ�����ĵ�ַ����ʱ����������*/
int NewTemp( SymbolList List, char Name[], int Width )
{ 	
	static int TempID = 1;
  	int addr;
    	sprintf( Name, "t%d", TempID++ ); /*����t1��t2��*/
	addr = List->endaddr;
    	List->endaddr += Width;
  
    	return addr;
}

/*****************************���棺���ű��Ķ������غ���*****************************/




/*****************************���棺�������Ķ������غ���*******************************/

union ConstVal {
        char    ch;    /*����ַ�����*/
        int     n;     /*������ͳ�������true=1��false=0 */
        double  f;     /*��Ÿ���������*/
};	

/*���һ������*/
struct ConstElem {
    char str[ID_MAX_LEN + 1 ]; /*�ñ������ڴ洢�������ı���ʽ����ʾ��ʱ���õ�,ʵ�ʵı���ϵͳ����Ҫ*/	   
    int type; /*�������������������int, �������ֻ���������ͣ���ʵ�ʵı������У�����Ҫ�������ṹ*/
    union ConstVal value;
    int  addr;      /*Ϊ�ó�������Ŀռ���׵�ַ*/
    int  width;     /*�ñ����Ŀ��ȣ���ռ�ö��ٸ��ֽ�*/
    struct ConstElem * next;  /*ָ����һ������*/
};

/*������*/
struct ConstList{
    struct ConstElem * head;  /*ָ��������������ʵ�֣��ĵ�һ����㣬û��ͷ���,��ʼ��ΪNULL*/
    int beginaddr;  /*�÷��ű��з���������ռ�Ŀ�ʼ��ַ*/
    int endaddr;    /*�÷��ű��з���������ռ�Ľ�����ַ*/
                   /*beginaddr~endaddr�Ŀռ��Ÿó����������г���*/
} ConstList ;  /*��������ȫ�ֱ�����ע����������ֻ��Ҫһ��������**/


/*���������س�����*/
void CreateConstList( int StartAddr )
{ 
	ConstList.head = NULL;
	ConstList.endaddr = ConstList.beginaddr = StartAddr;
}

void DestroyConstList( void )
{
	struct ConstElem * p, *q;
    
    	p = ConstList.head;
    	while( p!=NULL ) {
        		q = p->next; free(p); p=q;
    	}
	memset( &ConstList, 0, sizeof(struct ConstList) );
}

/*�ڳ�����ConstList�в����Ƿ���ڳ�����������ڣ��򷵻ظý��ָ�룬���򷵻ؿ�*/
struct ConstElem * LookUpConstList( int ConstType, union ConstVal ConstValue, int Width )
{
	struct ConstElem * p;
    	for( p = ConstList.head; p!=NULL; p = p->next ) 
        	if( p->type == ConstType && memcmp( &p->value,&ConstValue, Width) == 0 )  
		break;
	return p;
}


/*����һ���µĳ������,�����ӵ��������У����󷵻ظý��ָ��*/
struct ConstElem * AddToConstList( char * Str, int ConstType, union ConstVal ConstValue, int Width )
{struct ConstElem * p;

    p = (struct ConstElem *) malloc( sizeof(struct ConstElem) );

    strcpy( p->str, Str );
    p->type = ConstType;
    p->value = ConstValue;
    p->width = Width;

    p->addr = ConstList.endaddr;
    ConstList.endaddr += Width;

    p->next = ConstList.head;  /*���ó������ӵ���������ͷ*/
    ConstList.head = p;

    return p;    
}

void PrintConstList(void)
{
	struct ConstElem * p;
    	printf("***********************�����б�*************************\n");
    	for( p=ConstList.head; p!=NULL; p=p->next ) {
	    printf("����:%s, ����:", p->str);
		switch( p->type ) {
            			case CHAR : printf("char");  break;
            			case INT  : printf("int");   break;
            			case FLOAT: printf("float"); break;
            			case BOOL : printf("bool");  break;
		}
        	printf(", ��ַ:%d, ����:%d\n", p->addr, p->width );
	}
    	printf("**************�ó����б���ռ��%d���ֽڿռ�***************\n", ConstList.endaddr - ConstList.beginaddr);
}

/*****************************���棺�������Ķ������غ���*****************************/





/********************************����:��Ԫʽ�Ķ���ͺ���****************************/

/* ���ͼӼ��˳� */
#define OIntAdd		1001
#define OIntSub          	1002
#define OIntMultiply     	1003
#define OIntDivide       	1004

/* �������Ӽ��˳� */
#define OFloatAdd        	1011
#define OFloatSub        	1012
#define OFloatMultiply   	1013
#define OFloatDivide     	1014

/*��ֵa=b*/
#define OIntEvaluation   	1021
#define OFloatEvaluation 	1022
#define OCharEvaluation  	1023
#define OBoolEvaluation  	1024

/* ������goto��� */
#define OGoto            	1031

/* if a op b goto ��� */
#define OGTGoto          	1041
#define OGEGoto          	1042
#define OLTGoto          	1043
#define OLEGoto          	1044
#define OEQGoto          	1045
#define ONEQGoto         	1046

/*ǿ������ת��*/
#define OCharToInt       	1051
#define OCharToFloat     	1052
#define OIntToFloat      	1053
#define OIntToChar       	1054
#define OFloatToChar     	1055
#define OFloatToInt      	1056
#define OCharToBool      	1057
#define OIntToBool       	1058
#define OFloatToBool     	1059
#define OBoolToChar      	1060
#define OBoolToInt       	1061
#define OBoolToFloat     	1062 
#define HALT             	1063

/* ȡ�� */
#define OIntMinus           1071
#define OFloatMinus         1072

/*��Ԫʽ���ݽṹ*/
struct Quadruple {
    int op; /*�����*/
    int arg1; /*��ŵ�һ�������ĵ�ַ�������Ǳ�������ʱ�����ĵ�ַ*/
    int arg2;
    int arg3;/*��ŵ����������ĵ�ַ�������Ǳ�������ʱ�����ĵ�ַ������������Ԫʽ�ĵ�ַ(Goto �ĵ�ַ����)*/
    char arg1name[ID_MAX_LEN + 1]; /*������Ҫ��������ʾʱ����ʾarg1��Ӧ�ı�������ʱ����������(���еĻ���*/
    char arg2name[ID_MAX_LEN + 1]; /*������Ҫ��������ʾʱ����ʾarg2��Ӧ�ı�������ʱ����������(���еĻ���*/
    char arg3name[ID_MAX_LEN + 1]; /*������Ҫ��������ʾʱ����ʾarg3��Ӧ�ı�������ʱ����������(���еĻ���*/
};

/*��Ԫʽ��*/
struct QuadTable {
    int startaddr; /*��Ԫʽ��ʼ��ŵĵ�ַ,����100*/
    struct Quadruple * base; /*ָ��һ���ڴ棬������Ŷ����Ԫʽ����base[0]��ʼ���*/
    int size; /*base�п��Դ�ŵ���Ԫʽ�ĸ���*/
    int len; /*base[len]����һ����ԪʽҪ��ŵĿռ�*/

};

struct QuadTable QuadTable; /*ֻ��Ҫһ����Ԫʽ��*/

void CreateQuadTable(int StartAddr)
{
    QuadTable.startaddr = StartAddr; 
    QuadTable.size = 1000; /* һ��ʼ������Դ��1000����Ԫʽ*/
    QuadTable.base = ( struct Quadruple *)malloc( QuadTable.size * sizeof(struct Quadruple) );
    QuadTable.len = 0;
}

void DestroyQuadTable( void )
{
    QuadTable.startaddr = 0; 
    QuadTable.size = 0;
    if( QuadTable.base != NULL) free(QuadTable.base); 
    QuadTable.len = 0;   
}

/*��Arg1�Ǳ�������ʱ����ʱ��Arg1Name�Ǹñ���������,������ʾʱʹ�ã����������ͬ */
int Gen( int Op, int Arg1, int Arg2, int Arg3, char *Arg1Name, char *Arg2Name, char *Arg3Name )
{ 
	struct Quadruple * ptr; 
  	int incr = 100;
    	if( QuadTable.len >= QuadTable.size ) {
        		ptr = realloc( QuadTable.base, QuadTable.size+incr );
        		if( ptr==NULL ) return -1;
        		QuadTable.base = ptr;
        		QuadTable.size += incr;
   	 }
    	ptr = & QuadTable.base[QuadTable.len];
    	ptr->op = Op;
    	ptr->arg1 = Arg1;
    	ptr->arg2 = Arg2;
    	ptr->arg3 = Arg3;
    	strcpy( ptr->arg1name, Arg1Name);
    	strcpy( ptr->arg2name, Arg2Name);
    	strcpy( ptr->arg3name, Arg3Name);
    	QuadTable.len++;

    	return QuadTable.len - 1;
}

/*����Ԫʽ����Ӧ������ַ����д�뵽�ļ���*/
void WriteQuadTableToFile( const char * FileName )
{
	FILE * fp;
	struct Quadruple * ptr;
	int i,op;
	char str[1000],ch;
	fp = fopen( FileName, "w" );
    if( fp==NULL ) return;
    for( i=0, ptr = QuadTable.base; i < QuadTable.len; i++,ptr++ ) {
        fprintf(fp, "%5d:  ", QuadTable.startaddr + i);
        op = ptr->op;
        switch( op ) {
            case OIntAdd:
            case OIntSub: 
         	case OIntMultiply: 
         	case OIntDivide:
            case OFloatAdd: 
            case OFloatSub: 
            case OFloatMultiply: 
            case OFloatDivide:
                if( op==OIntAdd || op==OFloatAdd ) ch = '+';
                if(op==OIntSub || op==OFloatSub) ch = '-';
                if(op==OIntMultiply || op==OFloatMultiply) ch = '*';
                if(op==OIntDivide || op==OFloatDivide) ch = '/';
                sprintf(str,"[%d] = [%d] %c [%d]", ptr->arg3, ptr->arg1, ch, ptr->arg2);
				printf("%s = %s %c %s\n", ptr->arg3name, ptr->arg1name, ch, ptr->arg2name);
                break;
            
            case OIntEvaluation:
            case OFloatEvaluation:
            case OCharEvaluation:
            case OBoolEvaluation:
            	sprintf(str,"[%d] = [%d]", ptr->arg3, ptr->arg1);
				printf("%s = %s\n", ptr->arg3name, ptr->arg1name);
                break;
            
            case OGoto: 
				sprintf(str,"Goto %d", ptr->arg3);
				printf("Goto %s\n", ptr->arg3name);
                break;

            case OLTGoto  : 
				sprintf(str,"if [%d] < [%d] Goto %d", ptr->arg1, ptr->arg2, ptr->arg3 );  
				printf("if %s<%s Goto %s\n", ptr->arg1name, ptr->arg2name, ptr->arg3name );  
				break; 
            case OLEGoto: 
				sprintf(str, "if [%d] <= [%d] Goto %d", ptr->arg1, ptr->arg2, ptr->arg3 );  
				printf("if %s <= %s Goto %s\n", ptr->arg1name, ptr->arg2name, ptr->arg3name );  
				break; 
			case OGTGoto: 
				sprintf(str, "if [%d] > [%d] Goto %d", ptr->arg1, ptr->arg2, ptr->arg3 );  
				printf("if %s > %s Goto %s\n", ptr->arg1name, ptr->arg2name, ptr->arg3name );  
				break; 
			case OGEGoto: 
				sprintf(str, "if [%d] >= [%d] Goto %d", ptr->arg1, ptr->arg2, ptr->arg3 );  
				printf("if %s > %s Goto %s\n", ptr->arg1name, ptr->arg2name, ptr->arg3name );  
				break;
			case OEQGoto: 
				sprintf(str, "if [%d] == [%d] Goto %d", ptr->arg1, ptr->arg2, ptr->arg3 );  
				printf("if %s == %s Goto %s\n", ptr->arg1name, ptr->arg2name, ptr->arg3name );  
				break; 
			case ONEQGoto: 
				sprintf(str, "if [%d] != [%d] Goto %d", ptr->arg1, ptr->arg2, ptr->arg3 );  
				printf("if %s != %s Goto %s\n", ptr->arg1name, ptr->arg2name, ptr->arg3name );  
				break; 

            case OCharToBool:
            case OIntToBool:
            case OFloatToBool:
            	sprintf( str,"[%d] = (bool) [%d]", ptr->arg3, ptr->arg1); 
				printf("%s = (bool) %s\n", ptr->arg3name, ptr->arg1name);  
				break;
			case OBoolToChar:
            case OIntToChar:
            case OFloatToChar:
            	sprintf( str,"[%d] = (char) [%d]", ptr->arg3, ptr->arg1); 
				printf("%s = (char) %s\n", ptr->arg3name, ptr->arg1name);  
				break; 
			case OBoolToInt:
            case OCharToInt:
            case OFloatToInt:
            	sprintf( str,"[%d] = (int) [%d]", ptr->arg3, ptr->arg1); 
				printf("%s = (int) %s\n", ptr->arg3name, ptr->arg1name);  
				break;
			case OBoolToFloat:
            case OCharToFloat:
            case OIntToFloat:
            	sprintf( str,"[%d] = (float) [%d]", ptr->arg3, ptr->arg1); 
				printf("%s = (float) %s\n", ptr->arg3name, ptr->arg1name);  
				break; 
            
            case OIntMinus:
            case OFloatMinus: 
            	sprintf(str, "[%d] = - [%d]", ptr->arg3, ptr->arg1);
            	printf("%s = %s\n", ptr->arg3name, ptr->arg1name);
                break;

			case HALT : 
				sprintf(str, "HALT"); 
				printf("HALT\n");
				break;
            default: yyerror("������󣺳��ֲ���ʶ���������"); strcpy(str, "error: Unknown operator");break;
        }
        fprintf(fp,"%s\n",str);
    }

    fclose(fp);
}

/********************************����:��Ԫʽ�Ķ���ͺ���****************************/


/********************************����:�������ͼ����غ���****************************/
// ���ڷ��ز㼶�ߵĵ����ͣ��㼶�Ӹߵ��ͣ�float>int>char>bool
int typeMax(int type1, int type2)
{
	if(type1 > type2) return type1;
	else return type2;
}

// ������type�ؿ�ΪwideType
int typeWiden(int addr, int type, char name[], int wideType, char tmpName[], SymbolList TopSymbolList)
{
	if(type == wideType){ // �������������ͬ������ת����ֱ�ӷ��ص�ַ��
		return addr;
	} 
    else{ // ����ֻ�����Զ�����ת�����ؿ�ת���������Ͳ㼶����ת���ɸ߲㼶����
		int op;
		int tmpWidth;
		int tmpAddr;
		if(type == BOOL && wideType == CHAR){ // boolת��Ϊchar
			op = OBoolToChar;
			tmpWidth = CHAR_WIDTH;
		} 
        else if(type == BOOL && wideType == INT){ // boolת��Ϊint
			op = OBoolToInt;
			tmpWidth = INT_WIDTH;
		} 
        else if(type == BOOL && wideType == FLOAT){ // boolת��Ϊfloat
			op = OBoolToFloat;
			tmpWidth = FLOAT_WIDTH;
		} 
        else if(type == CHAR && wideType == INT){ // charת��Ϊint
			op = OCharToInt;
			tmpWidth = INT_WIDTH;
		} 
        else if(type == CHAR && wideType == FLOAT){ // charת��Ϊfloat
			op = OCharToFloat;
			tmpWidth = FLOAT_WIDTH;
		} 
        else if(type == INT && wideType == FLOAT){ // intת��Ϊfloat
			op = OIntToFloat;
			tmpWidth = FLOAT_WIDTH;
		}
		tmpAddr = NewTemp(TopSymbolList, tmpName, tmpWidth); // ����һ����ʱ����
		Gen(op, addr, 0, tmpAddr, name, "", tmpName); // ��������ַָ���������ת��

		return tmpAddr;
	}
}

/********************************����:�������ͼ����غ���****************************/


/******************************����:���������ر����ͺ���*******************************************/
// ���������洢
struct backlist{
     int backaddr;// ������ʾ�������ݵ�ַ
     struct backlist *next ; 
};

struct backlist * makelist(int i)
{
    struct backlist *x  = (struct  backlist *)malloc( sizeof( struct backlist)) ; 
	x->backaddr = i ; 
    x->next = NULL;
	return x;
}

struct backlist *  merge(struct backlist * p1 , struct backlist *p2 )
{
       struct backlist * tail = p1;
       while( tail->next != NULL){
	        tail = tail->next; 
	   }	   
	   tail->next = p2;
       return p1; 	  //�����ݺϲ���p1 ��	   
}

void backpatch( struct backlist * p , int instr)
{
     // ��������
	struct backlist *temp ;
    temp = p ;
	QuadTable.base[temp->backaddr-QuadTable.startaddr]. arg3 = instr; 
	while(temp->next !=NULL){
	    temp = temp->next; 
	    QuadTable.base[temp->backaddr-QuadTable.startaddr]. arg3 = instr; //ѭ�������б�
	}
}


/******************************�����涨�������ر����ͺ���*******************************************/


/**************����:����䷨����ջ��Ԫ�ص���Ϣ�����ս���ͷ��ս�����ۺ�����****************/

 union ParseStackNodeInfo{
    struct {
	  
        char name[ID_MAX_LEN + 1 ]; 
    }id;  /*��ʶ��:�ս��ID���ۺ�����*/

    struct {
	   char str[ID_MAX_LEN + 1 ]; /*�ñ������ڴ洢�������ı���ʽ����ʾ��ʱ���õ�,ʵ�ʵı���ϵͳ����Ҫ*/	   
           int type; /*�������������������INT*/
	   union ConstVal value; /*�������ս��CONST����Ϣ*/
	   int width;
	} constval; /*�ս��const���ۺ�����*/

    struct {
        int type; /*�������������������INT*/
    }basic; /*�����������ͣ��ս��BASIC���ۺ�����*/

    struct {
	   char str[ID_MAX_LEN + 1 ]; /*�ñ������ڴ洢����������ʱ�������������ı���ʽ����ʾ��ʱ���õ�,ʵ�ʵı���ϵͳ����Ҫ*/
	   int type;
	   int addr;
	   int width;
	   struct backlist * truelist;
	   struct backlist * falselist;
	   struct backlist * nextlist;
	   struct backlist * breaklist;//���ڴ��break �Ļ���ĵ�ַ
	} factor, unary, term, expr, rel, equality, join, bool,N,stmt,stmts,block;/*���ս��factor, term, expr, rel, equality, join, bool���ۺ�����*/
    struct {
	   int instr;// ��һ��ָ������ Ҳ���� QuadTable.len+QuadTable.startaddr  
	}M;
} ;

#define YYSTYPE union ParseStackNodeInfo 

       

/**************����:����䷨����ջ��Ԫ�ص���Ϣ�����ս���ͷ��ս�����ۺ�����****************/
 




#ifndef YYSTYPE
#define YYSTYPE int
#endif
#include <stdio.h>

#ifndef __cplusplus
#ifndef __STDC__
#define const
#endif
#endif



#define	YYFINAL		90
#define	YYFLAG		32768
#define	YYNTBASE	31

#define YYTRANSLATE(x) ((unsigned)(x) <= 274 ? yytranslate[x] : 50)

static const char yytranslate[] = {     0,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,    24,     2,     2,     2,     2,     2,     2,    29,
    30,    22,    20,     2,    21,     2,    23,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,    28,     2,
    19,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,    26,     2,    27,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     1,     2,     3,     4,     5,
     6,     7,     8,     9,    10,    11,    12,    13,    14,    15,
    16,    17,    18,    25
};

#if YYDEBUG != 0
static const short yyprhs[] = {     0,
     0,     2,     9,    10,    11,    14,    15,    19,    21,    25,
    27,    32,    39,    50,    58,    67,    69,    70,    71,    76,
    78,    83,    85,    89,    93,    95,    99,   103,   107,   111,
   113,   117,   121,   123,   127,   131,   133,   136,   139,   141,
   145,   147
};

static const short yyrhs[] = {    32,
     0,    26,    33,    35,    38,    34,    27,     0,     0,     0,
    35,    36,     0,     0,    37,     5,    28,     0,     3,     0,
    38,    41,    39,     0,    39,     0,     5,    19,    46,    28,
     0,     6,    29,    42,    30,    41,    39,     0,     6,    29,
    42,    30,    41,    39,     7,    40,    41,    39,     0,     8,
    41,    29,    42,    30,    41,    39,     0,     9,    41,    39,
     8,    29,    42,    30,    28,     0,    32,     0,     0,     0,
    42,    17,    41,    43,     0,    43,     0,    43,    18,    41,
    44,     0,    44,     0,    44,    15,    45,     0,    44,    16,
    45,     0,    45,     0,    46,    11,    46,     0,    46,    12,
    46,     0,    46,    13,    46,     0,    46,    14,    46,     0,
    46,     0,    46,    20,    47,     0,    46,    21,    47,     0,
    47,     0,    47,    22,    48,     0,    47,    23,    48,     0,
    48,     0,    24,    48,     0,    21,    48,     0,    49,     0,
    29,    46,    30,     0,     5,     0,     4,     0
};

#endif

#if YYDEBUG != 0
static const short yyrline[] = { 0,
   649,   658,   667,   671,   681,   682,   685,   705,   709,   716,
   722,   836,   843,   854,   864,   872,   878,   883,   886,   899,
   912,   925,   938,   952,   966,   979,   993,  1007,  1021,  1035,
  1049,  1108,  1167,  1180,  1239,  1298,  1311,  1322,  1341,  1353,
  1365,  1388
};
#endif


#if YYDEBUG != 0 || defined (YYERROR_VERBOSE)

static const char * const yytname[] = {   "$","error","$undefined.","BASIC",
"CONST","ID","IF","ELSE","WHILE","DO","BREAK","RELOP_LT","RELOP_LE","RELOP_GT",
"RELOP_GE","RELOP_EQ","RELOP_NEQ","OR","AND","'='","'+'","'-'","'*'","'/'","'!'",
"UMINUS","'{'","'}'","';'","'('","')'","program","block","blockM1","blockM2",
"decls","decl","type","stmts","stmt","N","M","bool","join","equality","rel",
"expr","term","unary","factor", NULL
};
#endif

static const short yyr1[] = {     0,
    31,    32,    33,    34,    35,    35,    36,    37,    38,    38,
    39,    39,    39,    39,    39,    39,    40,    41,    42,    42,
    43,    43,    44,    44,    44,    45,    45,    45,    45,    45,
    46,    46,    46,    47,    47,    47,    48,    48,    48,    49,
    49,    49
};

static const short yyr2[] = {     0,
     1,     6,     0,     0,     2,     0,     3,     1,     3,     1,
     4,     6,    10,     7,     8,     1,     0,     0,     4,     1,
     4,     1,     3,     3,     1,     3,     3,     3,     3,     1,
     3,     3,     1,     3,     3,     1,     2,     2,     1,     3,
     1,     1
};

static const short yydefact[] = {     0,
     3,     1,     6,     0,     8,     0,     0,    18,    18,    16,
     5,     0,    18,    10,     0,     0,     0,     0,     0,     0,
     0,    42,    41,     0,     0,     0,     0,    33,    36,    39,
     0,    20,    22,    25,    30,     0,     0,     7,     2,     9,
    38,    37,     0,     0,     0,    11,     0,     0,    18,    18,
    18,     0,     0,     0,     0,     0,     0,     0,     0,    40,
    31,    32,    34,    35,     0,     0,     0,    23,    24,    26,
    27,    28,    29,    18,     0,    19,    12,    21,     0,     0,
    17,    14,     0,    18,    15,     0,    13,     0,     0,     0
};

static const short yydefgoto[] = {    88,
    10,     3,    20,     4,    11,    12,    13,    14,    84,    17,
    31,    32,    33,    34,    35,    28,    29,    30
};

static const short yypact[] = {   -25,
-32768,-32768,-32768,    11,-32768,    -6,   -26,-32768,-32768,-32768,
-32768,     5,   -12,-32768,     4,     4,     0,    18,     8,    35,
    18,-32768,-32768,     4,     4,     4,    33,    49,-32768,-32768,
    13,    14,    40,-32768,    46,     4,    56,-32768,-32768,-32768,
-32768,-32768,     1,     4,     4,-32768,     4,     4,-32768,-32768,
-32768,     4,     4,     4,     4,     4,     4,    21,    50,-32768,
    49,    49,-32768,-32768,     4,    18,     4,-32768,-32768,    48,
    48,    48,    48,-32768,     4,    14,    71,    40,    18,    22,
-32768,-32768,    52,-32768,-32768,    18,-32768,    81,    82,-32768
};

static const short yypgoto[] = {-32768,
    83,-32768,-32768,-32768,-32768,-32768,-32768,   -16,-32768,    -9,
   -30,    19,    20,    24,    -8,    29,   -13,-32768
};


#define	YYLAST		87


static const short yytable[] = {    18,
     1,    37,    16,    21,    40,    58,    27,    22,    23,    19,
    41,    42,    15,     5,    -4,     6,     7,    43,     8,     9,
    44,    45,     6,     7,    24,     8,     9,    25,    36,    49,
    60,    51,    26,    63,    64,    38,     1,    49,    49,    65,
    66,    67,    50,     1,    80,    70,    71,    72,    73,    77,
    74,    83,    44,    45,    52,    53,    54,    55,    56,    57,
    46,    39,    82,    59,    79,    44,    45,    44,    45,    87,
    47,    48,    61,    62,    86,    68,    69,    81,    75,    85,
    89,    90,     2,    76,     0,     0,    78
};

static const short yycheck[] = {     9,
    26,    18,    29,    13,    21,    36,    15,     4,     5,     5,
    24,    25,    19,     3,    27,     5,     6,    26,     8,     9,
    20,    21,     5,     6,    21,     8,     9,    24,    29,    17,
    30,    18,    29,    47,    48,    28,    26,    17,    17,    49,
    50,    51,    30,    26,    75,    54,    55,    56,    57,    66,
    30,    30,    20,    21,    15,    16,    11,    12,    13,    14,
    28,    27,    79,     8,    74,    20,    21,    20,    21,    86,
    22,    23,    44,    45,    84,    52,    53,     7,    29,    28,
     0,     0,     0,    65,    -1,    -1,    67
};
/* -*-C-*-  Note some compilers choke on comments on `#line' lines.  */

/* Skeleton output parser for bison,
   Copyright (C) 1984, 1989, 1990 Free Software Foundation, Inc.

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2, or (at your option)
   any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.  */

/* As a special exception, when this file is copied by Bison into a
   Bison output file, you may use that output file without restriction.
   This special exception was added by the Free Software Foundation
   in version 1.24 of Bison.  */

#ifndef alloca
#ifdef __GNUC__
#define alloca __builtin_alloca
#else /* not GNU C.  */
#if (!defined (__STDC__) && defined (sparc)) || defined (__sparc__) || defined (__sparc) || defined (__sgi)
#include <alloca.h>
#else /* not sparc */
#if defined (MSDOS) && !defined (__TURBOC__)
#include <malloc.h>
#else /* not MSDOS, or __TURBOC__ */
#if defined(_AIX)
#include <malloc.h>
 #pragma alloca
#else /* not MSDOS, __TURBOC__, or _AIX */
#ifdef __hpux
#ifdef __cplusplus
extern "C" {
void *alloca (unsigned int);
};
#else /* not __cplusplus */
void *alloca ();
#endif /* not __cplusplus */
#endif /* __hpux */
#endif /* not _AIX */
#endif /* not MSDOS, or __TURBOC__ */
#endif /* not sparc.  */
#endif /* not GNU C.  */
#endif /* alloca not defined.  */

/* This is the parser code that is written into each bison parser
  when the %semantic_parser declaration is not specified in the grammar.
  It was written by Richard Stallman by simplifying the hairy parser
  used when %semantic_parser is specified.  */

/* Note: there must be only one dollar sign in this file.
   It is replaced by the list of actions, each action
   as one case of the switch.  */

#define yyerrok		(yyerrstatus = 0)
#define yyclearin	(yychar = YYEMPTY)
#define YYEMPTY		-2
#define YYEOF		0
#define YYACCEPT	return(0)
#define YYABORT 	return(1)
#define YYERROR		goto yyerrlab1
/* Like YYERROR except do call yyerror.
   This remains here temporarily to ease the
   transition to the new meaning of YYERROR, for GCC.
   Once GCC version 2 has supplanted version 1, this can go.  */
#define YYFAIL		goto yyerrlab
#define YYRECOVERING()  (!!yyerrstatus)
#define YYBACKUP(token, value) \
do								\
  if (yychar == YYEMPTY && yylen == 1)				\
    { yychar = (token), yylval = (value);			\
      yychar1 = YYTRANSLATE (yychar);				\
      YYPOPSTACK;						\
      goto yybackup;						\
    }								\
  else								\
    { yyerror ("syntax error: cannot back up"); YYERROR; }	\
while (0)

#define YYTERROR	1
#define YYERRCODE	256

#ifndef YYPURE
#define YYLEX		yylex()
#endif

#ifdef YYPURE
#ifdef YYLSP_NEEDED
#ifdef YYLEX_PARAM
#define YYLEX		yylex(&yylval, &yylloc, YYLEX_PARAM)
#else
#define YYLEX		yylex(&yylval, &yylloc)
#endif
#else /* not YYLSP_NEEDED */
#ifdef YYLEX_PARAM
#define YYLEX		yylex(&yylval, YYLEX_PARAM)
#else
#define YYLEX		yylex(&yylval)
#endif
#endif /* not YYLSP_NEEDED */
#endif

/* If nonreentrant, generate the variables here */

#ifndef YYPURE

int	yychar;			/*  the lookahead symbol		*/
YYSTYPE	yylval;			/*  the semantic value of the		*/
				/*  lookahead symbol			*/

#ifdef YYLSP_NEEDED
YYLTYPE yylloc;			/*  location data for the lookahead	*/
				/*  symbol				*/
#endif

int yynerrs;			/*  number of parse errors so far       */
#endif  /* not YYPURE */

#if YYDEBUG != 0
int yydebug;			/*  nonzero means print parse trace	*/
/* Since this is uninitialized, it does not stop multiple parsers
   from coexisting.  */
#endif

/*  YYINITDEPTH indicates the initial size of the parser's stacks	*/

#ifndef	YYINITDEPTH
#define YYINITDEPTH 200
#endif

/*  YYMAXDEPTH is the maximum size the stacks can grow to
    (effective only if the built-in stack extension method is used).  */

#if YYMAXDEPTH == 0
#undef YYMAXDEPTH
#endif

#ifndef YYMAXDEPTH
#define YYMAXDEPTH 10000
#endif

/* Prevent warning if -Wstrict-prototypes.  */
#ifdef __GNUC__
int yyparse (void);
#endif

#if __GNUC__ > 1		/* GNU C and GNU C++ define this.  */
#define __yy_memcpy(TO,FROM,COUNT)	__builtin_memcpy(TO,FROM,COUNT)
#else				/* not GNU C or C++ */
#ifndef __cplusplus

/* This is the most reliable way to avoid incompatibilities
   in available built-in functions on various systems.  */
static void
__yy_memcpy (to, from, count)
     char *to;
     char *from;
     int count;
{
  register char *f = from;
  register char *t = to;
  register int i = count;

  while (i-- > 0)
    *t++ = *f++;
}

#else /* __cplusplus */

/* This is the most reliable way to avoid incompatibilities
   in available built-in functions on various systems.  */
static void
__yy_memcpy (char *to, char *from, int count)
{
  register char *f = from;
  register char *t = to;
  register int i = count;

  while (i-- > 0)
    *t++ = *f++;
}

#endif
#endif


/* The user can define YYPARSE_PARAM as the name of an argument to be passed
   into yyparse.  The argument should have type void *.
   It should actually point to an object.
   Grammar actions can access the variable by casting it
   to the proper pointer type.  */

#ifdef YYPARSE_PARAM
#ifdef __cplusplus
#define YYPARSE_PARAM_ARG void *YYPARSE_PARAM
#define YYPARSE_PARAM_DECL
#else /* not __cplusplus */
#define YYPARSE_PARAM_ARG YYPARSE_PARAM
#define YYPARSE_PARAM_DECL void *YYPARSE_PARAM;
#endif /* not __cplusplus */
#else /* not YYPARSE_PARAM */
#define YYPARSE_PARAM_ARG
#define YYPARSE_PARAM_DECL
#endif /* not YYPARSE_PARAM */

int
yyparse(YYPARSE_PARAM_ARG)
     YYPARSE_PARAM_DECL
{
  register int yystate;
  register int yyn;
  register short *yyssp;
  register YYSTYPE *yyvsp;
  int yyerrstatus;	/*  number of tokens to shift before error messages enabled */
  int yychar1 = 0;		/*  lookahead token as an internal (translated) token number */

  short	yyssa[YYINITDEPTH];	/*  the state stack			*/
  YYSTYPE yyvsa[YYINITDEPTH];	/*  the semantic value stack		*/

  short *yyss = yyssa;		/*  refer to the stacks thru separate pointers */
  YYSTYPE *yyvs = yyvsa;	/*  to allow yyoverflow to reallocate them elsewhere */

#ifdef YYLSP_NEEDED
  YYLTYPE yylsa[YYINITDEPTH];	/*  the location stack			*/
  YYLTYPE *yyls = yylsa;
  YYLTYPE *yylsp;

#define YYPOPSTACK   (yyvsp--, yyssp--, yylsp--)
#else
#define YYPOPSTACK   (yyvsp--, yyssp--)
#endif

  int yystacksize = YYINITDEPTH;

#ifdef YYPURE
  int yychar;
  YYSTYPE yylval;
  int yynerrs;
#ifdef YYLSP_NEEDED
  YYLTYPE yylloc;
#endif
#endif

  YYSTYPE yyval;		/*  the variable used to return		*/
				/*  semantic values from the action	*/
				/*  routines				*/

  int yylen;

#if YYDEBUG != 0
  if (yydebug)
    fprintf(stderr, "Starting parse\n");
#endif

  yystate = 0;
  yyerrstatus = 0;
  yynerrs = 0;
  yychar = YYEMPTY;		/* Cause a token to be read.  */

  /* Initialize stack pointers.
     Waste one element of value and location stack
     so that they stay on the same level as the state stack.
     The wasted elements are never initialized.  */

  yyssp = yyss - 1;
  yyvsp = yyvs;
#ifdef YYLSP_NEEDED
  yylsp = yyls;
#endif

/* Push a new state, which is found in  yystate  .  */
/* In all cases, when you get here, the value and location stacks
   have just been pushed. so pushing a state here evens the stacks.  */
yynewstate:

  *++yyssp = yystate;

  if (yyssp >= yyss + yystacksize - 1)
    {
      /* Give user a chance to reallocate the stack */
      /* Use copies of these so that the &'s don't force the real ones into memory. */
      YYSTYPE *yyvs1 = yyvs;
      short *yyss1 = yyss;
#ifdef YYLSP_NEEDED
      YYLTYPE *yyls1 = yyls;
#endif

      /* Get the current used size of the three stacks, in elements.  */
      int size = yyssp - yyss + 1;

#ifdef yyoverflow
      /* Each stack pointer address is followed by the size of
	 the data in use in that stack, in bytes.  */
#ifdef YYLSP_NEEDED
      /* This used to be a conditional around just the two extra args,
	 but that might be undefined if yyoverflow is a macro.  */
      yyoverflow("parser stack overflow",
		 &yyss1, size * sizeof (*yyssp),
		 &yyvs1, size * sizeof (*yyvsp),
		 &yyls1, size * sizeof (*yylsp),
		 &yystacksize);
#else
      yyoverflow("parser stack overflow",
		 &yyss1, size * sizeof (*yyssp),
		 &yyvs1, size * sizeof (*yyvsp),
		 &yystacksize);
#endif

      yyss = yyss1; yyvs = yyvs1;
#ifdef YYLSP_NEEDED
      yyls = yyls1;
#endif
#else /* no yyoverflow */
      /* Extend the stack our own way.  */
      if (yystacksize >= YYMAXDEPTH)
	{
	  yyerror("parser stack overflow");
	  return 2;
	}
      yystacksize *= 2;
      if (yystacksize > YYMAXDEPTH)
	yystacksize = YYMAXDEPTH;
      yyss = (short *) alloca (yystacksize * sizeof (*yyssp));
      __yy_memcpy ((char *)yyss, (char *)yyss1, size * sizeof (*yyssp));
      yyvs = (YYSTYPE *) alloca (yystacksize * sizeof (*yyvsp));
      __yy_memcpy ((char *)yyvs, (char *)yyvs1, size * sizeof (*yyvsp));
#ifdef YYLSP_NEEDED
      yyls = (YYLTYPE *) alloca (yystacksize * sizeof (*yylsp));
      __yy_memcpy ((char *)yyls, (char *)yyls1, size * sizeof (*yylsp));
#endif
#endif /* no yyoverflow */

      yyssp = yyss + size - 1;
      yyvsp = yyvs + size - 1;
#ifdef YYLSP_NEEDED
      yylsp = yyls + size - 1;
#endif

#if YYDEBUG != 0
      if (yydebug)
	fprintf(stderr, "Stack size increased to %d\n", yystacksize);
#endif

      if (yyssp >= yyss + yystacksize - 1)
	YYABORT;
    }

#if YYDEBUG != 0
  if (yydebug)
    fprintf(stderr, "Entering state %d\n", yystate);
#endif

  goto yybackup;
 yybackup:

/* Do appropriate processing given the current state.  */
/* Read a lookahead token if we need one and don't already have one.  */
/* yyresume: */

  /* First try to decide what to do without reference to lookahead token.  */

  yyn = yypact[yystate];
  if (yyn == YYFLAG)
    goto yydefault;

  /* Not known => get a lookahead token if don't already have one.  */

  /* yychar is either YYEMPTY or YYEOF
     or a valid token in external form.  */

  if (yychar == YYEMPTY)
    {
#if YYDEBUG != 0
      if (yydebug)
	fprintf(stderr, "Reading a token: ");
#endif
      yychar = YYLEX;
    }

  /* Convert token to internal form (in yychar1) for indexing tables with */

  if (yychar <= 0)		/* This means end of input. */
    {
      yychar1 = 0;
      yychar = YYEOF;		/* Don't call YYLEX any more */

#if YYDEBUG != 0
      if (yydebug)
	fprintf(stderr, "Now at end of input.\n");
#endif
    }
  else
    {
      yychar1 = YYTRANSLATE(yychar);

#if YYDEBUG != 0
      if (yydebug)
	{
	  fprintf (stderr, "Next token is %d (%s", yychar, yytname[yychar1]);
	  /* Give the individual parser a way to print the precise meaning
	     of a token, for further debugging info.  */
#ifdef YYPRINT
	  YYPRINT (stderr, yychar, yylval);
#endif
	  fprintf (stderr, ")\n");
	}
#endif
    }

  yyn += yychar1;
  if (yyn < 0 || yyn > YYLAST || yycheck[yyn] != yychar1)
    goto yydefault;

  yyn = yytable[yyn];

  /* yyn is what to do for this token type in this state.
     Negative => reduce, -yyn is rule number.
     Positive => shift, yyn is new state.
       New state is final state => don't bother to shift,
       just return success.
     0, or most negative number => error.  */

  if (yyn < 0)
    {
      if (yyn == YYFLAG)
	goto yyerrlab;
      yyn = -yyn;
      goto yyreduce;
    }
  else if (yyn == 0)
    goto yyerrlab;

  if (yyn == YYFINAL)
    YYACCEPT;

  /* Shift the lookahead token.  */

#if YYDEBUG != 0
  if (yydebug)
    fprintf(stderr, "Shifting token %d (%s), ", yychar, yytname[yychar1]);
#endif

  /* Discard the token being shifted unless it is eof.  */
  if (yychar != YYEOF)
    yychar = YYEMPTY;

  *++yyvsp = yylval;
#ifdef YYLSP_NEEDED
  *++yylsp = yylloc;
#endif

  /* count tokens shifted since error; after three, turn off error status.  */
  if (yyerrstatus) yyerrstatus--;

  yystate = yyn;
  goto yynewstate;

/* Do the default action for the current state.  */
yydefault:

  yyn = yydefact[yystate];
  if (yyn == 0)
    goto yyerrlab;

/* Do a reduction.  yyn is the number of a rule to reduce with.  */
yyreduce:
  yylen = yyr2[yyn];
  if (yylen > 0)
    yyval = yyvsp[1-yylen]; /* implement default value of the action */

#if YYDEBUG != 0
  if (yydebug)
    {
      int i;

      fprintf (stderr, "Reducing via rule %d (line %d), ",
	       yyn, yyrline[yyn]);

      /* Print the symbols being reduced, and their result.  */
      for (i = yyprhs[yyn]; yyrhs[i] > 0; i++)
	fprintf (stderr, "%s ", yytname[yyrhs[i]]);
      fprintf (stderr, " -> %s\n", yytname[yyr1[yyn]]);
    }
#endif


  switch (yyn) {

case 1:
#line 650 "compile_sim.y"
{ 	printf("����ʽ��program -> block\n");
		  	if( yyvsp[0].block.nextlist != NULL){
				backpatch(yyvsp[0].block.nextlist,QuadTable.startaddr+QuadTable.len);
		  	}
		  	Gen(HALT,0,0,0,"","", "");
		;
    break;}
case 2:
#line 659 "compile_sim.y"
{ 	printf("����ʽ��block -> {decls stmts}\n"); 
            yyval.block.nextlist = yyvsp[-2].stmts.nextlist;
			if( yyvsp[-2].stmts.breaklist != NULL){
		    	yyval.block.breaklist  =  yyvsp[-2].stmts.breaklist;
			}
		;
    break;}
case 3:
#line 668 "compile_sim.y"
{ TopSymbolList = CreateSymbolList( TopSymbolList, TopSymbolList->endaddr ); ;
    break;}
case 4:
#line 672 "compile_sim.y"
{ 
		SymbolList env;
        PrintSymbolList( TopSymbolList); 
        env = TopSymbolList->prev;
        DestroySymbolList( TopSymbolList ); 
        TopSymbolList = env;                 
    ;
    break;}
case 5:
#line 681 "compile_sim.y"
{ printf("����ʽ��decls -> decls decl\n"); ;
    break;}
case 6:
#line 682 "compile_sim.y"
{ printf("����ʽ��decls -> NULL\n"); ;
    break;}
case 7:
#line 686 "compile_sim.y"
{ 	
		int width;
        printf("����ʽ��decl -> type ID; ID=%s\n",yyvsp[-1].id.name); 
     
		if (yyvsp[-2].basic.type == INT)
            AddToSymbolList( TopSymbolList, yyvsp[-1].id.name, yyvsp[-2].basic.type, INT_WIDTH );
        else if(yyvsp[-2].basic.type == CHAR)
            AddToSymbolList( TopSymbolList, yyvsp[-1].id.name, yyvsp[-2].basic.type, CHAR_WIDTH );
        else if(yyvsp[-2].basic.type == FLOAT)
            AddToSymbolList( TopSymbolList, yyvsp[-1].id.name, yyvsp[-2].basic.type, FLOAT_WIDTH );
        else if(yyvsp[-2].basic.type == BOOL)
            AddToSymbolList( TopSymbolList, yyvsp[-1].id.name, yyvsp[-2].basic.type, BOOL_WIDTH );
        else{
            width=-1;
            AddToSymbolList(TopSymbolList, yyvsp[-1].id.name, yyvsp[-2].basic.type, width);
        }
    ;
    break;}
case 8:
#line 706 "compile_sim.y"
{ printf("����ʽ��type -> BASIC\n"); yyval.basic.type = yyvsp[0].basic.type; ;
    break;}
case 9:
#line 710 "compile_sim.y"
{ 	printf("����ʽ��stmts -> stmts stmt\n");
			if( yyvsp[-2].stmts.nextlist  != NULL){ //���Ϊ�ղ�����
				backpatch(yyvsp[-2].stmts.nextlist, yyvsp[-1].M.instr) ;
			}
			yyval.stmts.nextlist = yyvsp[0].stmt.nextlist;
		;
    break;}
case 10:
#line 717 "compile_sim.y"
{	printf("����ʽ��stmts -> stmt\n");
			yyval.stmts.nextlist = yyvsp[0].stmt.nextlist; 
		;
    break;}
case 11:
#line 723 "compile_sim.y"
{ 	printf("����ʽ��stmt -> id = expr;\n"); 

			struct SymbolElem * p;
			p = LookUpAllSymbolList( TopSymbolList, yyvsp[-3].id.name );
      		if( p != NULL ) {
				if(p->type == yyvsp[-1].expr.type){ // �����ֵ�������������ͬ
                    switch(p->type){
                        case BOOL:
                            Gen(OBoolEvaluation , yyvsp[-1].expr.addr, 0, p->addr, yyvsp[-1].expr.str, "",  p->name);  
                            break;
                        case CHAR:
                            Gen(OCharEvaluation , yyvsp[-1].expr.addr, 0, p->addr, yyvsp[-1].expr.str, "",  p->name);   
                            break;
                        case INT:
                            Gen(OIntEvaluation , yyvsp[-1].expr.addr, 0, p->addr, yyvsp[-1].expr.str, "",  p->name);    
                            break;
                        case FLOAT:
                            Gen(OFloatEvaluation , yyvsp[-1].expr.addr, 0, p->addr, yyvsp[-1].expr.str, "",  p->name);  
                            break;
                        default:
                            yyerror("�������ͷǷ�");
                    }
                }
                else{ // ��ֵ����������Ͳ�ͬ��Ҫ��������ת��
                    int op;
                    char tmpName[10];
                    int tmpWidth;
                    int tmpAddr;

                    if(p->type == BOOL) { // ת��BOOL
                        tmpWidth = BOOL_WIDTH;
                        switch (yyvsp[-1].expr.type) {
                            case CHAR:
                                op = OCharToBool; break;
                            case INT: 
                                op = OIntToBool; break;
                            case FLOAT: 
                                op = OFloatToBool; break;
                            default: 
                                yyerror("�������ͷǷ�");
                        }
                    } 
                    else if(p->type == CHAR){ // ת��CHAR
                        tmpWidth = CHAR_WIDTH;
                        switch (yyvsp[-1].expr.type) {
                            case BOOL: 
                                op = OBoolToChar; break;
                            case INT: 
                                op = OIntToChar; break;
                            case FLOAT: 
                                op = OFloatToChar; break;
                            default: 
                                yyerror("�������ͷǷ�");
                        }
                    }
                    else if(p->type == INT){ // ת��INT
                        tmpWidth = INT_WIDTH; 
                        switch (yyvsp[-1].expr.type) {
                            case BOOL: 
                                op = OBoolToInt; break;
                            case CHAR: 
                                op = OCharToInt; break;
                            case FLOAT: 
                                op = OFloatToInt; break;
                            default: 
                                yyerror("�������ͷǷ�");
                        }
                    }
                    else if(p->type == FLOAT){ // ת��FLOAT
                        tmpWidth = FLOAT_WIDTH;
                        switch (yyvsp[-1].expr.type) {
                            case BOOL: 
                                op = OBoolToFloat; break;
                            case CHAR: 
                                op = OCharToFloat; break;
                            case INT: 
                                op = OIntToFloat; break;
                            default:
                                yyerror("�������ͷǷ�");
                        }
                    }
                    else yyerror("�����Ƿ�����");
                    // ������ʱ����
                    tmpAddr = NewTemp(TopSymbolList, tmpName, tmpWidth);
                    // ����ֵ�Ҳ�ı�����������ת���󸳸���ʱ����
                    Gen(op, yyvsp[-1].expr.addr, 0, tmpAddr, yyvsp[-1].expr.str, "", tmpName);
                    // ����ʱ����������ֵ���ı���
                    switch (p->type) {
                        case BOOL: 
                            Gen(OBoolEvaluation , tmpAddr, 0, p->addr, tmpName, "",  p->name); break;
                        case CHAR: 
                            Gen(OCharEvaluation , tmpAddr, 0, p->addr, tmpName, "",  p->name); break;
                        case INT: 
                            Gen(OIntEvaluation  , tmpAddr, 0, p->addr, tmpName, "",  p->name); break;
                        case FLOAT: 
                            Gen(OFloatEvaluation, tmpAddr, 0, p->addr, tmpName, "",  p->name); break;
                        default: 
                            yyerror("�������ͷǷ�");
                    }

                }
			}							    
			else {
				yyerror( "������û�ж���" );
				strcpy( yyval.factor.str, "no_id_defined" ); /*�ݴ�����*/
				yyval.factor.type = INT;
				yyval.factor.addr = -1;
				yyval.factor.width = INT_WIDTH;						
			
				Gen(OIntEvaluation , yyvsp[-1].expr.addr, 0, p->addr, yyvsp[-1].expr.str, "",  p->name);  
				yyval.stmt.nextlist = NULL; 
        	}
    	;
    break;}
case 12:
#line 837 "compile_sim.y"
{ 
			printf("����ʽ��stmt -> if (bool) stmt\n");
			backpatch(yyvsp[-3].bool.truelist,yyvsp[-1].M.instr);
			yyval.stmt.nextlist = merge(yyvsp[-3].bool.falselist,yyvsp[0].stmt.nextlist);
		;
    break;}
case 13:
#line 844 "compile_sim.y"
{
            printf("����ʽ��stmt -> if (bool) stmt else stmt\n");

            backpatch(yyvsp[-7].bool.truelist,yyvsp[-5].M.instr);
			backpatch(yyvsp[-7].bool.falselist,yyvsp[-1].M.instr);
			struct backlist *temp ;
			temp = merge(yyvsp[-2].N.nextlist, yyvsp[-4].stmt.nextlist);
			yyval.stmt.nextlist = merge(temp, yyvsp[0].stmt.nextlist);
        ;
    break;}
case 14:
#line 855 "compile_sim.y"
{
            printf("����ʽ��stmt -> while (bool) stmt\n");

			backpatch(yyvsp[0].stmt.nextlist, yyvsp[-5].M.instr);
			backpatch(yyvsp[-3].bool.truelist, yyvsp[-1].M.instr);
			yyval.stmt.nextlist = yyvsp[-3].bool.falselist;
			Gen(OGoto, 0, 0, yyvsp[-5].M.instr + QuadTable.startaddr, "", "", "");
        ;
    break;}
case 15:
#line 865 "compile_sim.y"
{
            printf("����ʽ��stmt -> do stmt while (bool);\n");

            backpatch(yyvsp[-2].bool.truelist, yyvsp[-6].M.instr);
            yyval.stmt.nextlist = yyvsp[-2].bool.falselist;
        ;
    break;}
case 16:
#line 873 "compile_sim.y"
{ 	printf("����ʽ��stmt -> block\n"); 
			yyval.stmt.nextlist = yyvsp[0].block.nextlist;
		;
    break;}
case 17:
#line 878 "compile_sim.y"
{
			yyval.N.nextlist = makelist(QuadTable.len+QuadTable.startaddr);	
			Gen(OGoto,0,0,0,"", "", "");
		;
    break;}
case 18:
#line 883 "compile_sim.y"
{
            yyval.M.instr = QuadTable.startaddr+QuadTable.len;
        ;
    break;}
case 19:
#line 887 "compile_sim.y"
{
            printf("����ʽ��bool -> bool || join\n");

            strcpy(yyval.bool.str, "");
			yyval.bool.type = 0;
			yyval.bool.addr = 0;
			yyval.bool.width = 0;  
			backpatch(yyvsp[-3].bool.falselist, yyvsp[-1].M.instr);
			yyval.bool.truelist = merge(yyvsp[-3].bool.truelist, yyvsp[0].join.truelist);
			yyval.bool.falselist = yyvsp[0].join.falselist;
		;
    break;}
case 20:
#line 900 "compile_sim.y"
{
            printf("����ʽ��bool -> join\n");

            strcpy( yyval.bool.str, yyvsp[0].join.str );
			yyval.bool.type = yyvsp[0].join.type;
			yyval.bool.addr = yyvsp[0].join.addr;
			yyval.bool.width = yyvsp[0].join.width;
			yyval.bool.truelist = yyvsp[0].join.truelist;
			yyval.bool.falselist = yyvsp[0].join.falselist;
        ;
    break;}
case 21:
#line 913 "compile_sim.y"
{
            printf("����ʽ��join -> join && equality\n");

            strcpy(yyval.join.str, "");
			yyval.join.type = 0;
			yyval.join.addr = 0;
			yyval.join.width = 0;  
            backpatch(yyvsp[-3].join.truelist, yyvsp[-1].M.instr);
			yyval.join.truelist = yyvsp[0].equality.truelist;
			yyval.join.falselist = merge(yyvsp[-3].join.falselist, yyvsp[0].equality.falselist);
        ;
    break;}
case 22:
#line 926 "compile_sim.y"
{
            printf("����ʽ��join -> equality\n");

            strcpy(yyval.join.str, yyvsp[0].equality.str);
			yyval.join.type = yyvsp[0].equality.type;	
			yyval.join.addr = yyvsp[0].equality.addr;
		  	yyval.join.width = yyvsp[0].equality.width;
			yyval.join.truelist = yyvsp[0].equality.truelist;
			yyval.join.falselist = yyvsp[0].equality.falselist;
        ;
    break;}
case 23:
#line 939 "compile_sim.y"
{
            printf("����ʽ��equality -> equality == rel\n");

            strcpy(yyval.equality.str, "");
			yyval.equality.type = 0;
			yyval.equality.addr = 0;
			yyval.equality.width = 0;
			yyval.equality.truelist = makelist(QuadTable.len + QuadTable.startaddr);	
			yyval.equality.falselist = makelist(QuadTable.len + QuadTable.startaddr + 1);	
			Gen(OEQGoto, yyvsp[-2].equality.addr, yyvsp[0].rel.addr, 0, yyvsp[-2].equality.str, yyvsp[0].rel.str, "");
			Gen(OGoto, 0, 0, 0, "", "", "");
        ;
    break;}
case 24:
#line 953 "compile_sim.y"
{
            printf("����ʽ��equality -> equality != rel\n");

            strcpy(yyval.equality.str, "");
            yyval.equality.type = 0;
			yyval.equality.addr = 0;
			yyval.equality.width = 0;
			yyval.equality.truelist = makelist(QuadTable.len + QuadTable.startaddr);	
			yyval.equality.falselist = makelist(QuadTable.len + QuadTable.startaddr + 1);	
			Gen(ONEQGoto, yyvsp[-2].equality.addr, yyvsp[0].rel.addr, 0, yyvsp[-2].equality.str, yyvsp[0].rel.str, "");
			Gen(OGoto, 0, 0, 0, "", "", "");
        ;
    break;}
case 25:
#line 967 "compile_sim.y"
{
            printf("����ʽ��equality -> rel\n");

            strcpy(yyval.equality.str, yyvsp[0].rel.str);
			yyval.equality.type = yyvsp[0].rel.type;
			yyval.equality.addr = yyvsp[0].rel.addr;
		  	yyval.equality.width = yyvsp[0].rel.width;
			yyval.equality.truelist = yyvsp[0].rel.truelist;
			yyval.equality.falselist = yyvsp[0].rel.falselist;
        ;
    break;}
case 26:
#line 980 "compile_sim.y"
{
            printf("����ʽ��rel -> expr < expr\n");

            strcpy(yyval.rel.str, "");
            yyval.rel.type = 0;
			yyval.rel.addr = 0;
			yyval.rel.width = 0;
			yyval.rel.truelist =  makelist(QuadTable.startaddr + QuadTable.len);	
			yyval.rel.falselist =  makelist(QuadTable.startaddr + QuadTable.len + 1 );
			Gen(OLTGoto, yyvsp[-2].expr.addr, yyvsp[0].expr.addr , 0 , yyvsp[-2].expr.str, yyvsp[0].expr.str, "_") ;
			Gen(OGoto, 0, 0, 0, "", "", "_");
		;
    break;}
case 27:
#line 994 "compile_sim.y"
{
            printf("����ʽ��rel -> expr <= expr\n");

            strcpy(yyval.rel.str, "");
            yyval.rel.type = 0;
			yyval.rel.addr = 0;
			yyval.rel.width = 0;
            yyval.rel.truelist = makelist(QuadTable.startaddr + QuadTable.len);
			yyval.rel.falselist = makelist(QuadTable.startaddr + QuadTable.len + 1 );
			Gen(OLEGoto, yyvsp[-2].expr.addr, yyvsp[0].expr.addr, 0, yyvsp[-2].expr.str, yyvsp[0].expr.str, "");
			Gen(OGoto, 0, 0, 0, "", "", "");
        ;
    break;}
case 28:
#line 1008 "compile_sim.y"
{
            printf("����ʽ��rel -> expr > expr\n");

            strcpy(yyval.rel.str, "");
            yyval.rel.type = 0;
			yyval.rel.addr = 0;
			yyval.rel.width = 0;
            yyval.rel.truelist = makelist(QuadTable.startaddr + QuadTable.len);
			yyval.rel.falselist = makelist(QuadTable.startaddr + QuadTable.len + 1 );
			Gen(OGTGoto, yyvsp[-2].expr.addr, yyvsp[0].expr.addr, 0, yyvsp[-2].expr.str, yyvsp[0].expr.str, "");
			Gen(OGoto, 0, 0, 0, "", "", "");
        ;
    break;}
case 29:
#line 1022 "compile_sim.y"
{
            printf("����ʽ��rel -> expr >= expr\n");

            strcpy(yyval.rel.str, "");
            yyval.rel.type = 0;
			yyval.rel.addr = 0;
			yyval.rel.width = 0;
            yyval.rel.truelist = makelist(QuadTable.startaddr + QuadTable.len);
			yyval.rel.falselist = makelist(QuadTable.startaddr + QuadTable.len + 1 );
			Gen(OGEGoto, yyvsp[-2].expr.addr, yyvsp[0].expr.addr, 0, yyvsp[-2].expr.str, yyvsp[0].expr.str, "");
			Gen(OGoto, 0, 0, 0, "", "", "");
        ;
    break;}
case 30:
#line 1036 "compile_sim.y"
{ 	
            printf("����ʽ��rel -> expr\n"); 
	  		
			strcpy(yyval.rel.str,yyvsp[0].expr.str);
			yyval.rel.type = yyvsp[0].expr.type;
			yyval.rel.addr = yyvsp[0].expr.addr;
			yyval.rel.width = yyvsp[0].expr.width;
			yyval.rel.truelist = NULL;
			yyval.rel.falselist = NULL;
 	 	;
    break;}
case 31:
#line 1050 "compile_sim.y"
{
            printf("����ʽ��expr -> expr + term\n"); 
            
			yyval.expr.type = typeMax(yyvsp[-2].expr.type, yyvsp[0].term.type);
			switch (yyval.expr.type) {
				case BOOL: 
                    yyval.expr.width = BOOL_WIDTH; break;
				case CHAR: 
                    yyval.expr.width = CHAR_WIDTH; break;
	  	 	  	case INT: 
                    yyval.expr.width = INT_WIDTH; break;
				case FLOAT: 
                    yyval.expr.width = FLOAT_WIDTH; break;
				default: 
                    yyerror("�������ͷǷ�");
			}
			yyval.expr.addr = NewTemp(TopSymbolList, yyval.expr.str, yyval.expr.width);
			if(yyvsp[-2].expr.type == yyvsp[0].term.type) { // ���ý�������ת��
				if (yyvsp[-2].expr.type == INT) {
					Gen(OIntAdd, yyvsp[-2].expr.addr, yyvsp[0].term.addr, yyval.expr.addr, yyvsp[-2].expr.str, yyvsp[0].term.str, yyval.expr.str); 
				} 
                else if (yyvsp[-2].expr.type == FLOAT) {
					Gen(OFloatAdd, yyvsp[-2].expr.addr, yyvsp[0].term.addr, yyval.expr.addr, yyvsp[-2].expr.str, yyvsp[0].term.str, yyval.expr.str);
				} 
                else {
					yyerror("�����ͻ򸡵�������");
				}
			} 
            else if(yyvsp[-2].expr.type > yyvsp[0].term.type) { // ת���ɽϸ߲㼶expr������
				char tmpName[10];
     			int tmpAddr = typeWiden(yyvsp[0].term.addr, yyvsp[0].term.type, yyvsp[0].term.str, yyvsp[-2].expr.type, tmpName, TopSymbolList);
				if(yyvsp[-2].expr.type == INT) {
					Gen(OIntAdd, yyvsp[-2].expr.addr, tmpAddr, yyval.expr.addr, yyvsp[-2].expr.str, tmpName, yyval.expr.str);	
				} 
                else if(yyvsp[-2].expr.type == FLOAT) {
					Gen(OFloatAdd, yyvsp[-2].expr.addr, tmpAddr, yyval.expr.addr, yyvsp[-2].expr.str, tmpName, yyval.expr.str);
				} 
                else {
					yyerror("�����ͻ򸡵�������");	
				}				  
			}
            else { // ת���ɽϸ߲㼶term������
				char tmpName[10];
     			int tmpAddr = typeWiden(yyvsp[-2].expr.addr, yyvsp[-2].expr.type, yyvsp[-2].expr.str, yyvsp[0].term.type, tmpName, TopSymbolList);
				if(yyvsp[0].term.type == INT) {
					Gen(OIntAdd, tmpAddr, yyvsp[0].term.addr, yyval.expr.addr, tmpName, yyvsp[0].term.str, yyval.expr.str);
				} 
                else if(yyvsp[0].term.type == FLOAT) {
					Gen(OFloatAdd, tmpAddr, yyvsp[0].term.addr, yyval.expr.addr, tmpName, yyvsp[0].term.str, yyval.expr.str);
				} 
                else {
					yyerror("�����ͻ򸡵�������");	
				}			  
			}
			yyval.expr.truelist = NULL;
			yyval.expr.falselist = NULL;
        ;
    break;}
case 32:
#line 1109 "compile_sim.y"
{   
            printf("����ʽ��expr -> expr - term\n");

            yyval.expr.type = typeMax(yyvsp[-2].expr.type, yyvsp[0].term.type);
			switch (yyval.expr.type) {
				case BOOL: 
                    yyval.expr.width = BOOL_WIDTH; break;
				case CHAR: 
                    yyval.expr.width = CHAR_WIDTH; break;
	  	 	  	case INT: 
                    yyval.expr.width = INT_WIDTH; break;
				case FLOAT: 
                    yyval.expr.width = FLOAT_WIDTH; break;
				default: 
                    yyerror("�������ͷǷ�");
			}
			yyval.expr.addr = NewTemp(TopSymbolList, yyval.expr.str, yyval.expr.width);
			if(yyvsp[-2].expr.type == yyvsp[0].term.type) { // ���ý�������ת��
				if (yyvsp[-2].expr.type == INT) {
					Gen(OIntSub, yyvsp[-2].expr.addr, yyvsp[0].term.addr, yyval.expr.addr, yyvsp[-2].expr.str, yyvsp[0].term.str, yyval.expr.str); 
				} 
                else if (yyvsp[-2].expr.type == FLOAT) {
					Gen(OFloatSub, yyvsp[-2].expr.addr, yyvsp[0].term.addr, yyval.expr.addr, yyvsp[-2].expr.str, yyvsp[0].term.str, yyval.expr.str);
				} 
                else {
					yyerror("�����ͻ򸡵�������");
				}
			} 
            else if(yyvsp[-2].expr.type > yyvsp[0].term.type) { // ת���ɽϸ߲㼶expr������
				char tmpName[10];
     			int tmpAddr = typeWiden(yyvsp[0].term.addr, yyvsp[0].term.type, yyvsp[0].term.str, yyvsp[-2].expr.type, tmpName, TopSymbolList);
				if(yyvsp[-2].expr.type == INT) {
					Gen(OIntSub, yyvsp[-2].expr.addr, tmpAddr, yyval.expr.addr, yyvsp[-2].expr.str, tmpName, yyval.expr.str);	
				} 
                else if(yyvsp[-2].expr.type == FLOAT) {
					Gen(OFloatSub, yyvsp[-2].expr.addr, tmpAddr, yyval.expr.addr, yyvsp[-2].expr.str, tmpName, yyval.expr.str);
				} 
                else {
					yyerror("�����ͻ򸡵�������");	
				}				  
			} 
            else { // ת���ɽϸ߲㼶term������
				char tmpName[10];
     			int tmpAddr = typeWiden(yyvsp[-2].expr.addr, yyvsp[-2].expr.type, yyvsp[-2].expr.str, yyvsp[0].term.type, tmpName, TopSymbolList);
				if(yyvsp[0].term.type == INT) {
					Gen(OIntSub, tmpAddr, yyvsp[0].term.addr, yyval.expr.addr, tmpName, yyvsp[0].term.str, yyval.expr.str);
				} 
                else if(yyvsp[0].term.type == FLOAT) {
					Gen(OFloatSub, tmpAddr, yyvsp[0].term.addr, yyval.expr.addr, tmpName, yyvsp[0].term.str, yyval.expr.str);
				} 
                else {
					yyerror("�����ͻ򸡵�������");	
				}			  
			}
			yyval.expr.truelist = NULL;
			yyval.expr.falselist = NULL;
        ;
    break;}
case 33:
#line 1168 "compile_sim.y"
{
            printf("����ʽ��expr -> term\n");

            strcpy(yyval.expr.str, yyvsp[0].term.str);
		  	yyval.expr.type = yyvsp[0].term.type;
			yyval.expr.addr = yyvsp[0].term.addr;
		 	yyval.expr.width = yyvsp[0].term.width;
			yyval.expr.truelist = yyvsp[0].term.truelist;
			yyval.expr.falselist = yyvsp[0].term.falselist;
        ;
    break;}
case 34:
#line 1181 "compile_sim.y"
{
            printf("����ʽ��term -> term * unary\n");

            yyval.term.type = typeMax(yyvsp[-2].term.type, yyvsp[0].unary.type);
			switch (yyval.term.type) {
				case BOOL: 
                    yyval.term.width = BOOL_WIDTH; break;
				case CHAR: 
                    yyval.term.width = CHAR_WIDTH; break;
	  	 	  	case INT: 
                    yyval.term.width = INT_WIDTH; break;
				case FLOAT: 
                    yyval.term.width = FLOAT_WIDTH; break;
				default: 
                    yyerror("�������ͷǷ�");
			}
			yyval.term.addr = NewTemp(TopSymbolList, yyval.term.str, yyval.term.width);
			if(yyvsp[-2].term.type == yyvsp[0].unary.type) {
				if (yyvsp[-2].term.type == INT) {
					Gen(OIntMultiply, yyvsp[-2].term.addr, yyvsp[0].unary.addr, yyval.term.addr, yyvsp[-2].term.str, yyvsp[0].unary.str, yyval.term.str); 
				} 
                else if (yyvsp[-2].term.type == FLOAT) {
					Gen(OFloatMultiply, yyvsp[-2].term.addr, yyvsp[0].unary.addr, yyval.term.addr, yyvsp[-2].term.str, yyvsp[0].unary.str, yyval.term.str);
				} 
                else {
					yyerror("�����ͻ򸡵�������");
				}
			} 
            else if(yyvsp[-2].term.type > yyvsp[0].unary.type) {
				char tmpName[10];
     			int tmpAddr = typeWiden(yyvsp[0].unary.addr, yyvsp[0].unary.type, yyvsp[0].unary.str, yyvsp[-2].term.type, tmpName, TopSymbolList);
				if(yyvsp[-2].term.type == INT) {
					Gen(OIntMultiply, yyvsp[-2].term.addr, tmpAddr, yyval.term.addr, yyvsp[-2].term.str, tmpName, yyval.term.str);	
				} 
                else if(yyvsp[-2].term.type == FLOAT) {
					Gen(OFloatMultiply, yyvsp[-2].term.addr, tmpAddr, yyval.term.addr, yyvsp[-2].term.str, tmpName, yyval.term.str);
				} 
                else {
					yyerror("�����ͻ򸡵�������");	
				}				  
			} 
            else {
				char tmpName[10];
     			int tmpAddr = typeWiden(yyvsp[-2].term.addr, yyvsp[-2].term.type, yyvsp[-2].term.str, yyvsp[0].unary.type, tmpName, TopSymbolList);
				if(yyvsp[0].unary.type == INT) {
					Gen(OIntMultiply, tmpAddr, yyvsp[0].unary.addr, yyval.term.addr, tmpName, yyvsp[0].unary.str, yyval.term.str);
				} 
                else if(yyvsp[0].unary.type == FLOAT) {
					Gen(OFloatMultiply, tmpAddr, yyvsp[0].unary.addr, yyval.term.addr, tmpName, yyvsp[0].unary.str, yyval.term.str);
				} 
                else {
					yyerror("�����ͻ򸡵�������");	
				}			  
			}
			yyval.term.truelist = NULL;
			yyval.term.falselist = NULL;
        ;
    break;}
case 35:
#line 1240 "compile_sim.y"
{
            printf("����ʽ��term -> term / unary\n");

            yyval.term.type = typeMax(yyvsp[-2].term.type, yyvsp[0].unary.type);
			switch (yyval.term.type) {
				case BOOL: 
                    yyval.term.width = BOOL_WIDTH; break;
				case CHAR: 
                    yyval.term.width = CHAR_WIDTH; break;
	  	 	  	case INT: 
                    yyval.term.width = INT_WIDTH; break;
				case FLOAT: 
                    yyval.term.width = FLOAT_WIDTH; break;
				default: 
                    yyerror("�������ͷǷ�");
			}
			yyval.term.addr = NewTemp(TopSymbolList, yyval.term.str, yyval.term.width);
			if(yyvsp[-2].term.type == yyvsp[0].unary.type) {
				if (yyvsp[-2].term.type == INT) {
					Gen(OIntDivide, yyvsp[-2].term.addr, yyvsp[0].unary.addr, yyval.term.addr, yyvsp[-2].term.str, yyvsp[0].unary.str, yyval.term.str); 
				} 
                else if (yyvsp[-2].term.type == FLOAT) {
					Gen(OFloatDivide, yyvsp[-2].term.addr, yyvsp[0].unary.addr, yyval.term.addr, yyvsp[-2].term.str, yyvsp[0].unary.str, yyval.term.str);
				} 
                else {
					yyerror("�����ͻ򸡵�������");
				}
			} 
            else if(yyvsp[-2].term.type > yyvsp[0].unary.type) {
				char tmpName[10];
     			int tmpAddr = typeWiden(yyvsp[0].unary.addr, yyvsp[0].unary.type, yyvsp[0].unary.str, yyvsp[-2].term.type, tmpName, TopSymbolList);
				if(yyvsp[-2].term.type == INT) {
					Gen(OIntDivide, yyvsp[-2].term.addr, tmpAddr, yyval.term.addr, yyvsp[-2].term.str, tmpName, yyval.term.str);	
				} 
                else if(yyvsp[-2].term.type == FLOAT) {
					Gen(OFloatDivide, yyvsp[-2].term.addr, tmpAddr, yyval.term.addr, yyvsp[-2].term.str, tmpName, yyval.term.str);
				} 
                else {
					yyerror("�����ͻ򸡵�������");	
				}				  
			} 
            else {
				char tmpName[10];
     			int tmpAddr = typeWiden(yyvsp[-2].term.addr, yyvsp[-2].term.type, yyvsp[-2].term.str, yyvsp[0].unary.type, tmpName, TopSymbolList);
				if(yyvsp[0].unary.type == INT) {
					Gen(OIntDivide, tmpAddr, yyvsp[0].unary.addr, yyval.term.addr, tmpName, yyvsp[0].unary.str, yyval.term.str);
				} 
                else if(yyvsp[0].unary.type == FLOAT) {
					Gen(OFloatDivide, tmpAddr, yyvsp[0].unary.addr, yyval.term.addr, tmpName, yyvsp[0].unary.str, yyval.term.str);
				} 
                else {
					yyerror("�����ͻ򸡵�������");	
				}			  
			}
			yyval.term.truelist = NULL;
			yyval.term.falselist = NULL;
        ;
    break;}
case 36:
#line 1299 "compile_sim.y"
{
            printf("����ʽ��term -> unary\n");

            strcpy(yyval.term.str, yyvsp[0].unary.str);
			yyval.term.type = yyvsp[0].unary.type;	
			yyval.term.addr = yyvsp[0].unary.addr;
			yyval.term.width = yyvsp[0].unary.width;
			yyval.term.truelist = yyvsp[0].unary.truelist;
			yyval.term.falselist = yyvsp[0].unary.falselist;
        ;
    break;}
case 37:
#line 1312 "compile_sim.y"
{
            printf("����ʽ��unary -> !unary\n");
            strcpy(yyval.unary.str, yyvsp[0].unary.str);
			yyval.unary.type = yyvsp[0].unary.type;
			yyval.unary.addr = yyvsp[0].unary.addr;
		  	yyval.unary.width = yyvsp[0].unary.width;
			yyval.unary.truelist = yyvsp[0].unary.falselist;
			yyval.unary.falselist = yyvsp[0].unary.truelist;
        ;
    break;}
case 38:
#line 1323 "compile_sim.y"
{
            printf("����ʽ��unary -> -unary\n");
            yyval.unary.type = yyvsp[0].unary.type;
			yyval.unary.width = yyvsp[0].unary.width;
			yyval.unary.truelist = NULL;
			yyval.unary.falselist = NULL;	
		    yyval.unary.addr = NewTemp(TopSymbolList, yyval.unary.str, yyval.unary.width);
		    if(yyvsp[0].unary.type == INT) {
		    	Gen(OIntMinus, yyvsp[0].unary.addr, 0, yyval.unary.addr, yyvsp[0].unary.str, "", yyval.unary.str);
		    } 
            else if(yyvsp[0].unary.type == FLOAT) {
				Gen(OFloatMinus, yyvsp[0].unary.addr, 0, yyval.unary.addr, yyvsp[0].unary.str, "", yyval.unary.str);
		    } 
            else {
		    	yyerror("�����ͻ򸡵�������");
		    }			  
        ;
    break;}
case 39:
#line 1342 "compile_sim.y"
{
            printf("����ʽ��unary -> factor\n");
            strcpy( yyval.unary.str, yyvsp[0].factor.str );
			yyval.unary.type = yyvsp[0].factor.type;
			yyval.unary.addr = yyvsp[0].factor.addr;
			yyval.unary.width = yyvsp[0].factor.width;
			yyval.unary.truelist = yyvsp[0].factor.truelist;
			yyval.unary.falselist = yyvsp[0].factor.falselist;
        ;
    break;}
case 40:
#line 1354 "compile_sim.y"
{	
            printf("����ʽ��factor -> ( expr )\n");

            strcpy(yyval.factor.str, yyvsp[-1].expr.str);
			yyval.factor.type = yyvsp[-1].expr.type;
			yyval.factor.addr = yyvsp[-1].expr.addr;
			yyval.factor.width = yyvsp[-1].expr.width;
			yyval.factor.truelist = yyvsp[-1].expr.truelist;
			yyval.factor.falselist = yyvsp[-1].expr.falselist;
        ;
    break;}
case 41:
#line 1366 "compile_sim.y"
{
            printf("����ʽ��factor -> id\n");

	    	struct SymbolElem * p;
			p = LookUpAllSymbolList( TopSymbolList, yyvsp[0].id.name );
			if( p != NULL ) {
				strcpy( yyval.factor.str, p->name );
				yyval.factor.type  = p->type;
				yyval.factor.addr  = p->addr;
				yyval.factor.width = p->width;
			}					    
			else {
			    yyerror( "������û�ж���" );
				strcpy( yyval.factor.str, "no_id_defined" ); /*�ݴ�����*/
				yyval.factor.type = INT;
				yyval.factor.addr = -1;
				yyval.factor.width = INT_WIDTH;							    
			}
			yyval.factor.truelist = NULL;
			yyval.factor.falselist = NULL;
		;
    break;}
case 42:
#line 1389 "compile_sim.y"
{
            printf("����ʽ��factor -> num\n"); 

			struct ConstElem * p;
			p = LookUpConstList(yyvsp[0].constval.type, yyvsp[0].constval.value, yyvsp[0].constval.width) ;
			if(p == NULL) {
				p = AddToConstList(yyvsp[0].constval.str, yyvsp[0].constval.type, yyvsp[0].constval.value, yyvsp[0].constval.width);
			}
							  
			strcpy(yyval.factor.str, yyvsp[0].constval.str);
			yyval.factor.type = yyvsp[0].constval.type;
			yyval.factor.addr = p->addr;
			yyval.factor.width = p->width;
			yyval.factor.truelist = NULL;
			yyval.factor.falselist = NULL;
        ;
    break;}
}
   /* the action file gets copied in in place of this dollarsign */

  yyvsp -= yylen;
  yyssp -= yylen;
#ifdef YYLSP_NEEDED
  yylsp -= yylen;
#endif

#if YYDEBUG != 0
  if (yydebug)
    {
      short *ssp1 = yyss - 1;
      fprintf (stderr, "state stack now");
      while (ssp1 != yyssp)
	fprintf (stderr, " %d", *++ssp1);
      fprintf (stderr, "\n");
    }
#endif

  *++yyvsp = yyval;

#ifdef YYLSP_NEEDED
  yylsp++;
  if (yylen == 0)
    {
      yylsp->first_line = yylloc.first_line;
      yylsp->first_column = yylloc.first_column;
      yylsp->last_line = (yylsp-1)->last_line;
      yylsp->last_column = (yylsp-1)->last_column;
      yylsp->text = 0;
    }
  else
    {
      yylsp->last_line = (yylsp+yylen-1)->last_line;
      yylsp->last_column = (yylsp+yylen-1)->last_column;
    }
#endif

  /* Now "shift" the result of the reduction.
     Determine what state that goes to,
     based on the state we popped back to
     and the rule number reduced by.  */

  yyn = yyr1[yyn];

  yystate = yypgoto[yyn - YYNTBASE] + *yyssp;
  if (yystate >= 0 && yystate <= YYLAST && yycheck[yystate] == *yyssp)
    yystate = yytable[yystate];
  else
    yystate = yydefgoto[yyn - YYNTBASE];

  goto yynewstate;

yyerrlab:   /* here on detecting error */

  if (! yyerrstatus)
    /* If not already recovering from an error, report this error.  */
    {
      ++yynerrs;

#ifdef YYERROR_VERBOSE
      yyn = yypact[yystate];

      if (yyn > YYFLAG && yyn < YYLAST)
	{
	  int size = 0;
	  char *msg;
	  int x, count;

	  count = 0;
	  /* Start X at -yyn if nec to avoid negative indexes in yycheck.  */
	  for (x = (yyn < 0 ? -yyn : 0);
	       x < (sizeof(yytname) / sizeof(char *)); x++)
	    if (yycheck[x + yyn] == x)
	      size += strlen(yytname[x]) + 15, count++;
	  msg = (char *) malloc(size + 15);
	  if (msg != 0)
	    {
	      strcpy(msg, "parse error");

	      if (count < 5)
		{
		  count = 0;
		  for (x = (yyn < 0 ? -yyn : 0);
		       x < (sizeof(yytname) / sizeof(char *)); x++)
		    if (yycheck[x + yyn] == x)
		      {
			strcat(msg, count == 0 ? ", expecting `" : " or `");
			strcat(msg, yytname[x]);
			strcat(msg, "'");
			count++;
		      }
		}
	      yyerror(msg);
	      free(msg);
	    }
	  else
	    yyerror ("parse error; also virtual memory exceeded");
	}
      else
#endif /* YYERROR_VERBOSE */
	yyerror("parse error");
    }

  goto yyerrlab1;
yyerrlab1:   /* here on error raised explicitly by an action */

  if (yyerrstatus == 3)
    {
      /* if just tried and failed to reuse lookahead token after an error, discard it.  */

      /* return failure if at end of input */
      if (yychar == YYEOF)
	YYABORT;

#if YYDEBUG != 0
      if (yydebug)
	fprintf(stderr, "Discarding token %d (%s).\n", yychar, yytname[yychar1]);
#endif

      yychar = YYEMPTY;
    }

  /* Else will try to reuse lookahead token
     after shifting the error token.  */

  yyerrstatus = 3;		/* Each real token shifted decrements this */

  goto yyerrhandle;

yyerrdefault:  /* current state does not do anything special for the error token. */

#if 0
  /* This is wrong; only states that explicitly want error tokens
     should shift them.  */
  yyn = yydefact[yystate];  /* If its default is to accept any token, ok.  Otherwise pop it.*/
  if (yyn) goto yydefault;
#endif

yyerrpop:   /* pop the current state because it cannot handle the error token */

  if (yyssp == yyss) YYABORT;
  yyvsp--;
  yystate = *--yyssp;
#ifdef YYLSP_NEEDED
  yylsp--;
#endif

#if YYDEBUG != 0
  if (yydebug)
    {
      short *ssp1 = yyss - 1;
      fprintf (stderr, "Error: state stack now");
      while (ssp1 != yyssp)
	fprintf (stderr, " %d", *++ssp1);
      fprintf (stderr, "\n");
    }
#endif

yyerrhandle:

  yyn = yypact[yystate];
  if (yyn == YYFLAG)
    goto yyerrdefault;

  yyn += YYTERROR;
  if (yyn < 0 || yyn > YYLAST || yycheck[yyn] != YYTERROR)
    goto yyerrdefault;

  yyn = yytable[yyn];
  if (yyn < 0)
    {
      if (yyn == YYFLAG)
	goto yyerrpop;
      yyn = -yyn;
      goto yyreduce;
    }
  else if (yyn == 0)
    goto yyerrpop;

  if (yyn == YYFINAL)
    YYACCEPT;

#if YYDEBUG != 0
  if (yydebug)
    fprintf(stderr, "Shifting error token, ");
#endif

  *++yyvsp = yylval;
#ifdef YYLSP_NEEDED
  *++yylsp = yylloc;
#endif

  yystate = yyn;
  goto yynewstate;
}
#line 1407 "compile_sim.y"

#include "lex.yy.c"

int yyparse();  /*main����Ҫ����yyparse()���������ú����Ķ����ں��棬����Ҫ������(��������)*/

int main()
{
	char sourcefile[1000],destfile[1000];

	printf("������Ҫ�����Դ�����ļ���(�س�Ĭ��Ϊ��ǰ�ļ����µ��ĵ�code.txt)��"); 
    gets(sourcefile);
    if( strcmp( sourcefile,"")== 0 ) 
        strcpy( sourcefile, "code.txt");
	printf("���������м������ļ���(�س�Ĭ��Ϊ��ǰ�ļ����µ��ĵ�gencode.txt)��"); 
    gets(destfile);
    if( strcmp( destfile,"")== 0 ) 
        strcpy( destfile, "gencode.txt");

	BeginCompileOneFile( sourcefile );

    CreateConstList(3000);/*����������,����ӵ�ַ3000��ʼ����ռ������*/
    	/*��C���Ա������У��÷��ű����ڴ���ⲿ�������������ȡ�
     	 �����ǵ��﷨�в���֧���ⲿ�����ͺ��������Ըñ�û�б��õ�*/
   	TopSymbolList = CreateSymbolList( NULL, 2000 ); /*����ӵ�ַ2000��ʼ����ռ������*/
    CreateQuadTable(100); /*������Ԫʽ����������Ԫʽ�ӵ�ַ�ռ�100��ʼ���*/

    yyparse();

    PrintConstList();
    WriteQuadTableToFile( destfile ); /*����Ԫʽд�뵽�ļ�destfile��*/

    DestroyQuadTable();
    DestroySymbolList(TopSymbolList);
	DestroyConstList();

   	if( CompileFailed == 0 ) 
	    printf("����ɹ������ɵ���Ԫʽ���ļ�%s�С�\n", destfile );
	else
	    printf("Դ�ļ�%s�д��󣬱���ʧ�ܡ�\n", sourcefile );

	EndCompileOneFile();
        
	getchar();

	return 0;
}
