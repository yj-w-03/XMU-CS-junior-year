#include<stdio.h> 
#include "lex.yy.c"

int lookahead;
int line=1;

void match(int TokenID);
void program();
void block();
void decls();
void decl();
void type();
void stmts();
void stmt();
void rstmt();
void _bool();
void rbool();
void expr();
void rexpr();
void term();
void rterm();
void factor();


void match(int Token)
{
    if(lookahead == Token) 
		lookahead = yylex();
	else
        printf("\nError in match() at line %d!\n",line);
}

void program()
{
	switch(lookahead) {
		case '{':
			printf("program -> block\n");
			block();
			break;
		default:
			printf("\nError in program() at line %d!\n",line);
			exit(1);
	}
}

void block()
{
	switch(lookahead) {
		case '{':
			printf("block -> { decls stmts }\n");
			match('{');decls();stmts();match('}');
			break;
		default:
			printf("\nError in block() at line %d!\n",line);
			exit(1);
	}
}

void decls()
{
	switch(lookahead) {
		case IF:case ID:case WHILE:case DO:case BREAK:
		case '{':case '}':
			printf("decls -> epsilon\n");
			break;
		case INT:case FLOAT:case CHAR:
			printf("decls -> decl decls\n");
			decl();decls();
			break;
		default:
			printf("\nError in decls() at line %d!\n",line);
			exit(1);
	}
}

void decl()
{
	switch(lookahead) {
		case INT:case FLOAT:case CHAR:
			printf("decl -> type ID ;\n");
			type();match(ID);match(';');
			break;
		default:
			printf("\nError in decl() at line %d!\n",line);
			exit(1);
	}
}

void type()
{
	switch(lookahead) {
		case INT:
			printf("type -> int\n");
			match(INT);
			break;
		case FLOAT:
			printf("type -> float\n");
			match(FLOAT);
			break;
		case CHAR:
			printf("type -> char\n");
			match(CHAR);
			break;
		default:
			printf("\nError in type() at line %d!\n",line);
			exit(1);
	}
}

void stmts()
{
	switch(lookahead) {
		case '}':
			printf("stmts -> epsilon\n");
			break;
		case IF:case ID:case WHILE:case DO:case BREAK:case '{':
			printf("stmts -> stmt stmts\n");
			stmt();stmts();
			break;
		default:
			printf("\nError in stmts() at line %d!\n",line);
			exit(1);
	}
}

void stmt()
{
	switch(lookahead) {
		case IF:
			printf("stmt -> if ( bool ) stmt rstmt\n");
			match(IF);match('(');_bool();match(')');stmt();rstmt();
			break;
		case ID:
			printf("stmt -> id = expr;\n");
			match(ID);match('=');expr();match(';');
			break;
		case WHILE:
			printf("stmt -> while ( bool ) stmt\n");
			match(WHILE);match('(');_bool();match(')');stmt();
			break;
		case DO:
			printf("stmt -> do stmt while ( bool ) ;\n");
			match(DO);match(WHILE);match('(');_bool();match(')');match(';');
			break;
		case BREAK:
			printf("stmt -> break ;\n");
			match(BREAK);match(';');
			break;
		case '{':
			printf("stmts -> block\n");
			block();
			break;
		default:
			printf("\nError in stmt() at line %d!\n",line);
			exit(1);
	}
}

void rstmt()
{
	switch(lookahead) {
		case IF:case ID:case WHILE:case DO:case BREAK:
		case '{':case '}':
			printf("rstmt -> epsilon\n");
			break;
		case ELSE:
			printf("rstmt -> else stmt\n");
			match(ELSE);
			stmt();
			break;
		default:
			printf("\nError in rstmt() at line %d!\n",line);
			exit(1);
	}
}

void _bool()
{
	switch(lookahead) {
		case '(':case ID:case NUM:
			printf("bool -> expr rbool\n");
			expr();rbool();
			break;
		default:
			printf("\nError in _bool() at line %d!\n",line);
			exit(1);
	}
}

void rbool()
{
	switch(lookahead) {
		case ')':
			printf("rbool -> epsilon\n");
			break;
		case RELOP_LT:
			printf("rbool -> < expr\n");
			match(RELOP_LT);
			expr();
			break;
		case RELOP_LE:
			printf("rbool -> <= expr\n");
			match(RELOP_LE);
			expr();
			break;
		case RELOP_GT:
			printf("rbool -> > expr\n");
			match(RELOP_GT);
			expr();
			break;
		case RELOP_GE:
			printf("rbool -> >= expr\n");
			match(RELOP_GE);
			expr();
			break;
		default:
			printf("\nError in rbool() at line %d!\n",line);
			exit(1);
	}
}

void expr()
{
	switch(lookahead) {
		case '(':case ID:case NUM:
			printf("expr -> term  rexpr\n");
			term();rexpr();
			break;
		default:
			printf("\nError in expr() at line %d!\n",line);
			exit(1);
	}	
}

void rexpr()
{
	switch(lookahead) {
		case RELOP_LT:case RELOP_LE:case RELOP_GT:case RELOP_GE:
		case ';':case ')':
			printf("rexpr -> epsilon\n");
			break;
		case '+':
			printf("rexpr -> + term rexpr\n");
			match('+');term();rexpr();
			break;
		case '-':
			printf("rexpr -> - term rexpr\n");
			match('-');term();rexpr();
			break;
		default:
			printf("\nError in rexpr() at line %d!\n",line);
			exit(1);
	}
}

void term()
{
	switch(lookahead) {
		case '(':case ID:case NUM:
			printf("term -> factor rterm\n");
			factor();rterm();
			break;
		default:
			printf("\nError in term() at line %d!\n",line);
			exit(1);
	}
}

void rterm()
{
	switch(lookahead) {
		case '+':case '-':case ';':case ')':
		case RELOP_LT:case RELOP_LE:case RELOP_GT:case RELOP_GE:
			printf("rterm -> epsilon\n");
			break;
		case '*':
			printf("rterm -> * factor rterm\n");
			match('*');factor();rterm();
			break;
		case '/':
			printf("rterm -> / factor rterm\n");
			match('/');factor();rterm();
			break;
		default:
			printf("\nError in rterm() at line %d!\n",line);
			exit(1);
	}
}

void factor()
{
	switch(lookahead) {
		case '(':
			printf("factor -> ( expr )\n");
			match('(');expr();match(')');
			break;
		case ID:
			printf("factor -> id\n");
			match(ID);
			break;
		case NUM:
			printf("factor -> num\n");
			match(NUM);
			break;
		default:
			printf("\nError in factor() at line %d!\n",line);
			exit(1);
	}
}

int main()
{
    lookahead = yylex();
	program();
	return 0;
}

