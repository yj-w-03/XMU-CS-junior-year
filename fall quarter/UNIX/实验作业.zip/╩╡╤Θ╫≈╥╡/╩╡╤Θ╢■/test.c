#include<stdio.h>
#include <string.h>
int main()
{
    char*a;
    char*b;
    a="123";
    b="456";
    //strcat(a,b);
    printf("%s",b+2);
}

