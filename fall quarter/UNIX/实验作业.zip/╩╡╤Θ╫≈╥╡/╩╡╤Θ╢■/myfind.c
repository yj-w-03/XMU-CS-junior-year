#include "apue.h"
#include <dirent.h>
#include <limits.h>
#include <fcntl.h>



/* function type that is called for each filename */
typedef	int	Myfunc(const char *, const struct stat *, int);

static Myfunc	myfunc,myfunc2,myfunc3;
static int		myftw(char *, Myfunc *);
static int		dopath(Myfunc *);
static char *getFullPath(const char *pathname, char *fullpathname);
static int getFileNamePosition(const char *pathname);

static char *filebuf, *comparebuf, *inputpath, *inputfilepath, *inputfilename;
static long	nreg, ndir, nblk, nchr, nfifo, nslink, nsock, ntot, nsizeless,filesize;

int
main(int argc, char *argv[])
{
    int	ret,position;
    size_t len;
    struct stat statbuf;
    if (!(argc == 2 || (argc == 4 && strcmp(argv[2], "-comp") == 0) || (argc >= 4 && strcmp(argv[2], "-name") == 0)))
        err_quit("usage:  myfind <pathname> [-comp <filename> | -name <str>…]");
    //<pathname>既可以是目录，也可以是文件，此时，目录为当前工作目录
    if (lstat(argv[1], &statbuf) < 0) {
        err_quit("lstat error: %s\n", argv[1]);
    }
    if (S_ISDIR(statbuf.st_mode) == 0)  /* not a directory */
        strcpy(argv[1], ".");
    if (argc == 2) {//功能一
        ret = myftw(argv[1], myfunc);        /* does it all */
        ntot = nreg + ndir + nblk + nchr + nfifo + nslink + nsock;
        if (ntot == 0)
            ntot = 1;        /* avoid divide by 0; print 0 for all counts */
        
        printf("regular files  = %7ld, %5.2f %%\n", nreg,
               nreg * 100.0 / ntot);
        if (nreg == 0)
            nreg = 1;

        printf("less than 4096  = %7ld, %5.2f %%\n", nsizeless,
            nsizeless * 100.0 / nreg);
        printf("directories    = %7ld, %5.2f %%\n", ndir,
               ndir * 100.0 / ntot);
        printf("block special  = %7ld, %5.2f %%\n", nblk,
               nblk * 100.0 / ntot);
        printf("char special   = %7ld, %5.2f %%\n", nchr,
               nchr * 100.0 / ntot);
        printf("FIFOs          = %7ld, %5.2f %%\n", nfifo,
               nfifo * 100.0 / ntot);
        printf("symbolic links = %7ld, %5.2f %%\n", nslink,
               nslink * 100.0 / ntot);
        printf("sockets        = %7ld, %5.2f %%\n", nsock,
               nsock * 100.0 / ntot);
    }
    if(argc == 4 && strcmp(argv[2], "-comp") == 0){//功能二
        if(lstat(argv[3],&statbuf)<0)
            err_sys("lstat error\n");
        int fd,position;
        filesize=statbuf.st_size;//获取filename文件长度
        if ((fd = open(argv[3], O_RDONLY, FILE_MODE)) == -1)//获取文件描述符
            err_sys("can't open the file '%s'\n", argv[3]);
        if ((filebuf = (char*)malloc(sizeof(char) * filesize)) == NULL ||
            (comparebuf = (char*)malloc(sizeof(char) * filesize)) == NULL)
            err_sys("malloc error\n");
        read(fd, filebuf, filesize);//把filename文件内容写入filebuf,等待被比较
        close(fd);
        size_t len;
        inputpath= path_alloc(&len);
        getFullPath(argv[1],inputpath);//把待查找路径路径转化为绝对路径
        char *inputfiledir;
        //以下做法是因为getcwd取出的绝对路径不含文件名
        inputfiledir = path_alloc(&len);
        position=getFileNamePosition(argv[3]);
        if (position == 0) {//获取不带文件名的目录
            strcpy(inputfiledir, ".");
        }
        else {
            strncpy(inputfiledir, argv[3], position);
        }
        inputfilepath = path_alloc(&len);
        getFullPath(inputfiledir, inputfilepath);//获取目录的绝对路径
        strcat(inputfilepath, argv[3]+position);//目录绝对路径加上文件名，就是文件的绝对路径了
        printf("\n The contents of the files under the following absolute paths are the same as '%s'\n", argv[3]);
        ret = myftw(inputpath, myfunc2);//查找

    }
    if(argc >= 4 && strcmp(argv[2], "-name") == 0){//功能三
        size_t len;
        int i;
        inputpath= path_alloc(&len);
        inputfilename= path_alloc(&len);
        getFullPath(argv[1],inputpath);//把pathname转化为绝对路径
        for(i=3;i<argc;i++){
            strncpy(inputfilename,argv[i],len);//待比较的filename
            printf("\n%d. The file names under the following absolute paths are the same as '%s':\n", i - 2, argv[i]);
            ret = myftw(inputpath, myfunc3);//对每个待比较的filename，调用一次查找
        }

    }
    exit(ret);
}

/*
 * Descend through the hierarchy, starting at "pathname".
 * The caller's func() is called for every file.
 */
#define	FTW_F	1		/* file other than directory */
#define	FTW_D	2		/* directory */
#define	FTW_DNR	3		/* directory that can't be read */
#define	FTW_NS	4		/* file that we can't stat */

static char	*fullpath;		/* contains full pathname for every file */
static size_t pathlen;

static int					/* we return whatever func() returns */
myftw(char *pathname, Myfunc *func)
{
    
    fullpath = path_alloc(&pathlen);	/* malloc PATH_MAX+1 bytes */
    /* ({Prog pathalloc}) */
    if (pathlen <= strlen(pathname)) {
        pathlen = strlen(pathname) * 2;
        if ((fullpath = realloc(fullpath, pathlen)) == NULL)
            err_sys("realloc failed");
    }
    strcpy(fullpath, pathname);
    return(dopath(func));
}

/*
 * Descend through the hierarchy, starting at "fullpath".
 * If "fullpath" is anything other than a directory, we lstat() it,
 * call func(), and return.  For a directory, we call ourself
 * recursively for each name in the directory.
 */
static int					/* we return whatever func() returns */
dopath(Myfunc* func)
{
    struct stat		statbuf;
    struct dirent	*dirp;
    DIR				*dp;
    int				ret, n;
    char *ptr;

    if (lstat(fullpath, &statbuf) < 0)	/* stat error */
        return(func(fullpath, &statbuf, FTW_NS));
    if (S_ISDIR(statbuf.st_mode) == 0)	/* not a directory */
        return(func(fullpath, &statbuf, FTW_F));

    /*
     * It's a directory.  First call func() for the directory,
     * then process each filename in the directory.
     */
    if ((ret = func(fullpath, &statbuf, FTW_D)) != 0)
        return(ret);
    /*
    n = strlen(fullpath);
    if (n + NAME_MAX + 2 > pathlen) {	//expand path buffer 
        pathlen *= 2;
        if ((fullpath = realloc(fullpath, pathlen)) == NULL)
            err_sys("realloc failed");
    }
    fullpath[n++] = '/';
    fullpath[n] = 0;
    */

    ptr = fullpath + strlen(fullpath);  // point to end of fullpath 
    //为了避免出现"//"，做了以下修改
    if (*(ptr - 1) != '/') {  //只有当不是以斜杠结尾时，才需要加斜杠，否则会出现双斜杠
        *ptr++ = '/'; //保证是目录的路径以单斜杠结尾 
        *ptr = 0;
    }

    if ((dp = opendir(fullpath)) == NULL)	/* can't read directory */
        return(func(fullpath, &statbuf, FTW_DNR));

    while ((dirp = readdir(dp)) != NULL) {
        if (strcmp(dirp->d_name, ".") == 0  ||
            strcmp(dirp->d_name, "..") == 0)
            continue;		/* ignore dot and dot-dot */
        //strcpy(&fullpath[n], dirp->d_name);	/* append name after "/" */
        strcpy(ptr, dirp->d_name);
        if ((ret = dopath(func)) != 0)		/* recursive */
            break;	/* time to leave */
    }
    //fullpath[n-1] = 0;	/* erase everything from slash onward */

    if (closedir(dp) < 0)
        err_ret("can't close directory %s", fullpath);
    return(ret);
}

static int
myfunc(const char *pathname, const struct stat *statptr, int type)
{
    switch (type) {
        case FTW_F:
            switch (statptr->st_mode & S_IFMT) {
                case S_IFREG:	nreg++;		//常规文件
                    if(statptr->st_size <= 4096)//统计文件长度不大于4096字节的常规文件
                        nsizeless++;
                    break;
                case S_IFBLK:	nblk++;		break;//块特殊文件
                case S_IFCHR:	nchr++;		break;//字符特殊文件
                case S_IFIFO:	nfifo++;	break;//管道或FIFO
                case S_IFLNK:	nslink++;	break;//符号链接
                case S_IFSOCK:	nsock++;	break;//套接字

                //为了不输出无关路径，把它们注释掉
                /*
                case S_IFDIR:	// directories should have type = FTW_D
                    err_dump("for S_IFDIR for %s", pathname);
                */
            }
            break;
        case FTW_D:
            ndir++;
            break;
        case FTW_DNR:
            //err_ret("can't read directory %s", pathname);
            break;
        case FTW_NS:
            //err_ret("stat error for %s", pathname);
            break;
        // default:;
        //     //err_dump("unknown type %d for pathname %s", type, pathname);
    }
    return(0);
}

static char*
getFullPath(const char *pathname, char *fullpathname){//获取pathname的绝对路径fullpathname
    size_t len;
    char *srcpath, *p;
    srcpath= path_alloc(&len);
    if(getcwd(srcpath,len)==NULL)//保存原来的目录
        err_sys("getcwd fail\n");
    if(chdir(pathname)<0)//改变当前工作目录
        err_sys("chdir fail\n");
    if(getcwd(fullpathname,len)==NULL)//获得绝对路径
        err_sys("getcwd fail\n");
    p=fullpathname+strlen(fullpathname);//把指针移到尾部
    if (*(p-1) != '/') {//保证目录的绝对路径以斜杠结尾
        *p++ = '/';
        *p = 0;
    }
    if (chdir(srcpath) < 0)//回到原来的目录
        err_sys("can't chdir: %s\n", pathname);
    return fullpathname;
}

static int
getFileNamePosition(const char *pathname){//过滤掉目录，返回文件名开头地址
    int i, position = 0;
    for (i = strlen(pathname)-1; i >= 0; i-- ) {
        if (pathname[i] == '/') {
            position = i;
            break;
        }
    }
    return (position == 0) ? position : position + 1;//返回文件名开头地址
}

static int
myfunc2(const char *pathname, const struct stat *statptr, int type){//这里的pathname已经是绝对路径了
    if(type==FTW_F&&statptr->st_size==filesize){//当文件长度一致才能继续比较内容
        int fd;
        if((fd=open(pathname,O_RDONLY,FILE_MODE))==-1)
            return 0;
        read(fd,comparebuf,filesize);

        close(fd);
        if(strcmp(filebuf,comparebuf)==0)//如果内容一致，输出绝对路径
            printf("%s\n",pathname);

    }
    return 0;
}

static int
myfunc3(const char *pathname, const struct stat *statptr, int type){//这里的pathname已经是绝对路径了
    int position;
    if(type==FTW_F){
        position= getFileNamePosition(pathname);
        if(strcmp(inputfilename,pathname+position)==0){//取出绝对路径中的文件名，与此时的filename比较
            printf("%s\n",pathname);//输出绝对路径
        }
    }
    return 0;
}




