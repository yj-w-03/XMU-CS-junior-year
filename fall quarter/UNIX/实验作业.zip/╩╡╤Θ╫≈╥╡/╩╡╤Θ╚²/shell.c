#include "apue.h"
#include <sys/wait.h>

int
main(void)
{
	char	buf[MAXLINE];	/* from apue.h */
	pid_t	pid;
	int		status;
    int i=0,index=0,len;
    extern char **environ;

	printf("%% ");	/* print prompt (printf requires %% to print %) */
	while (fgets(buf, MAXLINE, stdin) != NULL) {
		if (buf[strlen(buf) - 1] == '\n')
			buf[strlen(buf) - 1] = 0; /* replace newline with null */

		if ((pid = fork()) < 0) {
			err_sys("fork error");
		} else if (pid == 0) {		/* child */
            char *argv[80];//数组中各指针指向的字符串，利用buf的存储空间
            while(buf[i]==' '){//移动到不是空格处
                i++;
            }
            argv[index++]=buf+i;//第一个参数
            len=strlen(buf);
            for(;i<len;i++){
                if(buf[i]==' '){
                    buf[i]='\0';
                }
                else{
                    if(buf[i-1]=='\0'&&(i-1)>=0){
                        argv[index++]=buf+i;
                    }
                }
            }
            argv[index]=NULL;//argv数组的最后一个指针必须为NULL


			//execlp(buf, buf, (char *)0);
            execve(argv[0],argv,environ);//执行用户输入的命令

			err_ret("couldn't execute: %s", buf);
			exit(127);
		}

		/* parent */
		if ((pid = waitpid(pid, &status, 0)) < 0)
			err_sys("waitpid error");
		printf("%% ");
	}
	exit(0);
}