#include "apue.h"
#include <setjmp.h>
#include <sys/wait.h>

static volatile pid_t pid;    /* ����ӽ���ID����0��ʾ����ִ���û����� */
static sigjmp_buf jmpbuf;

static void sig_alrm(int);    /* our signal-catching function */
static void sig_quit(int);    /* our signal-catching function */
Sigfunc* signal(int, Sigfunc*);  /* Reliable version of signal() */


int
main(int argc, char* argv[])
{
    char  buf[MAXLINE]; /* from apue.h */
    int   status;
    int time = 0;

    /* �������� */
    if (argc != 1 && argc != 3)
        err_quit("usage: myshell [-t <time>] ");
    if (argc == 3 && strcmp(argv[1], "-t") != 0) {
        err_quit("usage: myshell [-t <time>] ");
    }
    else {
        time = atoi(argv[2]);
    }

    /* ע���ź� */
    if (signal(SIGALRM, sig_alrm) == SIG_ERR)
        err_sys("signal error");
    if (signal(SIGQUIT, sig_quit) == SIG_ERR)
        err_sys("signal error");

    sigsetjmp(jmpbuf, 1); /* ������ת�� */

    printf("%% ");  /* print prompt (printf requires %% to print %) */
    while (fgets(buf, MAXLINE, stdin) != NULL) {
        if (buf[strlen(buf) - 1] == '\n')
            buf[strlen(buf) - 1] = 0; /* replace newline with null */

        if (time) alarm(time);  /* ���û�����ִ��ǰ�������� */

        if ((pid = fork()) < 0) {
            err_sys("fork error");
        }
        else if (pid == 0) {    /* child */
            execlp("/bin/sh", "sh", "-c", buf, (char*)0); /* ʹ��ϵͳshell */
            err_ret("couldn't execute: %s", buf);
            exit(127);
        }

        /* parent */
        if ((pid = waitpid(pid, &status, 0)) < 0)
            err_sys("waitpid error");

        if (time) alarm(0);   /* ���û�����ִ����ɺ�Ӧ�������� */

        printf("%% ");
    }
    exit(0);
}

/* Reliable version of signal(), using POSIX sigaction().  */
Sigfunc*
signal(int signo, Sigfunc* func)
{
    struct sigaction  act, oact;

    act.sa_handler = func;
    sigemptyset(&act.sa_mask);
    act.sa_flags = 0;

    /* �ڴ�������һ���ź�ʱ��������һ���ź� */
    if (signo == SIGALRM) {
        sigaddset(&act.sa_mask, SIGQUIT);
    }
    else if (signo == SIGQUIT) {
        sigaddset(&act.sa_mask, SIGALRM);
    }

    if (signo == SIGALRM) {
#ifdef  SA_INTERRUPT
        act.sa_flags |= SA_INTERRUPT;
#endif
    }
    else {
#ifdef  SA_RESTART
        act.sa_flags |= SA_RESTART;
#endif
    }
    if (sigaction(signo, &act, &oact) < 0)
        return(SIG_ERR);
    return(oact.sa_handler);
}

void
sig_alrm(int signo)
{
    if (pid > 0) {
        kill(pid, SIGKILL);
        pid = 0;
    }
    printf("\n *** TIMEOUT ***\n");


    sigset_t pendmask;
    if (sigemptyset(&pendmask) < 0)
        err_sys("sigemptyset error!");
    if (sigpending(&pendmask) < 0)
        err_sys("sigpending error!");
    if (sigismember(&pendmask, SIGQUIT)) {  /* ����δ���ź� */
        signal(SIGQUIT, SIG_IGN);     /* ���δ���ź� */
        signal(SIGQUIT, sig_quit);      /* �ָ�֮ǰ�Ĵ�����ʽ */
    }

    siglongjmp(jmpbuf, 1);

}

void
sig_quit(int signo)
{
    if (pid > 0) {
        kill(pid, SIGKILL);
        pid = 0;
    }
    printf("\n*** QUIT *** \n");
    alarm(0); /* ������� */

    sigset_t pendmask;
    if (sigemptyset(&pendmask) < 0)
        err_sys("sigemptyset error!");
    if (sigpending(&pendmask) < 0)
        err_sys("sigpending error!");
    if (sigismember(&pendmask, SIGALRM)) {  /* ����δ���ź� */
        signal(SIGALRM, SIG_IGN);     /* ���δ���ź� */
        signal(SIGALRM, sig_alrm);      /* �ָ�֮ǰ�Ĵ�����ʽ */
    }

    siglongjmp(jmpbuf, 1);
}