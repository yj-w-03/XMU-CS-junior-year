import socket
import time

if __name__ == '__main__':
    ip = '127.0.0.1'
    port = input("请输入服务器绑定的端口：")
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    addr = (ip, int(port))
    s.bind(addr)
    # 建立字典，用于判断用户名是否已经存在
    user = {}  # {addr:name}
    while True:
        # 异常捕捉
        try:
            data, addr = s.recvfrom(1024)
            # 新用户昵称注册
            if not addr in user.keys():
                # 如果昵称重复，提示重新输入
                if data.decode('utf-8') in user.values():
                    s.sendto("该昵称已被使用，请重新输入:".encode('utf-8'), addr)
                    continue
                # 如果昵称不重复，注册成功，进入聊天室
                else:
                    for address in user.keys():
                        s.sendto(data + ' 进入聊天室...'.encode('utf-8'), address)
                    user[addr] = data.decode('utf-8')
                    s.sendto("注册成功".encode('utf-8'), addr)
                    continue
            # 用户输入exit退出聊天室
            if 'exit' in data.decode('utf-8'):
                name = user[addr]
                user.pop(addr)
                for address in user:
                    s.sendto((name + ' 离开了聊天室...').encode(), address)
            # 服务器显示用户聊天信息
            else:
                print("{'%s' from ('%s' , %s)} " % (data.decode('utf-8'), addr[0], addr[1]) , end="")
                print(time.strftime("%Y-%m-%d %H:%M:%S", time.localtime()))
                for address in user:
                    if address != addr:
                        s.sendto(data, address)

        except ConnectionResetError:
            print('------------客户机异常退出------------')



