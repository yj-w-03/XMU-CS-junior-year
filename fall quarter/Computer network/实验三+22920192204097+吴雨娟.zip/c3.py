import socket
import threading

def recv(sock, addr, name):
    while True:
        # 异常捕捉
        try:
            data = sock.recv(1024)
            print(data.decode('utf-8'))
        except ConnectionResetError:
            print("------------服务器连接失败------------")


def send(sock, addr, name):
    while True:
        # 异常捕捉
        try:
            string = input()
            message = name + ' : ' + string
            data = message.encode('utf-8')
            sock.sendto(data, addr)
            if string == 'exit':
                print("------------连接关闭-------------")
                break
        except ConnectionResetError:
            print("------------服务器连接失败------------")


if __name__ == '__main__':
    ip = input("请输入服务器的IP:")
    port = input("请输入服务器绑定的端口号:")
    print("-----欢迎来到聊天室,退出聊天室请输入'exit'-----")
    # 提示用户输入昵称
    name = input('输入你的昵称:')
    port = int(port)
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    server = (ip,port)

    s.sendto(name.encode('utf-8'), server)
    # 通过服务器的回复判断昵称是否重复，如果重复，提示重新输入，直到不重复为止
    while s.recv(1024).decode('utf-8') == "该昵称已被使用，请重新输入:":
        print("该昵称已被使用，请重新输入:", end="")
        newname = input()
        name = newname
        s.sendto(name.encode('utf-8'), server)
    print('-----------------%s------------------' % name)

    # 创建线程
    tr = threading.Thread(target=recv, args=(s, server, name), daemon=True)
    ts = threading.Thread(target=send, args=(s, server, name))
    tr.start()
    ts.start()
    ts.join()
    s.close()
