#include "addition.h"

#include <iostream>
using namespace std;

char checksum(char *frame, int count) {   //计算校验和
    u_long sum = 0;
    while (count--) {
        sum += *frame++;
        if (sum & 0xFFFF0000) {
            sum &= 0xFFFF;
            sum++; 
        }
    }
    return (sum & 0xFFFF);
}

int create_frame(int seq_num, char *frame, char *data, int data_size, bool eot) {   //构造帧
    frame[0] = eot ? 0x0 : 0x1;   //第一个字节是EOT标志
    uint32_t net_seq_num = htonl(seq_num);   //序列号
    uint32_t net_data_size = htonl(data_size);   //数据字段长度
    memcpy(frame + 1, &net_seq_num, 4);   //序列号4字节，数据长度字段4字节，接着是数据部分
    memcpy(frame + 5, &net_data_size, 4);
    memcpy(frame + 9, data, data_size);
    frame[data_size + 9] = checksum(frame, data_size + (int) 9);   //最后是校验和

    return data_size + (int)10;
}

void create_ack(int seq_num, char *ack, bool error) {   //构造ack回复
    ack[0] = error ? 0x0 : 0x1;   //是否出错？
    uint32_t net_seq_num = htonl(seq_num);   //序列号
    memcpy(ack + 1, &net_seq_num, 4);   
    ack[5] = checksum(ack, ACK_SIZE - (int) 1);   //校验和
}

bool read_frame(int *seq_num, char *data, int *data_size, bool *eot, char *frame) {   //读帧，读帧和读ack都没有检验校验和，可以加上
    *eot = frame[0] == 0x0 ? true : false;   //EOT标志

    uint32_t net_seq_num;   //序列号
    memcpy(&net_seq_num, frame + 1, 4);
    *seq_num = ntohl(net_seq_num);  

    uint32_t net_data_size;   //数据长度
    memcpy(&net_data_size, frame + 5, 4);
    *data_size = ntohl(net_data_size);

    memcpy(data, frame + 9, *data_size);   //数据部分

    return frame[*data_size + 9] != checksum(frame, *data_size + (int) 9);
}

bool read_ack(int *seq_num, bool *neg, char *ack) {   //读ack
    *neg = ack[0] == 0x0 ? true : false;   //是否出错

    uint32_t net_seq_num;
    memcpy(&net_seq_num, ack + 1, 4);   //序列号
    *seq_num = ntohl(net_seq_num);

    return ack[5] != checksum(ack, ACK_SIZE - (int) 1);
}
