#include <iostream>
#include <thread>

#include <stdio.h>
#include <sys/socket.h>
#include <netdb.h>
#include <unistd.h>
#include <arpa/inet.h>

#include "addition.h"

#define random(x) (rand() % x) //产生随机数

#define ByeBye 3000 //挥手等待3000ms

using namespace std;

int socket_fd, connect_fd;
struct sockaddr_in server_address, client_address;

void send_ack()
{ //TCP关闭时，接收到任何消息，都回复ack
  char frame[MAX_FRAME_SIZE];
  char data[MAX_DATA_SIZE];
  char ack[ACK_SIZE];
  int frame_size;
  int data_size;

  int recv_seq_num;
  bool frame_error;
  bool eot;

  /* Listen for frames and send ack */
  while (true)
  {
    frame_size = recv(connect_fd, frame, MAX_FRAME_SIZE, 0);
    frame_error = read_frame(&recv_seq_num, data, &data_size, &eot, frame);

    create_ack(recv_seq_num, ack, frame_error);
    send(connect_fd, ack, ACK_SIZE, 0);
  }
}

int main(int argc, char *argv[])
{
  int port;            //端口号
  int window_len;      //TCP滑动窗口大小
  int max_buffer_size; //最大缓冲区长度
  char *fname;         //接收到数据保存在该文件中
  double lost_rate;    //丢包率

  srand((int)time(0));

  if (argc == 6)
  { //输入参数：文件名 窗口大小 缓冲区大小 端口号 丢包率
    fname = argv[1];
    window_len = (int)atoi(argv[2]);
    max_buffer_size = MAX_DATA_SIZE * (int)atoi(argv[3]); //每个帧按最大数据长度计算，比如输入1000，代表缓冲区长度是1000个最大数据长(1024 Byte)
    port = atoi(argv[4]);
    lost_rate = atof(argv[5]);
  }
  else
  {
    cerr << "usage: ./recvfile <filename> <window_size> <buffer_size> <port> <loss_rate>" << endl;
    return 1;
  }

  memset(&server_address, 0, sizeof(server_address));
  memset(&client_address, 0, sizeof(client_address));

  /* Fill server address data structure */
  server_address.sin_family = AF_INET;                //使用TCP/IP-IPv4协议
  server_address.sin_addr.s_addr = htonl(INADDR_ANY); //本机
  server_address.sin_port = htons(port);              //绑定端口

  /* Create socket_fd file descriptor */
  if ((socket_fd = socket(AF_INET, SOCK_STREAM, 0)) < 0)
  { //创建套接字
    cerr << "socket_fd creation failed" << endl;
    return 1;
  }

  /* Bind socket_fd to server address */
  if (bind(socket_fd, (const struct sockaddr *)&server_address, //绑定服务器地址及端口号
           sizeof(server_address)) < 0)
  {
    cerr << "socket_fd binding failed" << endl;
    return 1;
  }
  cout << WHITE << "Bind socket to port: " << port << " successfully." << endl;

  if (listen(socket_fd, 1) < 0)
  {
    cerr << "listen error." << endl;
    return 1;
  }
  cout << "listening..." << endl;

  FILE *file = fopen(fname, "wb"); //打开文件，以写入方式（接收信息）
  char buffer[max_buffer_size];    //缓冲区大小由输入参数决定，max_data_size指最大数据部分的字节数，max_buffer_size为最大缓冲区的字节数
  int buffer_size;                 //缓冲区长度（实际长度，因为最后一个帧不一定是最大帧长）

  /* Initialize sliding window variables */
  char frame[MAX_FRAME_SIZE]; //接收到的帧存在这里
  char data[MAX_DATA_SIZE];   //从帧中间提取出的数据部分
  char ack[ACK_SIZE];         //回复的内容
  int frame_size;             //实际帧长
  int data_size;              //实际数据长度
  int left, right;            //滑动窗口的左边界和右边界
  int recv_seq_num;           //当前收到的帧的序列号
  bool eot;                   //当前帧里是否有EOT
  bool frame_error;           //帧出错？是否为错误帧？

  /* Receive frames until EOT */
  bool recv_done = false; //true表示已接收完所有信息
  int buffer_num = 0;     //缓冲区个数（已经写入文件的）
  socklen_t addr_len = sizeof(sockaddr_in);

  if ((connect_fd = accept(socket_fd, (struct sockaddr *)&client_address, &addr_len)) < 0)
  {
    cerr << "accept error." << endl;
    return 1;
  }
  cout << "connected: " << inet_ntoa(client_address.sin_addr) << endl; //打印客户端IP

  while (!recv_done)
  {                                 //当前还没有收到EOT，就要继续接收信息
    buffer_size = max_buffer_size;  //缓冲区实际长度暂时置为最大缓冲区长度，用来清空缓冲区，只要不遇见EOT，这个buffer_size就是最大的
    memset(buffer, 0, buffer_size); //清空缓冲区

    cout << WHITE << "---The received data will be written to buffer " << buffer_num << "---" << endl;

    int recv_seq_count = (int)max_buffer_size / MAX_DATA_SIZE; //先计算出最多可以接收的帧数
    bool window_recv_mask[window_len];                         //接收窗口初始化，这个bool数组里为true的是已经接收到的序列号，false表示未接收到
    for (int i = 0; i < window_len; i++)
    { //初始化
      window_recv_mask[i] = false;
    }
    left = -1;                 //左右边界，不代表数组下标，只是逻辑边界，其中左边界表示这个序列号已收到，下一个序列号是第一个未收到的序列
    right = left + window_len; //右边界总是和左边界相差window_len，它表示最后一个可以接收的序列号，在左右边界之间的数，前开后闭，可以接收

    cout << WHITE << "window:     " << left + 1 << " ---------- " << right << endl;

    /* Receive current buffer with sliding window */ //接收一个buffer的数据，直到buffer满
    while (true)
    {
      frame_size = recv(connect_fd, frame, MAX_FRAME_SIZE, 0); //接收帧，返回值为帧长，内容写到frame中
      if (frame_size < 0)
      {
        cerr << "recv error." << endl;
      }
      //printf("%s\n", strerror(errno));
      //从frame读帧，序列号填入recv_seq_num，数据部分写入data，data_size为实际数据长度，eot为true表示帧内含有结束符，frame_error为true应该是错误帧
      frame_error = read_frame(&recv_seq_num, data, &data_size, &eot, frame);

      if (random(100) >= 100 * lost_rate) //产生随机数，如果大于丢包率*100，则发送，否则不发送（模拟丢失）
      {
        create_ack(recv_seq_num, ack, frame_error); //创建回复ack报文，带有收到的帧序列号，ack是输出，帧出错需要重传
        if (send(connect_fd, ack, ACK_SIZE, 0) < 0) //发送回复
        {
          cout << "send error." << endl;
        }

        cout << GREEN << "Receive seq num: " << recv_seq_num;
        if (!frame_error)
          cout << GREEN << ". No error, ack replied." << endl;
        else
          cout << GREEN << ". Frame error, ack replied." << endl;

        if (recv_seq_num <= right)
        { //接收到的序列号小于等于右边界，即在接收范围内（左边界左边的依然要回复）
          if (!frame_error)
          {                                                  //帧没有出错
            int buffer_shift = recv_seq_num * MAX_DATA_SIZE; //缓冲区偏移，当前收到的序列号*最大数据长度（序列号应该从0开始）

            if (recv_seq_num == left + 1)
            {                                                 //接收到的序列号就是左边界旁第一个，即第一个未接收到的序列号，需要滑动窗口
              memcpy(buffer + buffer_shift, data, data_size); //将数据写入到buffer，虽然写入data_size实际大小，但缓冲区是按最大数据大小增加（实际大小在不是最后一个时应该就是最大大小）

              int shift = 1; //因为至少收到一个，左边界至少要加1
              for (int i = 1; i < window_len; i++)
              { //遇到false退出，即窗口中第一个未收到的，shift指向这个未收到的序号
                if (!window_recv_mask[i])
                  break;
                shift += 1;
              }
              for (int i = 0; i < window_len - shift; i++)
              { //滑动到mask[0]为false，把后面的往前挪
                window_recv_mask[i] = window_recv_mask[i + shift];
              }
              for (int i = window_len - shift; i < window_len; i++)
              { //最后填充false
                window_recv_mask[i] = false;
              }
              left += shift;             //左边界加滑动的距离
              right = left + window_len; //右边界加滑动距离
              cout << WHITE << "window:     " << left + 1 << " ---------- " << right << endl;
            }
            else if (recv_seq_num > left + 1)
            { //收到的不是第一个未收到的序列号，而是这之后的序列号提前收到了
              if (!window_recv_mask[recv_seq_num - (left + 1)])
              {                                                     //如果这个序列号还没收到
                memcpy(buffer + buffer_shift, data, data_size);     //把data内容复制进去
                window_recv_mask[recv_seq_num - (left + 1)] = true; //标记该序列号已收到
              }
            }

            /* Set max sequence to sequence of frame with EOT */ //将最大序列设置为带EOT的帧序列号
            if (eot)
            {                                         //收到EOT
              buffer_size = buffer_shift + data_size; //最后一个缓冲区实际大小
              recv_seq_count = recv_seq_num + 1;      //收到的序列数
              recv_done = true;                       //结束接收
              cout << RED << "Received EOT, wait to end." << endl;
            }
          }
        }
      }
      else //丢包时输出丢失信息
      {
        cout << RED << "Receive seq num: " << recv_seq_num;
        if (!frame_error)
          cout << RED << ". No error, but ack lost." << endl;
        else
          cout << RED << ". Frame error and ack lost." << endl;
      }

      /* Move to next buffer if all frames in current buffer has been received */ //如果在当前缓冲区的所有帧都已经被接收，进入下一个缓冲区
      if (left >= recv_seq_count - 1)
        break; //左边界大于等于可接受到的最大值，先写入文件，再继续接收，一般只会等于不会大于，这时候如果后续有提前收到的将会被清空
    }

    cout << WHITE << "\r"
         << "[RECEIVED " << (unsigned long long)buffer_num * (unsigned long long) //缓冲区个数*最大缓冲区长度+当前缓冲区实际长度
                                    max_buffer_size +
                                (unsigned long long)buffer_size
         << " BYTES]" << endl;
    fwrite(buffer, 1, buffer_size, file);
    buffer_num += 1; //缓冲区个数+1
  }

  fclose(file);

  /* Start thread to keep sending requested ack to sender for 3 seconds */ //启动线程，将请求的ack持续发送给发送方3秒钟，TCP关闭连接，但有可能有迟到的包传送
  thread stdby_thread(send_ack);
  time_stamp start_time = current_time(); //记录开启线程的时间
  while (elapsed_time(current_time(), start_time) < ByeBye)
  { //当前时间过去3000（ByeBye)ms之内
    cout << WHITE << "\r"
         << "[STANDBY TO SEND ACK FOR 3 SECONDS | ]" << flush;
    sleep_for(100);
    cout << WHITE << "\r"
         << "[STANDBY TO SEND ACK FOR 3 SECONDS / ]" << flush;
    sleep_for(100);
    cout << WHITE << "\r"
         << "[STANDBY TO SEND ACK FOR 3 SECONDS - ]" << flush;
    sleep_for(100);
    cout << WHITE << "\r"
         << "[STANDBY TO SEND ACK FOR 3 SECONDS \\ ]" << flush;
    sleep_for(100);
  }
  cout << WHITE << "\nAll done!" << endl;
  stdby_thread.detach();

  close(connect_fd);
  close(socket_fd);

  return 0;
}
