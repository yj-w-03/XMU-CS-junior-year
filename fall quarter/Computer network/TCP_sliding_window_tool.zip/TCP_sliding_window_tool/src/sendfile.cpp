#include <iostream>
#include <thread>
#include <mutex>

#include <stdio.h>
#include <cstdlib>
#include <time.h>
#include <unistd.h>
#include <sys/socket.h>
#include <netdb.h>

#include "addition.h"

#define TIMEOUT 10 // 超时重传时间，定值，可改为采用自适应算法

using namespace std;

// socket编程使用
int socket_fd;
struct sockaddr_in server_addr, client_addr;

int window_len;               // 发送窗口大小
bool *window_ack_mask;        // 发送窗口状态数组，每个分组是否收到确认分组
time_stamp *window_sent_time; // 发送窗口状态数组，每个分组发送的时间(时间戳)
int lp1, lp2;                 // 发送窗口中的P1和P3指针(在课本P1、P3前一个位置)

time_stamp TMIN = current_time();
mutex window_info_mutex;

/* 该函数用于 接收服务器端发来的确认分组 并进行差错检测，设置滑动窗口状态 */
void listen_ack()
{
  char ack[ACK_SIZE];
  int ack_size;
  int ack_seq_num; // 确认号ack
  bool ack_error;  // 差错检测，检测分组是否正确
  bool ack_neg;    // 分组是否超时

  /* 持续监听，接收服务器端发来的确认分组 */
  while (true)
  {
    socklen_t server_addr_size;
    // TCP编程中接收数据
    ack_size = recv(socket_fd, (char *)ack, ACK_SIZE, 0);
    // 检查该确认分组是否有误,函数见addition.cpp
    ack_error = read_ack(&ack_seq_num, &ack_neg, ack);

    window_info_mutex.lock();
    // 若该确认分组无误，且确认号ack值正确(在发送窗口中)
    if (!ack_error && ack_seq_num > lp1 && ack_seq_num <= lp2)
    {
      if (!ack_neg)
      { // 该确认分组无误(绿色表示)
        window_ack_mask[ack_seq_num - (lp1 + 1)] = true;
        printf("\t\033[32m%d:ack\033[0m\n", ack_seq_num);
      }
      else
      { // 该分组出错，需要重新发送(通过设为超时，重传)
        window_sent_time[ack_seq_num - (lp1 + 1)] = TMIN;
      }
    }
    // 分组出错，直接丢弃
    window_info_mutex.unlock();
  }
}

int main(int argc, char *argv[])
{
  char *dest_ip;       // 目的主机域名
  int dest_port;       // 目的端口号
  int max_buffer_size; // 发送缓存的大小
  struct hostent *dest_hnet;
  char *fname;       // 文件指针，文件中放应用层发送的数据
  double loss_rate;  // 发送端发给接收方过程中的丢包率
  srand(time(NULL)); // 为实现丢包率产生随机数

  if (argc == 7)
  {
    fname = argv[1];                                      // 文件名称(路径) 文件中为应用层发送的数据
    window_len = atoi(argv[2]);                           // 发送窗口大小
    max_buffer_size = MAX_DATA_SIZE * (int)atoi(argv[3]); // 发送缓存大小=MAX_DATA_SIZE(1024)*窗口中的数据块个数
    dest_ip = argv[4];                                    // 目的主机IP地址
    dest_port = atoi(argv[5]);                            // 目的端口号
    loss_rate = atof(argv[6]);                            // 发送端的报文丢包率
  }
  else
  {
    // 命令行参数：文件路径(应用层发送的数据) 发送窗口大小 窗口中的数据块个数 目的主机IP(域名) 目的端口号 发送端丢包率
    cerr << "usage: ./sendfile <filename> <window_len> <buffer_size> <destination_ip> <destination_port> <loss_rate>" << endl;
    return 1;
  }

  /* 可以将域名转换成IP地址 */
  dest_hnet = gethostbyname(dest_ip); // desi_ip为目的IP地址(或域名)
  if (!dest_hnet)
  {
    cerr << "unknown host: " << dest_ip << endl;
    return 1;
  }

  memset(&server_addr, 0, sizeof(server_addr)); //初始化 清空
  memset(&client_addr, 0, sizeof(client_addr));

  /* 设置服务器地址 */
  server_addr.sin_family = AF_INET;
  bcopy(dest_hnet->h_addr, (char *)&server_addr.sin_addr,
        dest_hnet->h_length);
  server_addr.sin_port = htons(dest_port); // 服务器端TCP通信的端口号

  /* 设置客户端地址 */
  client_addr.sin_family = AF_INET;
  client_addr.sin_addr.s_addr = INADDR_ANY;
  client_addr.sin_port = htons(0); // 0为发送端TCP通信的默认端口号

  /* 创建socket */
  if ((socket_fd = socket(AF_INET, SOCK_STREAM, 0)) < 0)
  {
    cerr << "socket creation failed" << endl;
    return 1;
  }

  /* 绑定socket与发送端地址 */
  if (::bind(socket_fd, (const struct sockaddr *)&client_addr,
             sizeof(client_addr)) < 0)
  {
    cerr << "socket binding failed" << endl;
    return 1;
  }

  if (connect(socket_fd, (struct sockaddr *)&server_addr, sizeof(server_addr)) < 0)
  {
    cerr << "connect error." << endl;
    return 1;
  }

  /* 检查存放应用层数据的文件是否存在 */
  if (access(fname, F_OK) == -1)
  {
    cerr << "file doesn't exist: " << fname << endl;
    return 1;
  }

  /* 打开文件，准备发送 */
  FILE *file = fopen(fname, "rb"); // 应用层数据放在fname指向的文件中
  char buffer[max_buffer_size];    // 创建缓存区，作为发送缓存
  int buffer_size;

  /* 启动线程运行listen_ack()函数，持续监听，接收服务器端发来的确认分组 */
  thread recv_thread(listen_ack); // 实例化一个线程对象recv_thread，使用函数listen_ack构造，该线程就开始执行了

  char frame[MAX_FRAME_SIZE]; // socket编程模拟网络层，发送IP数据包
  char data[MAX_DATA_SIZE];   // socket编程TCP通信的数据部分
  int frame_size;
  int data_size;

  /* 发送文件中的应用层数据 */
  bool read_done = false; // 应用层数据是否已全部写入发送缓存的标志
  int buffer_num = 0;     // 发送缓存的个数(应用层数据分几次写入发送缓存)
  while (!read_done)
  { // 当应用层数据还未全部写入发送缓存

    /* 读取文件中的部分应用层数据，写入发送缓存(填满) */
    buffer_size = fread(buffer, 1, max_buffer_size, file); // 每次读取部分应用层数据，大小为发送缓存大小max_buffer_size，单位为字节
    // 判断应用层数据是否已经全部读出
    if (buffer_size == max_buffer_size)
    { // 上一次读取的数据等于 要求读出的数据
      char temp[1];
      int next_buffer_size = fread(temp, 1, 1, file); // 尝试读取下一个字节
      if (next_buffer_size == 0)
        read_done = true;                    // 应用层数据已经全部读出
      int error = fseek(file, -1, SEEK_CUR); // 还有数据，文件指针从当前位置回退，以免少读一个数据
    }
    else if (buffer_size < max_buffer_size)
    { // 上一次读取的数据小于 要求读出的数据，说明数据全部读出
      read_done = true;
    }

    window_info_mutex.lock();

    // 发送缓存里总共需要发送的数据块个数(分组个数)
    int seq_count = buffer_size / MAX_DATA_SIZE + ((buffer_size % MAX_DATA_SIZE == 0) ? 0 : 1); // 发送缓存里总共需要发送的数据块个数(分组个数)
    int seq_num;                                                                                // 发送缓存中已发送的seq序号(分组个数)

    /* 初始化发送窗口的状态数组和指针 */
    window_sent_time = new time_stamp[window_len]; // 发送窗口状态数组，每个分组发送的时间(已发送分组)
    window_ack_mask = new bool[window_len];        // 发送窗口状态数组，每个分组是否收到确认分组(已发送分组)
    bool window_sent_mask[window_len];             // 发送窗口状态数组，每个分组是否已经发送
    for (int i = 0; i < window_len; i++)
    {
      window_ack_mask[i] = false;  // 初始没有收到ack分组
      window_sent_mask[i] = false; // 初始没有发送分组
                                   //window_sent_time[i] = current_time();
    }
    lp1 = -1;                                    // 发送窗口中的指针P1(在课本P1前一个位置)
    lp2 = lp1 + window_len;                      // 发送窗口中的指针P3(在课本P3前一个位置)
    printf("window: %d-----%d\n", lp1 + 1, lp2); //输出当前窗口位置

    window_info_mutex.unlock();

    printf("-----buffer NO: %d-----\n", buffer_num); // 输出发送缓冲的序号
    /* 通过滑动窗口发送 发送缓存中的数据 具体实现如下 */
    bool send_done = false; // 发送缓存中的数据是否已全部发送并收到确认分组的标志
    while (!send_done)
    {
      window_info_mutex.lock();

      /* 检查收到的确认分组，确定滑动窗口的状态 */
      if (window_ack_mask[0])
      {                // 发送窗口中第一个分组若已收到确认分组
        int shift = 1; // 当前窗口滑动值为1
        // 遍历所有分组的确认信息，计算按序收到确认分组的个数shift，窗口向前滑动shift
        for (int i = 1; i < window_len; i++)
        {
          if (!window_ack_mask[i])
            break;
          shift += 1;
        }
        // 窗口向前滑动shift，继续发送发送窗口中shift个分组(按序收到确认分组的分组从窗口中滑出)
        for (int i = 0; i < window_len - shift; i++)
        {
          window_sent_mask[i] = window_sent_mask[i + shift]; //已发送
          window_ack_mask[i] = window_ack_mask[i + shift];   //未收到确认
          window_sent_time[i] = window_sent_time[i + shift]; //设置超时计时器
        }
        // 未发送的数据(有效窗口)
        for (int i = window_len - shift; i < window_len; i++)
        {
          window_sent_mask[i] = false; //未发送
          window_ack_mask[i] = false;  //未收到确认
        }
        lp1 += shift;                                // P1指针向前移动shift
        lp2 = lp1 + window_len;                      // P3指针
        printf("window: %d-----%d\n", lp1 + 1, lp2); //输出当前窗口位置
      }

      window_info_mutex.unlock();

      /* 根据发送窗口的状态，发送 发送窗口中的未发送的分组 以及需要重传(超时、出错)的分组 */
      for (int i = 0; i < window_len; i++)
      {
        seq_num = lp1 + i + 1; // 更新当前发送缓存中已发送的seq序号

        if (seq_num < seq_count)
        { //当前已发送的seq序号小于总共需要发送的seq序号
          window_info_mutex.lock();

          // 窗口中的未发送的分组 以及 需要重传的分组
          if ((!window_sent_mask[i]) || (!window_ack_mask[i] && (elapsed_time(current_time(), window_sent_time[i]) > TIMEOUT)))
          {
            int rate = rand() % 100; // 随机数对100取余，根据丢包率决定是否发送
            if (rate >= loss_rate * 100)
            {                                             // 余数大于丢包率的百分数，发送
              int buffer_shift = seq_num * MAX_DATA_SIZE; // 当前序号分组的指针
              // TCP每次发送的数据块大小
              data_size = (buffer_size - buffer_shift < MAX_DATA_SIZE) ? (buffer_size - buffer_shift) : MAX_DATA_SIZE;
              memcpy(data, buffer + buffer_shift, data_size); // 向下交付的TCP数据部分

              bool eot = (seq_num == seq_count - 1) && (read_done);            // 此TCP数据块是否为最后一块
              frame_size = create_frame(seq_num, frame, data, data_size, eot); // 向下交付给网络层
              // 通过TCP连接发送数据
              if (send(socket_fd, frame, frame_size, 0) < 0)
              {
                cerr << "send error." << endl;
              }

              // 已发送未收到ack，需要重传的分组(蓝色表示)
              if ((window_sent_mask[i]) && (!window_ack_mask[i] && (elapsed_time(current_time(), window_sent_time[i]) > TIMEOUT)))
              {
                printf("\t\033[34msend_num(timeout): %d\033[0m\n", seq_num);
              }
              else
              { // 未发送的分组(白色表示)
                printf("\tsend_num: %d\n", seq_num);
              }
            }
            else
            { // 余数小于等于丢包率的百分数，则不发，模拟发送端发完接收端的报文丢失(红色表示)
              printf("\t\033[31mloss_num: %d\033[0m\n", seq_num);
            }
            window_sent_mask[i] = true;           // 分组已发送
            window_sent_time[i] = current_time(); // 设置发送分组的时间
          }

          window_info_mutex.unlock();
        }
      }

      /* 当前发送缓存中的数据全部收到确认分组，移向下一个发送缓存(应用层往发送缓存中继续写入后续数据) */
      if (lp1 >= seq_count - 1)
        send_done = true; // 发送缓存中的数据已全部发送完毕的标志
    }

    // 输出已发送并收到确认的总数据量 = 之前发送缓存的个数*发送缓存的大小 + 当前发送缓存中的数据量
    cout << "\r"
         << "[SENT " << (unsigned long long)buffer_num * (unsigned long long)max_buffer_size + (unsigned long long)buffer_size << " BYTES]" << flush
         <<"\n";
    buffer_num += 1; // 发送缓存个数加一
    if (read_done)
      break; // 应用层数据全部写入发送缓存并发送完毕
  }

  fclose(file); // 关闭文件
  delete[] window_ack_mask;
  delete[] window_sent_time;
  recv_thread.detach(); // 线程退出，释放所有分配的资源
  sleep_for(4000);
  close(socket_fd);

  cout << "\nAll done!" << endl;
  return 0;
}
