﻿//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ 生成的包含文件。
// 供 MFCApplication3BMP.rc 使用
//
#define IDD_ABOUTBOX                    100
#define IDP_OLE_INIT_FAILED             100
#define IDR_MAINFRAME                   128
#define IDR_MFCApplication3BMPTYPE      130
#define IDD_DIALOG_ZFT                  315
#define IDCANCEL                        1002
#define IDC_COMMONDIALOG1               1004
#define IDC_STATIC_ZFT                  1008
#define IDC_SLIDER_TV                   1009
#define IDC_TEXT_TV                     1010
#define ID_32771                        32771
#define ID_32772                        32772
#define ID_32773                        32773
#define ID_Menu                         32774
#define ID_32775                        32775
#define ID_32776                        32776

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        320
#define _APS_NEXT_COMMAND_VALUE         32777
#define _APS_NEXT_CONTROL_VALUE         1011
#define _APS_NEXT_SYMED_VALUE           310
#endif
#endif
